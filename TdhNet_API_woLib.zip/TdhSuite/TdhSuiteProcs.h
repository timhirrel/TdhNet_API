// defines a class used to set up the TdhNet API and to control the solution process

#ifndef TdhSuiteProcsHeader
#define TdhSuiteProcsHeader

#include "TdhContainer.hpp"
#include "TdhSolutionIntf.h"
#include "Tdhdata02.h"

class TQualityAnalysis;

class TSuiteProcs {
protected:
  virtual TSystemResults0 *SysRslt();
  virtual TEpsResults0 *EpsRslt ();
  virtual Ttdhvars *TdhVars () {return tdhvars;}
  TSystemIntf *sysIntf;
  TRuleIntf *ruleIntf;
  TPrvIntf *prvIntf;
  bool usePumpControls;
  TdhContainer *dataContainer;
//  void StartUp (Ttdhvars*, TMessenger0*);
  virtual bool Init (Ttdhvars*, TMessenger0*);
  virtual TtdhDataInterfaces2 *DataIntfs();
  virtual solution_stats Solve2 (tdhString, tdhString); //called by Solve()
  virtual bool UsePumpControls(); //returns true if pumps speed control are being used
public:
  TQualityAnalysis *QualityAnalysis;
  bool firstsolve;
  Ttdhvars *tdhvars;
  TSuiteProcs (Ttdhvars*, TMessenger0*);
  virtual ~TSuiteProcs ();
  virtual TdhContainer *DataContainer() {return dataContainer;}
  virtual bool SequenceInit  (tdhString, tdhString); //called at the start of a solution sequence
  virtual void ResetSolve (); //called to reset the solution engine and allow for a new solution sequence
  virtual solution_stats Solve (tdhString, tdhString); //called to obtain a single solution and perform post solution processing. returns the solution status
  virtual void SetNextTime(); //returns the the next time for an eps solution
  virtual void SetEngine(TEngineTypes); //sets the solution engine type
  };


#endif
