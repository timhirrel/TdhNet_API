// implements classes to set up and control a hydraulic solution sequence
// and the water quality analyses

#include "TdhSuiteProcs.h"
#include "QualityIntf.h"
#include "TdhIO.hpp"
#include "TdhContainer.hpp"
#include "TdhEngine.h"
#include "EpaEngine.h"
#include "uiUtils_generic.h"


class TQualityAnalysis {
// sets up the quality analysis functionality
// and controls the quality analysis process
protected:
  TdhContainer *dataContainer;
  virtual TSystemResults0 *SysRslt();
  virtual TEpsResults0 *EpsRslt ();
  TSystemIntf2 *sysdata;
  TEpsIntf2 *epsdata;
  int QualSolveType;
  virtual TdhContainer *DataContainer () {return dataContainer;}
  virtual Ttdhvars *TdhVars ();
  virtual TtdhDataInterfaces2 *DataIntfs();
public:
  TQualityAnalysis (TdhContainer *dataParam) {
    dataContainer = dataParam;
    sysdata = DataIntfs()->get_SystemIntf2();
    epsdata = DataIntfs()->get_EpsIntf2();
    };
  virtual ~TQualityAnalysis () {
    }
  void Prepare ();
  void Solve ();
  void Reset ();
  };

TtdhDataInterfaces2 *TQualityAnalysis::DataIntfs() {
  return DataContainer()->DataIntfs(); }

Ttdhvars *TQualityAnalysis::TdhVars() {
  return DataContainer()->TdhVars();}

TSystemResults0 *TQualityAnalysis::SysRslt() {
  return TdhVars()->ResultsClasses()->SystemRslts(); }

TEpsResults0 *TQualityAnalysis::EpsRslt() {
  return TdhVars()->ResultsClasses()->EpsRslts();}

void TQualityAnalysis::Prepare () {
// prepares the quality analysis for a solution sequence
  QualSolveType = 0;
  if (SysRslt()->epsflag())
	QualSolveType = epsdata->get_QualSolveType();
  if (QualSolveType > 0)
	TdhVars()->QualityIntf()->PrepareQual();
  }

void TQualityAnalysis::Solve () {
// performs a quality analysis for the current solution
  if (QualSolveType)
    TdhVars()->QualityIntf()->SolveQual(EpsRslt()->time_step());
  }

void TQualityAnalysis::Reset () {
// reset the quality analysis after completion of a solution sequence
  TdhVars()->QualityIntf()->ResetQual();
  }


//TSuiteProcs *suiteProcs;

TSuiteProcs::TSuiteProcs (Ttdhvars *varsparam, TMessenger0 *reportParam) {
  Init (varsparam, reportParam);
  }

bool TSuiteProcs::Init (Ttdhvars *varsparam, TMessenger0 *reportParam) {
// sets up the TdhNet API
  tdhvars = varsparam;
  firstsolve = true;
  SetEngine (engtypeTdhNet);
  dataContainer = get_TdhContainer(tdhvars); //TdhContainer_Create(tdhvars);
  TdhQuality_Init(DataContainer());
  TdhIO_StartUp(DataContainer(), reportParam);
  QualityAnalysis = new TQualityAnalysis(DataContainer());
  sysIntf = DataIntfs()->get_SystemIntf();
  ruleIntf = DataIntfs()->get_RuleIntf();
  prvIntf = DataIntfs()->get_PrvIntf();
  return true;
  }

TSuiteProcs::~TSuiteProcs () {
  }

TtdhDataInterfaces2 *TSuiteProcs::DataIntfs() {
  return DataContainer()->DataIntfs(); }

TSystemResults0 *TSuiteProcs::SysRslt() {
  return TdhVars()->ResultsClasses()->SystemRslts(); }

TEpsResults0 *TSuiteProcs::EpsRslt() {
  return TdhVars()->ResultsClasses()->EpsRslts();}

void TSuiteProcs::SetEngine (TEngineTypes typeParam) {
  switch (typeParam) {
    default:
    case engtypeTdhNet: Use_TdhNet_Engine(tdhvars); break;
    case engtypeEpanet: Use_EpaNet_Engine(tdhvars, get_EpaIntf(tdhvars->Messenger())); break;
    }
  }

bool TSuiteProcs::SequenceInit (tdhString chansetname, tdhString controlname) {
// sets up the API for a solution sequence
  SetEngine(DataContainer()->DataIntfs()->get_SystemIntf()->EngineType());
  TdhVars()->TdhIO()->SetOutProc(TTdhIO::ftSolution, TdhVars()->Messenger(), 0);
  DataContainer()->AttachData(chansetname);
  if (DataContainer()->DataCheck(chansetname, true))
    return false;
  TdhVars()->SolveControl()->SequenceInit(true);
  TdhVars()->ChangeInst()->Controls_Start();
  TdhVars()->ChangeInst()->StartChanges(chansetname);
  QualityAnalysis->Prepare();
  DataIntfs()->get_PumpControlIntf()->SequenceInit();
  usePumpControls = UsePumpControls();
  return true;
  }

void TSuiteProcs::ResetSolve () {
// resets the API after completion of a solution sequence
  QualityAnalysis->Reset();
  DataContainer()->UnAttachData();
  TdhVars()->QualityIntf()->ResetQual();
  TdhVars()->ChangeInst()->UndoChanges();
  TdhVars()->SolveControl()->ResetSolve();
  firstsolve = true;
  }

solution_stats TSuiteProcs::Solve (tdhString chansetname, tdhString controlname) {
// performs a solution
// returns the status of the solution
  solution_stats result = Solve2(chansetname, controlname);
  TdhVars()->SolveControl()->set_SolveStatus(result);
  return result;
}

solution_stats TSuiteProcs::Solve2 (tdhString chansetname, tdhString controlname) {
// invokes the EPS driver and quality solve
// performs a hydraulic solution
// returns solution status
  solution_stats result = Unknown_status;
  if (firstsolve) {
    if (!SequenceInit(chansetname, controlname))
      return DATA_ERROR;
    prvIntf->SetFloatValves();
    }
  else { //invoke quality analysis and EPS driver
    SetNextTime();
	QualityAnalysis->Solve();
	TdhVars()->ChangeInst()->NextChange(EpsRslt()->current_time());
	if (!TdhVars()->SolveControl()->EpsDriver())
      return DATA_ERROR;
	}
  if (SysRslt()->epsflag())
    TdhVars()->Messenger()->Message("Time: " + stringify(EpsRslt()->current_time()));
  int iteration=0;
  do { //perform a hydraulic solution
    result = TdhVars()->SolveControl()->SolveOne(iteration);
	iteration = SysRslt()->iterations();
	if (usePumpControls)
	  DataIntfs()->get_PumpControlIntf()->ImplementPumpControls();
	} while (TdhVars()->ChangeInst()->Rules_Process() && iteration < sysIntf->get_maxtrials());
  TdhVars()->SolveControl()->EnergyCalcs();
  TdhVars()->SolveControl()->SetTankFlows();
  firstsolve = false;
  return result;
  }

void TSuiteProcs::SetNextTime () {
// sets the next time in the solution sequence
  TdhVars()->SolveControl()->InitNextTime();
  TdhVars()->ChangeInst()->SetNextTime();
  ruleIntf->set_NextTime();
  prvIntf->SetFloatValves();
  TdhVars()->SolveControl()->TankTimeLimit();
  }

bool TSuiteProcs::UsePumpControls () {
// returns value defining whether pump controls are used within the solution sequence
  TChangeSetIntf *chansetIntf = DataIntfs()->get_ChangeSetIntf();
  return chansetIntf->get_UsePumpControls();
  }


