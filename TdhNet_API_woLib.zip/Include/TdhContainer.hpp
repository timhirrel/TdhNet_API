// Copyright 2009-2023
// Timothy D. Hirrel, TDH Engineering
// timhirrel@tdhnet.com

#ifndef tdhcontainerheader
#define tdhcontainerheader

#include "tdhdefs.hpp"

class Ttdhdata;
class Ttdhdata2;
class TtdhDataInterfaces;
class TtdhDataInterfaces2;

class EXPORTPROC TdhContainer {
// establishes instances for input data class and change data class
// associates the data with a Ttdhvars instance
// provides functionality for using the data for a solution
public:
  Ttdhvars *tdhvars;
  Ttdhdata2 *tdhdata;
  TdhChanges0 *tdhChanges;
public:
  TdhContainer (Ttdhvars*);
  virtual ~TdhContainer ();
  virtual bool Ok () {return true;}
  virtual Ttdhvars *TdhVars () {return tdhvars;}
  virtual Ttdhdata2 *TdhData2() {return tdhdata;}
  virtual Ttdhdata *TdhData() {return (Ttdhdata*)tdhdata;}
  virtual void set_TdhData (Ttdhdata2 *val) {tdhdata = val;}
  virtual TtdhDataInterfaces2 *DataIntfs();
  virtual void EmptyData (); //empties all data from the container, calls UnAttachData
  virtual void EmptyChanges (); //empties change data from the container
  virtual void AttachData (tdhString); //attaches data to the solution engine, 2nd parameter specifies a ChangeSetName (use "" for none)
  virtual void UnAttachData (); //unattaches data from the solution engine
  virtual bool DataCheck (tdh_keytype chansetID, bool stopcheck=false);
    //checks attached data and the specified change data
    //returns true if data error found; stopcheck stops other data checks, if true
  virtual bool IsDataAttached(); //result is valid only if TdhContainer functions are used to attach and unattached data
  virtual Tsysdataref0 *SysData (); //return system data
  };

enum changetypes {
    ctNone = -1,    //an undefined change type
    ctDemand = 0,   //to set a new nodal demand
    ctFGNGrade,     //to set a new fixed grad
    ctPipeStatus,   //to set a new pipe status
    ctLength,       //to set a new pipe length
    ctDiameter,     //to set a new pipe diameter
    ctRoughness,    //to set a new pipe roughness
    ctMinor,        //to set a new pipe minor coefficient
    ctPumpSpeed,    //to set a new pump speed
    ctPumpPower,    //to set a new pump power
    ctPRVGrade,     //to set a new prv grade
    ctTankInflow,   //obsolete
    ctPowerCost,    // to set a new power cost
    ctGroupDemandFactor, //to set a new node group demand factor
    ctQualSource_jun,   //to set a new quality source for a junction node
    ctQualSource_fgn,   //to set a new quality source for a fixed grade node
    ctQualStart_jun,    //to set a new quality start for a junction node
    ctQualStart_fgn,    //to set a new quality start for a fixed grade node
    ctPipePumpSpeed,    //to set a new pump speed
    ctSwitchStatus, //obsolete
    ctSwitchFactor, //obsolete
    ctGroupUsage,   //to set a new node group status
    ctRuleStatus,   //to set a new rule status
    ctAddDemand,    //to add to a node demand
    ctControlsUse,  //to set a new control set status
    ctPipeQuality,  //to set a new pipe quality
    ctEmitCoef,     //to set a new emitter coefficient
    ctPumpControlGrade,     //to set a new pump control grade
    ctPumpControlStatus,    //to set a new pump control status
    ctValveOpen,    //to set the amount open for a throttle valve
    ctMax   //marks the highest change type value
    };

class EXPORTPROC TdhChanges0 {
//an abstract class for change data functionality
protected:
public:
  virtual ~TdhChanges0() {}
  virtual void InitChanges() {} //initialize change structures
  virtual bool StartChanges (tdhString)= 0; //start implementation of change data (1st param) for solution sequence, call after ModInit
  virtual void SetAllDemands() {}
  virtual void RestartChanges () = 0;
  virtual void GotoTime (float) {} //set the eps time to the 1st param
  virtual void NextChange (float) = 0; //incorporate next change situation if situation time <= 1st param
  virtual bool AnotherSim () = 0; //determine if another solution is needed for either eps or a change situation
  virtual bool CheckChanges (tdhString) = 0;
  virtual bool ChangeError (FLAG reset=0) {return 0;} //returns error status
  virtual bool RepeatEps () {return 0;}
  virtual int CurrentSitNum () = 0;
  virtual int CurrentRepeatNum () {return 0;}

  virtual tdhString EntTypeStr (changetypes) = 0; //return entity label for change type
  virtual tdhString ValueStr (changetypes) = 0; //return value label for change type

  virtual void CreateUndo (tdhString, double, changetypes) {}
  virtual void UndoChanges () {} //restores data to before changes

  virtual bool Controls_Start () = 0; //starts implementation of all active control sets
  virtual bool Rules_Process () = 0; //checks the condition status of rules and implements appropriate actions
  virtual void SetNextTime () = 0;
  };


EXTERNC TdhContainer EXPORTPROC *get_TdhContainer (Ttdhvars*);

#endif
