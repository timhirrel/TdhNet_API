// Provides classes for implementing the TdhNet solution engine and the Epanet solution engine
// using the modified Epanet API within the TdhNetAPI_Demo

#ifndef EpaToTdDemoFuncs_Header
#define EpaToTdDemoFuncs_Header

#include "EpaDemo_funcs.h"

class TEpaIntf0;
class TSystemResults0;

class TEpaToTdhDemo : public TEpaDemo {
// this class implements the TdhNet solution engine using a modified EpaNet API
protected:
  Ttdhvars *tdhvars2;
  TdhContainer *dataContainer2;
  TEpaIntf0 *epaIntf;
  TSystemResults0 *sysRslts;
  virtual TEpaIntf0 *EpaIntf () {return epaIntf;}
  virtual void Init();
  virtual void WriteDiameters();
  virtual void Solve();
  virtual void WriteFlows();
  virtual void SaveResultsToDB ();
public:
  };

class TEpaToEpaDemo : public TEpaToTdhDemo  {
// this class implements the EpaNet solution engine using a modified EpaNet API
protected:
  virtual void Init();
  virtual void SetEngine();
  virtual void Solve();
  };

#endif // EpaToTdDemoFuncs_Header
