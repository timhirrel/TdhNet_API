#ifndef TDHSQL_IO_H_INCLUDED
#define TDHSQL_IO_H_INCLUDED

#include "Tdhdata02.h"

enum loadResultsFlag {lfNextSim, lfScratchRun, lfScratchSim}; //, lfScratchAll
enum PumpResult_Types {crSystem, crStation, crPump};

class TCadDrawingData;
class TSqlUtils;
class TtdhSql_IO;
class TGetData;
class TLoadData;
class TLoadResults;
class TEpsRestore;
class TGetResults;
class TtdhOrphans;
class TVgUtils;
class TdhImageIO_tdhnet;
class TdhSetDb_net;
class Tdbfuncs;
class TUpdateDB;
class TdhContainer;

class EXPORTPROC TdhSql_netIO {
protected:
//  TSqlUtils *SqlUtils;
  TtdhSql_IO *tdhSql;
  TGetData *getData;
  TLoadData *loadData;
  TLoadResults *LoadResults;
  TEpsRestore *epsRestore;
  TGetResults *GetResults;
  TtdhOrphans *tdhOrphans;
  TdhSetDb_net *setterDB;
  Tdbfuncs *dbFuncs;
  TUpdateDB *updateDB;
//  TdhImageIO_tdhnet *imageIO;
public:
  TMessenger0 *sqlMessage;
  TdhSql_netIO (TdhContainer*, tdhString);   //initialize TdhSql, 2nd param is structure directory
  virtual int getLibVersion (); //returns the current library version
  virtual char SetDB (tdhString); //sets the TdhNet database

  virtual TtdhSql_IO *TdhSql () {return tdhSql;}
  virtual Tdbfuncs *DbFuncs ();
  virtual TUpdateDB *UpdateDB () {return updateDB;}
  virtual TdhSetDb_net *SetterDB ();
  virtual TtdhOrphans *Orphans () {return tdhOrphans;}
  virtual TEpsRestore *EpsRestore () {return epsRestore;}
  virtual TdhContainer *DataContainer ();
  virtual void set_DataContainer(TdhContainer*);

  virtual bool SaveNetwork ();
    // save network data to database
    // if network name doesn't exist in database, a new network code is assigned
    // if network name exists and its network code = current NetworkCode, existing data is overwritten
    // if network name exists and its network code != current NetworkCode, data is not saved

  virtual int getNetworkCode (tdhString); //returns DatasetCode for a network name; returns -1 if name not found

  virtual bool getNetwork (int); //transfers into RAM the network specified by DatasetCode

  virtual void DeleteNetwork (int); //deletes from the database the network specified by DatasetCode

  virtual int getCurrNetCode (); //returns current NetworkCode; i.e. the most recent network accessed

  virtual bool getNetName (int netCode, tdhString* =NULL, tdhString* =NULL);
    //returns false if netCode not in database
    //puts network name in 1st string and network description in 2nd string, if parameter values are not NULL

  virtual void resetCurrNetCode ();   //sets current NetworkCode and runnumber to 0 (all valid codes are greater than 0);
  virtual int getFlaggedNet (); // get the Network last accessed in the previous session
  virtual bool Compress (); //use to compress database after numerous deletes; also removes any orphans. may take some time
  virtual void FillNetworkList (TStringVector*); //fill string vector with network names contained in database

  virtual bool SaveResults (loadResultsFlag = lfNextSim, TChangeSetIntf* = NULL, bool = false);
    //saves results to database, returns false if results are not available or cannot be saved
    // if loadFlag = lfNextSim, unique run and simulation numbers will be used
    // if loadFlag = lfScratchAll run number will = 1 and simulation number = -1
    // if loadFlag = lfScratchSim run number will be unique and simulation number will = -1
    // if loadFlag = lfScratchRun run number will be 1 and simulation number will be unique
    // if 2nd parameter != NULL, changeset description will be written with run results
    // the 3rd parameter is only used for lfScractchRun to indicated whether the simulation is the first in the sequence

  virtual bool getResults (int, long, int);
    // transfers into RAM the results in database for the network associated with the current Network Code and specified by
    // parameters are network code, run number and simulation number
    // the results must be associated with input data currently in the data container
    // returns false if simulation not found

  virtual void DeleteResults(int, long, int = -1);
    // parameters are network code, run number and simulation number
    // deletes run number and all simulations if simulation number < 0; otherwise deletes just one simulation.

  void FillRunList (int, std::vector<long>*); //fills vector with all the run numbers associated with a network code (1st parameter)
  virtual bool getSelectedOrCurrentSim (bool, long*, int*, float* = NULL, int* = NULL);
    // if 1st param = true, saves and sets the current results as selected. return false if current results not available
    // for the results currently set as selected, sets:
      // 2nd param as run number, 3rd param as simulation number, 4th param as simulation eps time, 5th param as position of simulation within the saved simulations for the run.
      // if no results are set as selected, returns false


  virtual TGetData *GetData() {return getData;}
  virtual TLoadData *LoadData() {return loadData;}
  };
//extern EXPORTPROC TdhSql_netIO *TdhnetSql_IO;


class EXPORTPROC TdhSql_netIO_images : public TdhSql_netIO {
public:
  TdhImageIO_tdhnet *imageIO;
public:
  TdhSql_netIO_images (TdhContainer*, tdhString, TVgUtils*);   //initialize TdhSql, 2nd param may be NULL
  virtual TdhImageIO_tdhnet *ImageIO() {return imageIO;}
  };

#endif // TDHSQL_H_INCLUDED
