// Provides a set of interfaces for data that is not needed by the solution engine
// but is otherwise used for modeling purposes

//---------------------------------------------------------------------------
#ifndef tdhdata02H
#define tdhdata02H
//---------------------------------------------------------------------------


#include "Tdhdata01.h"
#include "CadPrimitives0.h"
#include "DataInterfaces.h"
#include "TdhContainer.hpp"

typedef std::string TTdhLabelStr;
typedef std::string TNetName;

enum OutputOptions {loOff, loDefaultNo, loDefaultYes}; //limited output options
enum OuputFlags {lfDefault, lfYes, lfNo}; //limited output flags
enum TColorFlag_hyd {cfOwner_hyd, cfColor_hyd};




enum pipestatuschanges {scToggle=-1, scOpen, scClose};
enum groupuseflags {gufOn=-1, gufOff=-2, gufAllOff=-3};
enum GroupStatus {gsOff, gsOn, gsPtsOff};

class Ttdhdata2;
class TvgData;
class TCellData;
class TCadDrawingData;
class Tsystemdata2;
class Tsystem_results2;
class TtdhDataInterfaces2;

class EXPORTPROC TBaseIntf2 {
protected:
  Ttdhdata2 *tdhdata2;
public:
  TBaseIntf2 (Ttdhdata2 *dataParam) {
    tdhdata2 = dataParam;
    }
  virtual TtdhDataInterfaces2 *DataIntfs2();
  };

class EXPORTPROC TSystemIntf2 : public TSystemIntf, public TBaseIntf2 {
protected:
  virtual Tsystemdata2 *GetDataObj2();
public:
  TSystemIntf2 (Ttdhdata2*);
  virtual TNetName get_netname();
  virtual void set_netname (TNetName);
  virtual OutputOptions get_limitedoutput ();
  virtual void set_limitedoutput (OutputOptions);
  virtual double get_defradius ();
  virtual void set_defradius (double);
  virtual double get_minradius ();
  virtual void set_minradius (double);

  virtual void set_vgData (TvgData*, TCellData*);
  virtual TvgData *get_vgData ();
  virtual void set_cellflag(FLAG);
  virtual FLAG get_cellflag ();
  virtual double get_cellwidth ();
  virtual void set_cellwidth (double);
  virtual double get_cellheight();
  virtual void set_cellheight (double);
  virtual TTdhLabelStr get_celldescript ();
  virtual void set_celldescript (TTdhLabelStr);
  virtual TTdhLabelStr get_cellxdescript ();
  virtual void set_cellxdescript (TTdhLabelStr);
  virtual TTdhLabelStr get_cellydescript ();
  virtual void set_cellydescript (TTdhLabelStr);
  virtual double get_cellxorig();
  virtual void set_cellxorig (double);
  virtual double get_cellyorig();
  virtual void set_cellyorig (double);
  virtual TCadDrawingData *get_CadDrawingData ();

  virtual bool copy_data (TSystemIntf2*);
};

class TChangeSetIntf;
class Tepsdata2;
class EXPORTPROC TEpsIntf2 : public TEpsIntf {
protected:
  TChangeSetIntf *chansetIntf;
  virtual Tepsdata2 *GetDataObj2();
  virtual Tepsdata *GetDataObj();
public:
  TEpsIntf2 (TChangeSetIntf*, Ttdhdata2*);
  virtual FLAG get_QualTraceNodeType ();
  virtual void set_QualTraceNodeType(FLAG);
  virtual FLAG get_QualSolveType ();
  virtual void set_QualSolveType(FLAG);
  virtual double get_EpsTimePause();
  virtual void set_EpsTimePause(double);
  virtual double get_EpsPauseInterval();
  virtual void set_EpsPauseInterval(double);
  virtual int get_EpsRepeatValue();
  virtual void set_EpsRepeatValue(int);
  virtual double get_EpsReportStep ();
  virtual void set_EpsReportStep(double);
  virtual int get_QualMaxSegs();
  virtual void set_QualMaxSegs(int);
  virtual double get_GlobalWallCoeff();
  virtual void set_GlobalWallCoeff(double);
  virtual double get_GlobalBulkCoeff();
  virtual void set_GlobalBulkCoeff(double);
  virtual double get_BulkOrder();
  virtual void set_BulkOrder(double);
  virtual double get_WallOrder();
  virtual void set_WallOrder(double);
  virtual double get_TankOrder();
  virtual void set_TankOrder(double);
  virtual double get_Diffusivity();
  virtual void set_Diffusivity(double);
  virtual double get_QualTimeStep();
  virtual void set_QualTimeStep(double);
  virtual tdh_keytype get_QualTraceNodeID();
  virtual void set_QualTraceNodeID(tdh_keytype);
  virtual double get_QualityTolerance();
  virtual void set_QualityTolerance(double);
  virtual double get_QualityLimit();
  virtual void set_QualityLimit(double);
  virtual double get_QualRoughnessFactor();
  virtual void set_QualRoughnessFactor(double);
  virtual TTdhLabelStr get_ChemicalName();
  virtual void set_ChemicalName(TTdhLabelStr val);
  virtual bool copy_data (TEpsIntf2*);
 };

class Ttdhlabel;
class TtdhNoKey;
class EXPORTPROC TLabelIntf: public TBaseIntf01 <Ttdhlabel, TtdhNoKey*>,
public TBaseIntf2 {
protected:
  virtual Ttdhlabel *createObj();
  virtual bool new_data_wkey (Ttdhlabel*) {return false;}
public:
  TLabelIntf (Ttdhdata2*, TRecordsNav0 <Ttdhlabel, TtdhNoKey*>*);
  virtual TTdhLabelStr get_labelstr ();
  virtual void set_labelstr (TTdhLabelStr);
  virtual void Clear ();
  virtual bool copy_data (TLabelIntf*);
  };

class TSysLabelIntf : public TLabelIntf {
protected:
//  TRecordsNav0 <Ttdhlabel, Ttdhlabel*> *queManager;
  virtual void new_data ();
public:
  TSysLabelIntf (Ttdhdata2*);
  virtual ~TSysLabelIntf();
  virtual entities GetEntType() {return etSYSLABEL;}
  };

class TtdhNote;
class EXPORTPROC TNoteIntf : public TBaseIntf01 <TtdhNote, unsigned>,
public TBaseIntf2 {
protected:
//  int noteCode;
//  virtual int GetNewCode();
//  virtual void setkey (int keyParam) {
//    noteCode = keyParam;}
  virtual TtdhNote *createObj() {return NULL;}
//  virtual int *keyPtr () {return &noteCode;}
  virtual bool new_data_wkey (int) {return false;}
  virtual void new_data() {}
public:
  TNoteIntf (Ttdhdata2*);
  virtual ~TNoteIntf ();
//  virtual int getkey () {return noteCode;}
  virtual entities get_entitytype();
//  virtual tdh_keytype get_EntKey();
//  virtual void set_entitytype (entities);
  virtual unsigned get_notecode();
  virtual void set_notecode(unsigned);
  virtual tdhString get_NoteStr();
  virtual void set_NoteStr (tdhString);
  virtual long get_noteDate ();
  virtual void set_noteDate(long);
  virtual int GetEntCode (TBase0Intf*);
  virtual bool SetEntCode (TBase0Intf*, int code);
  virtual tdh_keytype FindEnt (int codeparam, entities, tdh_keytype previd = "");
  virtual void new_data(entities);
  virtual bool OkToWrite (long);
  virtual bool get_WriteFlag();
  virtual void Reset_WriteFlags ();
  virtual entities GetEntType() {return etNOTE;}
  };

class EXPORTPROC Tpipe_data2;
class EXPORTPROC TPipeIntf2 : public TPipeIntf, public TBaseIntf2 {
protected:
  virtual Tpipe_data *createObj();
public:
  TPipeIntf2 (Ttdhdata2*);
  virtual ~TPipeIntf2 ();
  virtual Tpipe_data2 *GetDataObj2() {return (Tpipe_data2*)GetDataObj();}
  virtual bool copy_data (TPipeIntf2*, tdh_keytype);
  virtual FLAG get_OutputFlag ();
  virtual void set_OutputFlag (FLAG);
  virtual bool Output (); //returns output decision based on system option and junction flag
  virtual FLAG get_CordsModified ();
  virtual void set_CordsModified (FLAG);
  virtual char get_width();
  virtual void set_width (char);
  virtual word get_color ();
  virtual void set_color (word);
  virtual int get_colorFlag ();
  virtual void set_colorFlag (TColorFlag_hyd);
  virtual double get_radius();
  virtual void set_radius (double);
  virtual double get_WallCoeff();
  virtual void set_WallCoeff (double);
  virtual double get_BulkCoeff();
  virtual void set_BulkCoeff (double);
  virtual double get_QualityStart();
  virtual void set_QualityStart (double);
  virtual void setCurrent_QualityStart(double);
  virtual long get_notecode();
  virtual void set_notecode (long);
  virtual long *get_NotePtr ();
  virtual TPointXY GetNodeCords (char pos); // set pos = 1 for nodea, pos = 2 for nodeb
  virtual void SetNodeCords (char, TPointXY0&); // set param1 = 1 for nodea, 2 for nodeb
  virtual TMultiLine0 *get_multiline ();
  virtual TMultiLine *MultiLine ();
  virtual void set_LabelPt (TPointXY0&);
  virtual TPointXY get_LabelPt ();
  virtual void set_ycord (double);
  virtual void set_xcord (double);
  virtual FLAG get_UserFlag ();
  virtual void set_UserFlag (FLAG);
  virtual void CalcRoughness_dw (bool = false); //if 1st param true, set rough2 to CalcDarcyFromHazen, else copy rough1 to rough2, set rough1 to 0
  virtual double CalcDarcyFromHazen(double); // use 1st Param (cval) and diam to calc a darcy ff from hazen c (Travis and Mays’s (2007) equation)
  };

class Tprv_data2;
class EXPORTPROC TPrvIntf2 : public TPrvIntf, public TBaseIntf2 {
protected:
  virtual Tprv_data *createObj();
public:
  TPrvIntf2 (Ttdhdata2*);
  virtual long get_notecode();
  virtual void set_notecode (long);
  virtual bool copy_data (TPrvIntf2*, tdh_keytype);
  virtual Tprv_data2 *GetDataObj2 () {return (Tprv_data2*)GetDataObj();}
  };

class Tpump_data2;
class EXPORTPROC TPumpIntf2 : public TPumpIntf, public TBaseIntf2 {
protected:
  virtual Tpump_data *createObj();
public:
  TPumpIntf2 (Ttdhdata2*);
  virtual long get_notecode();
  virtual void set_notecode (long);
  virtual bool copy_data (TPumpIntf2*, tdh_keytype);
  virtual Tpump_data2 *GetDataObj2() {return (Tpump_data2*)GetDataObj();}
  virtual void SaveStatus();
  virtual void RestoreStatus();
  };

class EXPORTPROC TPumpPtIntf2 : public TPumpPtIntf, public TBaseIntf2 {
public:
  TPumpPtIntf2 (Ttdhdata2*, TPumpIntf2*);
  virtual bool copy_data(TPumpPtIntf2*);
  };

class Temit_data2;
class EXPORTPROC TEmitIntf2 : public TEmitIntf {
protected:
  virtual Temit_data *createObj();
public:
  TEmitIntf2 (Ttdhdata2*);
  virtual long get_notecode();
  virtual void set_notecode (int);
  virtual bool copy_data (TEmitIntf2*, tdh_keytype);
  virtual Temit_data2 *GetDataObj2() {return (Temit_data2*)GetDataObj();}
  };

class Tstation_data2;
class EXPORTPROC TStationIntf2 : public TStationIntf {
protected:
  virtual Tstation_data *createObj();
public:
  TStationIntf2 (Ttdhdata2*);
  virtual long get_notecode();
  virtual void set_notecode (long);
  virtual bool copy_data (TStationIntf2*, tdh_keytype);
  virtual Tstation_data2 *GetDataObj2 () {return (Tstation_data2*)GetDataObj();}
  };

class TJunGroupData;
class EXPORTPROC TJunGroupIntf : public TBaseIntf01 <TJunGroupData, tdh_keytype>,
TBaseIntf2 {
protected:
  virtual void Delete_GroupDemands ();
  virtual void FixDeletedOwners ();
  virtual void BeforeDelete ();
  virtual TJunGroupData *createObj();
  friend class TJunctionIntf2;
public:
  TJunGroupIntf (Ttdhdata2*);
  virtual ~TJunGroupIntf();
  virtual tdh_keytype get_groupid ();
  virtual bool set_groupid (tdh_keytype);
  virtual GroupStatus get_status ();
  virtual void set_status (GroupStatus);
  virtual long get_notecode();
  virtual void set_notecode (long);
  virtual double get_demandfactor();
  virtual void set_demandfactor (double);
  virtual tdh_keytype get_owner();
  virtual void set_owner(tdh_keytype);
  virtual GroupStatus get_SolveStatus();
  virtual void set_SolveStatus (GroupStatus); //changes status after group is attached for solution
  virtual void SaveStatus();
  virtual void ResetDemandFactors(); //resets all jungroup demaand factors to 1
  virtual bool copy_data (TJunGroupIntf*, tdh_keytype);
  virtual entities GetEntType() {return etJUNGROUP;}
  virtual TJunGroupData *get_groupPtr (tdh_keytype, bool createFlag);
  };

class Tnode_data2;
class EXPORTPROC TJunctionIntf2 : public TJunctionIntf, public TBaseIntf2 {
protected:
//  Ttdhdata2 *tdhdata2;
  virtual Tnode_data *createObj();
public:
  TJunctionIntf2 (Ttdhdata2*);
  virtual FLAG get_OutputFlag ();
  virtual void set_OutputFlag (FLAG);
  virtual bool Output (); //returns output decision based on system option and junction flag
  virtual bool Output2 (basekey); //navigates to 1st param and returns Output()
  virtual tdh_keytype get_groupname ();
  virtual void set_groupname (tdh_keytype, bool = false);
  virtual char get_width();
  virtual void set_width (char);
  virtual word get_color () ;
  virtual void set_color (word);
  virtual int get_colorFlag ();
  virtual void set_colorFlag (TColorFlag_hyd);
  virtual double get_radius();
  virtual void set_radius (double);
  virtual void set_ycord (double);
  virtual void set_xcord (double);
  virtual TPointXY get_nodePt ();
  virtual void set_nodePt (TPointXY0&);
  virtual double get_QualityStart();
  virtual void set_QualityStart (double);
  virtual void setCurrent_QualityStart (double);
  virtual double get_QualitySource();
  virtual void set_QualitySource (double);
  virtual void setCurrent_QualitySource (double);
  virtual FLAG get_QualSourceType();
  virtual void set_QualSourceType (FLAG);
  virtual FLAG get_CordsModified ();
  virtual void set_CordsModified (FLAG);
  virtual long get_notecode();
  virtual void set_notecode (long);
  virtual bool copy_data (TJunctionIntf2*, tdh_keytype);
  virtual Tnode_data2 *GetDataObj2() {return (Tnode_data2*)GetDataObj();}
  virtual double CalcSolveDemand (); // basedemand + demand pts, all multiplied by applicable factors.
//  virtual TtdhDataInterfaces2 *DataIntfs2();
  };

class TDemandPtData;
class EXPORTPROC TDemandPtIntf : public TBaseIntf01 <TDemandPtData, tdh_keytype>,
TBaseIntf2 {
protected:
  TJunctionIntf2 *junIntf;
  TJunGroupIntf *groupIntf;
  virtual TDemandPtData *createObj();
public:
  TDemandPtIntf (Ttdhdata2*, TJunctionIntf2*);
  virtual ~TDemandPtIntf ();
  virtual tdh_keytype get_group ();
  virtual bool set_group (tdh_keytype);
  virtual double get_demand();
  virtual void set_demand (double);
  virtual bool copy_data (TDemandPtIntf*);
  virtual entities GetEntType() {return etDEMANDPT;}
  };

class EXPORTPROC TFgnIntf2 : public TFgnIntf {
protected:
  virtual Tnode_data *createObj();
public:
  TFgnIntf2 (Ttdhdata2*);
  virtual FLAG get_OutputFlag ();
  virtual void set_OutputFlag (FLAG);
  virtual bool Output (); //returns output decision based on system option and junction flag
  virtual tdh_keytype get_groupname ();
  virtual void set_groupname (tdh_keytype, bool) ;
  virtual char get_width();
  virtual void set_width (char);
  virtual word get_color ();
  virtual void set_color (word);
  virtual int get_colorFlag ();
  virtual void set_colorFlag (TColorFlag_hyd);
  virtual double get_radius();
  virtual void set_radius (double);
  virtual void set_ycord (double);
  virtual void set_xcord (double);
  virtual TPointXY get_nodePt ();
  virtual void set_nodePt (TPointXY0&);
  virtual double get_QualityStart();
  virtual void set_QualityStart (double);
  virtual void setCurrent_QualityStart (double);
  virtual double get_QualitySource();
  virtual void set_QualitySource (double);
  virtual void setCurrent_QualitySource (double);
  virtual FLAG get_QualSourceType();
  virtual void set_QualSourceType (FLAG);
  virtual FLAG get_CordsModified ();
  virtual void set_CordsModified (FLAG);
  virtual long get_notecode();
  virtual void set_notecode (long);
  virtual bool copy_data (TFgnIntf2*, tdh_keytype);
  virtual Tnode_data2 *GetDataObj2 () {return (Tnode_data2*)GetDataObj();}
  };

class Ttank_data2;
class EXPORTPROC TTankIntf2 : public TTankIntf {
protected:
  virtual Ttank_data *createObj();
public:
  TTankIntf2 (Ttdhdata2*);
  virtual Ttdhdata2 *get_tdhdata2() {return (Ttdhdata2*)get_tdhdata();}
  virtual double get_BulkCoeff();
  virtual void set_BulkCoeff (double);
  virtual double get_DeadVolume();
  virtual void set_DeadVolume (double);
  virtual double get_CompartmentVolume();
  virtual void set_CompartmentVolume (double);
  virtual FLAG get_MixModel();
  virtual void set_MixModel (FLAG);
  virtual long get_notecode();
  virtual void set_notecode (long);
  virtual bool copy_data (TTankIntf2*, tdh_keytype);
  virtual Ttank_data2 *GetDataObj2() {return (Ttank_data2*)GetDataObj();}
  virtual double get_DeadDepth (); // calculate depth of dead volume based on bottom diam
  };

class EXPORTPROC TTankPtIntf2 : public TTankPtIntf {
public:
  TTankPtIntf2 (Ttdhdata2*, TTankIntf2*);
  virtual bool copy_data(TTankPtIntf2*);
  };

class TChangeSetData;
class EXPORTPROC TChangeSetIntf :
public TBaseIntf01 <TChangeSetData, tdh_keytype>, public TBaseIntf2 {
protected:
//  Ttdhdata2 *tdhata2;
  virtual TChangeSetData *createObj();
public:
  TChangeSetIntf (Ttdhdata2*);
  virtual ~TChangeSetIntf ();
  virtual TNetName get_setname();
  virtual bool set_setname (TNetName);
  virtual FLAG get_AllPtsOff();
  virtual void set_AllPtsOff(FLAG);
  virtual bool get_AllControlsOff ();
  virtual void set_AllControlsOff (bool);
  virtual int get_ChanSitsBeforeSolve();
  virtual void set_ChanSitsBeforeSolve(int);
  virtual tdh_keytype get_ControlSet ();
  virtual void set_ControlSet (tdh_keytype);
  virtual long get_notecode();
  virtual void set_notecode (long);
  virtual double get_DemandFactor ();
  virtual void set_DemandFactor (double);
  virtual bool copy_data (TChangeSetIntf*, TNetName);
  virtual entities GetEntType() {return etCHANSET;}
  virtual int GetLast_SitNum ();
  virtual void set_UsePumpControls(bool);
  virtual bool get_UsePumpControls();
//  virtual TtdhDataInterfaces2 *DataIntfs2();
  };

class EXPORTPROC TChangeLabelIntf : public TLabelIntf {
protected:
//  TRecordsNav0 <Ttdhlabel, Ttdhlabel*> *queManager;
  virtual void new_data ();
public:
  TChangeLabelIntf (Ttdhdata2*, TChangeSetIntf*);
  virtual ~TChangeLabelIntf();
  virtual entities GetEntType() {return etCHANLABEL;}
  };

class Tchange_situation_data;
class EXPORTPROC TChangeSituationIntf : public TBaseIntf01 <Tchange_situation_data, int>,
TBaseIntf2 {
protected:
  changetypes currChanType;
  TChangeSetIntf *chansetIntf;
  virtual Tchange_situation_data *createObj();
  virtual void set_ChangeType (changetypes);
  friend class TChangeValueIntf;
public:
  TChangeSituationIntf (Ttdhdata2*, TChangeSetIntf*);
  virtual ~TChangeSituationIntf ();
  virtual TChangeSetIntf *ChanSetIntf () {return chansetIntf;}
  virtual int get_SituationNumber();
  virtual bool set_SituationNumber (int);
  virtual FLAG get_inactive();
  virtual void set_inactive(FLAG);
  virtual double get_DemandFactor();
  virtual void set_DemandFactor (double);
  virtual double get_EpsInterval(); //time step to be used until next situation
  virtual void set_EpsInterval(double);
  virtual double get_EpsTime(); //time when sit takes effect
  virtual void set_EpsTime(double);
  virtual long get_notecode();
  virtual void set_notecode (long);
  virtual double get_UnitCost_sys ();
  virtual void set_UnitCost_sys (double);
  virtual bool get_resetPeakKw ();
  virtual void set_resetPeakKw (bool);
  virtual void increment_sitnum (int newnum); //set current sitnum = newnum and increment other sitnum's as necessary to maintain order.
  virtual bool copy_data (TChangeSituationIntf*, int);
  virtual entities GetEntType() {return etCHANSIT;}
  virtual changetypes get_ChangeType();
  };

class Tchange_val_ptr;
class Tchange_value_data;
class TChangeValOwner;
class EXPORTPROC TChangeValueIntf : public TBaseIntf01 <Tchange_value_data, tdh_keytype>,
TBaseIntf2 {
protected:
  Tchange_val_ptr *currValPtr;
  TChangeSituationIntf *chansitIntf;
//  TChangeValOwner *valOwner;
  virtual bool new_data_wkey (tdh_keytype) {return false;} //use createChangeValue
  virtual void new_data () {} //use createChangeValue
  virtual bool new_data_wkey (changetypes, tdh_keytype);
  virtual Tchange_value_data *createObj();
public:
  TChangeValueIntf (Ttdhdata2*, TChangeSituationIntf*);
  virtual ~TChangeValueIntf ();
  virtual TChangeSituationIntf *ChanSitIntf () {return chansitIntf;}
  virtual tdh_keytype get_entityid();
  virtual bool set_entityid (tdh_keytype);
  virtual int get_index();
  virtual void set_index (int);
  virtual FLAG get_inactive();
  virtual void set_inactive(FLAG);
  virtual double get_newvalue();
  virtual void set_newvalue (double);
  virtual long get_notecode();
  virtual void set_notecode (long);
  virtual bool copy_data (TChangeValueIntf*);
  virtual entities GetEntType() {return etCHANVAL;}
  virtual changetypes get_ChangeType();
  virtual void set_ChangeType (changetypes);
  virtual bool gotoFirstChangeType (); // sets current Change Type and returns true, if a first change value exists, otherwise returns false;
  virtual bool gotoNextChangeType ();  // sets current Change Type and returns true, if another change value type exists, otherwise returns false;
  virtual Tchange_value_data *createChangeValue(changetypes, tdh_keytype, double);

  };

class TControlSetData;
class EXPORTPROC TControlSetIntf : public TBaseIntf01 <TControlSetData, tdh_keytype>,
public TBaseIntf2 {
  virtual TControlSetData *createObj();
public:
  TControlSetIntf (Ttdhdata2*);
  virtual ~TControlSetIntf ();
  virtual tdh_keytype get_setname();
  virtual bool set_setname (tdh_keytype);
  virtual bool get_active ();
  virtual void set_active (bool);
  virtual long get_notecode();
  virtual void set_notecode (long);
  virtual bool get_currActive (); //the current active state within a solution sequence
  virtual void set_currActive (bool);
  virtual bool copy_data (TControlSetIntf*, tdh_keytype);
  virtual entities GetEntType() {return etCONTROLSET;}
  };

class TRuleData;
class TtdhRulesAdmin;
class EXPORTPROC TRuleIntf : public TBaseIntf01 <TRuleData, tdh_keytype>,
TBaseIntf2 {
protected:
  TControlSetIntf *controlIntf;
  virtual tdhString ParseRule2 (tdhString*, tdhString); // used by ParseRule
  virtual TRuleData *createObj();
  friend class TtdhRulesAdmin;
public:
  TRuleIntf (Ttdhdata2*, TControlSetIntf*);
  virtual ~TRuleIntf ();
  virtual TControlSetIntf *ControlIntf() {return controlIntf;}
  virtual tdh_keytype get_ruleid ();
  virtual bool set_ruleid (tdh_keytype);
  virtual tdh_keytype get_CompositeID ();
  virtual tdh_keytype make_CompositeID (tdhString);
  virtual tdh_keytype get_ControlsID ();
  virtual bool GotoCompositeID (tdhString);
  virtual TTdhLabelStr get_ifStr ();
  virtual void set_ifStr (TTdhLabelStr);
  virtual TTdhLabelStr get_thenStr ();
  virtual void set_thenStr (TTdhLabelStr);
  virtual TTdhLabelStr get_elseStr ();
  virtual void set_elseStr (TTdhLabelStr);
  virtual int get_priority();
  virtual void set_priority (int);
  virtual bool get_active();
  virtual void set_active (bool);
  virtual bool get_currActive (); //the current active state within a solution sequence
  virtual void set_currActive (bool);
  virtual bool get_OwnerActive (); //returns the currActive value of the ControlSet
  virtual long get_notecode();
  virtual void set_notecode (long);
  virtual bool ParseRule (tdhString); //for a rule contained in one string, breaks it into If, Then, Else clauses
  virtual tdhString GetEpaRule (TtdhRulesAdmin*); //translate rule for Epanet; call TdhRules_Parse before and TdhRules_Reset after
  virtual bool copy_data (TRuleIntf*, tdh_keytype);
  virtual entities GetEntType() {return etRULE;}
  virtual void set_NextTime ();
  };

enum ruleStatusFlags {invalidAction= -2, invalidCondition, conditionFalse, conditionTrue};
class TtdhRule;

class EXPORTPROC Trule_results  :  public Ttdh_recrslts2 <TtdhRule, basekey> { //public Ttdh_recrslts <TtdhRule, tdh_keytype> {;
protected:
//  TRuleIntf *ruleIntf;
  TdhContainer *dataContainer;
  virtual TdhContainer *DataContainer () {return dataContainer;}
  virtual TtdhRule* get_rule();
public:
  Trule_results (TdhContainer*, TRecordsNav0 <TtdhRule, basekey>*);
  ~Trule_results ();
  virtual entities get_entitytype() {return etRULERSLT;}
  virtual Tsysdataref0 *SysData ();
  virtual basekey ruleid (); // a string uniquely identifying the rule within the control set to which it belongs
  virtual basekey controlid (); // the id for the control set to which the rule belongs
  virtual basekey CompositeID (); // a concatenation of the conroldid and the ruleid
  virtual short priority (); // the input priority value
  virtual bool InUse(); // the input active value
  virtual bool OwnerActive(); // the input active value
  virtual ruleStatusFlags status (); // indicates whether rule condition has been satisfied
  virtual double time(); // the most recent time the rule status changed
  virtual int day (); // the most recent day the rule status changed
  virtual double totaltime(); // the most recent totaltime (day + time) the status changed
  };

Trule_results EXPORTPROC *create_rulerslt (TdhContainer*);


class EXPORTPROC TContainer_Results {
protected:
//  TSystemResults0 *sysRslts;
//  TEpsResults0 *epsRslts;
//  Ttdhvars *tdhvars;
  TdhContainer *dataContainer;
//  virtual Ttdhvars *get_tdhvars () {return tdhvars;}
  virtual TSystemResults0 *SysRslts ();
  virtual TEpsResults0 *EpsRslts ();
public:
  TContainer_Results (TdhContainer*);
  virtual ~TContainer_Results();
  virtual TdhContainer *DataContainer ();
  virtual TtdhDataInterfaces2 *DataIntfs();
  virtual Ttdhvars *TdhVars ();
  virtual bool Fgn_Output (basekey); //returns output decision based on system option and fgn output flag
  virtual bool Jun_Output (basekey); //returns output decision based on system option and junction flag
  virtual bool Pipe_Output (basekey); //returns output decision based on system option and pipe output flag
  virtual int situation(); //the change situation number in effect;
  virtual int cycle();  //the cycle number for eps repeats
  virtual double elapsedtime(); //elapsed time since time 0 on first cycle
  virtual double CycledHours (); //elapsed time since start of current cycle
  virtual double get_nexthour (); //time for the next scheduled solution
  virtual void set_nexthour (double); //set the time for the next scheduled solution
  };

class EXPORTPROC TtdhDataInterfaces2 : public TtdhDataInterfaces {
// public functions return a TdhNet data interface
// if the 1st parameter is the default value, the default interface is returned
// if the 1st parameter is not the default value, a unique interface is returned and belongs to the caller
protected:
  virtual TSystemIntf *create_SystemIntf ();
  virtual TEpsIntf2 *create_EpsIntf2 (TChangeSetIntf*);
  virtual TJunctionIntf *create_JunIntf ();
  virtual TFgnIntf *create_FgnIntf ();
  virtual TPipeIntf *create_PipeIntf();
  virtual TPumpIntf *create_PumpIntf();
  virtual TPumpPtIntf *create_PumpPtIntf(TPumpIntf*);
  virtual TPrvIntf *create_PrvIntf();
  virtual TEmitIntf *create_EmitIntf();
  virtual TStationIntf *create_StationIntf ();
  virtual TTankIntf *create_TankIntf ();
  virtual TTankPtIntf *create_TankPtIntf (TTankIntf*);
  virtual TDemandPtIntf *create_DemandPtIntf (TJunctionIntf2*);
  virtual TJunGroupIntf *create_JunGroupIntf ();
  virtual TRuleIntf *create_RuleIntf (TControlSetIntf*);
  virtual TNoteIntf *create_NoteIntf ();
  virtual TChangeValueIntf *create_ChangeValueIntf (TChangeSituationIntf*);
  virtual TChangeSituationIntf *create_ChangeSituationIntf (TChangeSetIntf*);
  virtual TChangeSetIntf *create_ChangeSetIntf ();
  virtual TControlSetIntf *create_ControlSetIntf ();
  virtual TSysLabelIntf *create_SysLabelIntf ();
  virtual TChangeLabelIntf *create_ChangeLabelIntf (TChangeSetIntf*);

public:
  TtdhDataInterfaces2 (Ttdhdata2*);
  virtual Ttdhdata2 *TdhData2();
  virtual TSystemIntf2 *get_SystemIntf2 (bool = false);
  virtual TEpsIntf2 *get_EpsIntf2 (TChangeSetIntf* = NULL);
  virtual TEpsIntf *get_EpsIntf (bool = false);
  virtual TSysLabelIntf *get_SysLabelIntf (bool = false);
  virtual TPipeIntf2 *get_PipeIntf2 (bool = false);
  virtual TPrvIntf2 *get_PrvIntf2 (bool = false);
//THeadLossPtIntf2 EXPORTPROC *GetHeadLossPtIntf2 (Ttdhvars*, TPrvIntf2* = NULL);
  virtual TEmitIntf2 *get_EmitIntf2 (bool = false);
  virtual TPumpIntf2 *get_PumpIntf2 (bool newintf = false);
  virtual TPumpPtIntf2 *get_PumpPtIntf2 (TPumpIntf2* = NULL);
  virtual TStationIntf2 *get_StationIntf2 (bool = false);
  virtual TDemandPtIntf *get_DemandPtIntf (TJunctionIntf2* = NULL);
  virtual TJunGroupIntf *get_JunGroupIntf (bool = false);
  virtual TJunctionIntf2 *get_JunctionIntf2 (bool = false);
  virtual TFgnIntf2 *get_FgnIntf2 (bool = false);
  virtual TTankIntf2 *get_TankIntf2 (bool = false);
  virtual TTankPtIntf2 *get_TankPtIntf2 (TTankIntf2* = NULL);
  virtual TChangeSetIntf *get_ChangeSetIntf (bool = false);
  virtual TChangeSituationIntf *get_ChangeSituationIntf (TChangeSetIntf* = NULL);
  virtual TChangeValueIntf *get_ChangeValueIntf (TChangeSituationIntf* = NULL);
  virtual TChangeLabelIntf *get_ChangeLabelIntf (TChangeSetIntf* = NULL);
  virtual TControlSetIntf *get_ControlSetIntf (bool = false);
  virtual TRuleIntf *get_RuleIntf (TControlSetIntf* = NULL);
  virtual TNoteIntf *get_NoteIntf (bool = false);

  virtual TtdhDataIntf *get_IntfByType2_tdhkey (entities); //get interface using tdh_keytype by type
  virtual TBase0Intf *get_IntfByType2 (entities); //get any interface by type

  virtual void Delete_DemandPtIntf (TDemandPtIntf*); //needs to be called before the owner interface is deleted
  virtual void Delete_JunGroupIntf (TJunGroupIntf*);
  virtual void Delete_SysLabelIntf (TSysLabelIntf*);
  virtual void Delete_ChangeLabelIntf (TChangeLabelIntf*); //needs to be called before the owner interface is deleted
  virtual void Delete_NoteIntf (TNoteIntf*);
  virtual void Delete_RuleIntf (TRuleIntf*);
  virtual void Delete_ChangeValueIntf (TChangeValueIntf*); //needs to be called before the owner interface is deleted
  virtual void Delete_ChangeSituationIntf (TChangeSituationIntf*); //needs to be called before the owner interface is deleted
  virtual void Delete_ChangeSetIntf (TChangeSetIntf*);
  virtual void Delete_ControlSetIntf (TControlSetIntf*);

  virtual void reset_DemandPtIntf ();
  virtual void reset_JunGroupIntf ();
  virtual void reset_SysLabelIntf ();
  virtual void reset_ChangeLabelIntf ();
  virtual void reset_NoteIntf ();
  virtual void reset_RuleIntf ();
  virtual void reset_ChangeValueIntf ();
  virtual void reset_ChangeSituationIntf ();
  virtual void reset_ChangeSetIntf ();
  virtual void reset_ControlSetIntf ();
  };


class EXPORTPROC TCurvePt0 {
public:
  virtual double get_x () = 0;
  virtual void set_x (double) = 0;
  virtual double get_y () = 0;
  virtual void set_y (double) = 0;
  };
extern TCurvePt0 EXPORTPROC *create_CurvePt ();

typedef TRecordsNav0_min <TCurvePt0, double> TCurvePtList;

class EXPORTPROC TCurveUser {
public:
  virtual tdh_keytype UserID () = 0;
  virtual void set_UserID (tdh_keytype) = 0;
  };
extern TCurveUser EXPORTPROC *create_CurveUser();

typedef TRecordsNav0_min <TCurveUser, tdh_keytype> TCurveUserList;

class EXPORTPROC TCurve {
protected:
public:
  enum curvetypes {cuUnknown, cuPump, cuTank, cuHeadLoss, cuEfficiency,
                   ptDemFact, ptGrade, ptSpeed, ptQuality};
  curvetypes curveType;
  TCurve() {
      curveType = cuUnknown;
    }
  virtual tdh_keytype CurveID () = 0;
  virtual void set_CurveID (tdh_keytype) = 0;
  virtual TCurvePtList *PtList() = 0;
  virtual TCurveUserList *UserList() = 0;
  };
extern TCurve EXPORTPROC *create_Curve (TCurve::curvetypes);

typedef TRecordsNav0_min <TCurve, tdh_keytype> TCurveList;
extern TCurveList EXPORTPROC *create_CurveList ();


#endif
