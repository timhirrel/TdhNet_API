// Provide a class for TdhNetAPI_Demo that implements the EpaNet solution engine using the TdhNet API

#ifndef EpaDemoFuncs_Header
#define EpaDemoFuncs_Header

#include "TdhNetAPI_DemoDb.h"


class TEpaDemo : public TTdhDemo_DB {
// this class implements the EpaNet solution engine using the TdhNet API
protected:
  virtual void SetEngine();
  };


#endif // EpaDemo_Header
