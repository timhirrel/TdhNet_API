// Provides functionality for obtaining TdhNet data interfaces

#ifndef TdhDataInterface_Header
#define TdhDataInterface_Header

#include "Tdhdata01.h"

class EXPORTPROC TtdhDataInterfaces {
// public functions return a TdhNet data interface
// if the 1st parameter is the default value, the default interface is returned
// if the 1st parameter is not the default value, a unique interface is returned and belongs to the caller
protected:
  Ttdhdata *tdhdata;
  virtual TSystemIntf *create_SystemIntf ();
  virtual TEpsIntf *create_EpsIntf ();
  virtual TJunctionIntf *create_JunIntf ();
  virtual TFgnIntf *create_FgnIntf ();
  virtual TPipeIntf *create_PipeIntf();
  virtual TPumpIntf *create_PumpIntf();
  virtual TPumpPtIntf *create_PumpPtIntf(TPumpIntf*);
  virtual TPrvIntf *create_PrvIntf();
  virtual TValveDataIntf *create_ValveDataIntf ();
  virtual TValvePtIntf *create_ValvePtIntf (TValveDataIntf*);
  virtual TEmitIntf *create_EmitIntf();
  virtual TStationIntf *create_StationIntf ();
  virtual TTankIntf *create_TankIntf ();
  virtual TTankPtIntf *create_TankPtIntf (TTankIntf*);
  virtual TPressDpndcyIntf *create_PressDpndcyIntf ();
  virtual TPumpControlIntf *create_PumpControlIntf ();
public:
  TtdhDataInterfaces (Ttdhdata*);
  virtual ~TtdhDataInterfaces () {}
  virtual Ttdhdata *TdhData();
  virtual TSystemIntf *get_SystemIntf (bool = false);
  virtual TEpsIntf *get_EpsIntf (bool = false);
  virtual TPipeIntf *get_PipeIntf (bool = false);
  virtual TJunctionIntf *get_JunctionIntf (bool = false);
  virtual TFgnIntf *get_FgnIntf (bool = false);
  virtual TPrvIntf *get_PrvIntf (bool = false);
  virtual TValveDataIntf *get_ValveDataIntf (bool = false);
  virtual TValvePtIntf *get_ValvePtIntf (TValveDataIntf* = NULL);
  virtual TEmitIntf *get_EmitIntf (bool = false);
  virtual TStationIntf *get_StationIntf (bool = false);
  virtual TPumpIntf *get_PumpIntf (bool = false);
  virtual TPumpPtIntf *get_PumpPtIntf (TPumpIntf* = NULL);
  virtual TTankIntf *get_TankIntf (bool = false);
  virtual TTankPtIntf *get_TankPtIntf (TTankIntf* = NULL);
  virtual TPressDpndcyIntf *get_PressDpndcyIntf (bool = false);
  virtual TPumpControlIntf *get_PumpControlIntf (bool = false);

  virtual TtdhDataIntf* get_IntfByType_tdhkey (entities); //get interface using tdh_keytype by type
  virtual TBase0Intf *get_IntfByType (entities); //use only if Tdhdata02.h not used, otherwise use GetIntfByType2

  virtual void Delete_SystemIntf (TSystemIntf*);
  virtual void Delete_EpsIntf (TEpsIntf*);
  virtual void Delete_PipeIntf (TPipeIntf*);
  virtual void Delete_JunctionIntf (TJunctionIntf*);
  virtual void Delete_FgnIntf (TFgnIntf*);
  virtual void Delete_PrvIntf (TPrvIntf*);
  virtual void Delete_ValvePtIntf (TValvePtIntf*); //needs to be called before the owner interface is deleted
  virtual void Delete_ValveDataIntf (TValveDataIntf*);
  virtual void Delete_EmitIntf (TEmitIntf*);
  virtual void Delete_StationIntf (TStationIntf*);
  virtual void Delete_PumpIntf (TPumpIntf*);
  virtual void Delete_PumpPtIntf (TPumpPtIntf*); //needs to be called before the owner interface is deleted
  virtual void Delete_TankIntf (TTankIntf*);
  virtual void Delete_TankPtIntf (TTankPtIntf*); //needs to be called before the owner interface is deleted
  virtual void Delete_PressDpndcyIntf(TPressDpndcyIntf*);
  virtual void Delete_PumpControlIntf (TPumpControlIntf*);

  virtual void reset_SystemIntf();
  virtual void reset_EpsIntf();
  virtual void reset_PipeIntf();
  virtual void reset_FgnIntf();
  virtual void reset_JunctionIntf();
  virtual void reset_PrvIntf();
  virtual void reset_ValveDataIntf();
  virtual void reset_ValvePtIntf();
  virtual void reset_EmitIntf();
  virtual void reset_PumpIntf();
  virtual void reset_PumpPtIntf();
  virtual void reset_StationIntf();
  virtual void reset_TankIntf();
  virtual void reset_TankPtIntf();
  virtual void reset_PressDpndcyIntf();
  virtual void reset_PumpControlIntf();
  };

#endif // TdhDataInterfact_Header
