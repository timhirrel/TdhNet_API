//Provides an abstract class for the Epanet API

#ifndef EpaIntf_Header
#define EpaIntf_Header

#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <string>


#define EN_API_FLOAT_TYPE double

namespace Epanet_types {

#include "types.h"  //Epanet file
#include "epanet2_enums.h"  //Epanet file


} //namespace

typedef void (*TEpanetReportCallback)(void *userData, void *EN_projectHandle, const char*);
  // the definition for a callback function used by the Epanet API

class TEpaIntf0 {
// a class for the EpaNet interface
public:
  virtual Epanet_types::EN_Project EpaProj () = 0;
  virtual Epanet_types::EN_Project *ProjPtr () = 0;
  virtual Epanet_types::Network *EpaNet() = 0;
  virtual Epanet_types::Parser *EpaParser() = 0;
  virtual Epanet_types::Hydraul *EpaHyd() = 0;
//input
  virtual int EN_setflowunits(int units) = 0;
  virtual int EN_setoption(int option, double value) = 0;
  virtual int EN_addlink(char *id, int linkType, char *fromNode, char *toNode, int *index) = 0;
  virtual int EN_deletelink(int index, int actionCode) = 0;
  virtual int EN_setlinknodes(int index, int node1, int node2) = 0;
  virtual int EN_getlinknodes(int index, int *out_node1, int *out_node2) = 0;
  virtual int EN_setlinkvalue(int index, int property, EN_API_FLOAT_TYPE value) = 0;
  virtual int EN_setlinktype(int *inout_index, int linkType, int actionCode) = 0;
  virtual int EN_addnode(char *id, int nodeType, int *index) = 0;
  virtual int EN_setnodevalue(int index, int property, double value) = 0;
  virtual int EN_addcurve(char *id) = 0;
  virtual int EN_getcurveindex(char *id, int *index) = 0;
  virtual int EN_setcurvevalue(int curveIndex, int pointIndex, double x, double y) = 0;
//results
  virtual int EN_getcount(int object, int *count) = 0;
  virtual int EN_getlinkid(int index, char *id) = 0;
  virtual int EN_getlinkindex(char *id, int *index) = 0;
  virtual int EN_getlinktype(int index, int *linkType) = 0;
  virtual int EN_getlinkvalue(int index, int property, double *value) = 0;
  virtual int EN_getnodeid(int index, char *id) = 0;
  virtual int EN_getnodeindex(char *id, int *index) = 0;
  virtual int EN_getnodetype(int index, int *nodeType) = 0;
  virtual int EN_getnodevalue(int index, int property, double *value) = 0;
  virtual int EN_getcurvelen(int index, int *len) = 0;
//control
  virtual int EN_createproject() = 0;
  virtual int EN_close() = 0;
  virtual int EN_deleteproject() = 0;
  virtual int EN_init(const char *rptFile, const char *outFile, int unitsType, int headLossType) = 0;
  virtual int EN_openH() = 0;
  virtual int EN_initH(int initFlag) = 0;
//  virtual int EN_solveH(Epanet_types::EN_Project ph) = 0;
  virtual int EN_runH(long *currentTime) = 0;
  virtual int EN_closeH() = 0;
  virtual int EN_setreportcallback(TEpanetReportCallback) {return 0;}
  virtual int EN_setstatusreport(int level) {return 0;}
// non Epanet functions
  virtual bool set_FrictionFormula (int) = 0;
  };

extern const int idSize;

extern char* StrToPtr (std::string str);


#endif

