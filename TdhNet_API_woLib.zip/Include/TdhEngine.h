// Provides a function to use the TdhNet solution engine

// Copyright 1997-2022
// Timothy D. Hirrel, TDH Engineering
// timhirrel@tdhnet.com

#ifndef tdhengineheader
#define tdhengineheader

#include "TdhSolutionIntf.h"

EXTERNC void EXPORTPROC Use_TdhNet_Engine (Ttdhvars*);
/*
  This function sets up the solution engine API to use the TdhNet solution engine.
  This function should be called immediately after GetTdhVars().
  The processing within this function includes calling:
    1.   Ttdhvars::set_SolveControl()
    2.   Ttdhvars::set_EpsSolve()
    3.   Ttdhvars::set_AttachData()
    4.   Ttdhvars::set_ResultsClasses ()
    5.   Ttdhvars::set_FireFlow ()
    6.   Ttdhvars::set_PressDpndcy()
    7.   Ttdhvars::set_PumpSpeedControl()
*/

#endif
