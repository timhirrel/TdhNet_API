//Provides some basic functionality commonly needed in Tdh Software

#ifndef commonheader
#define commonheader

#define _USE_MATH_DEFINES
#undef __STRICT_ANSI__
#include <math.h>

#include <stdlib.h>
#include <stdio.h>
#include <cstring>

#include "ExportDef.hpp"

#include "StringDef.hpp"


const double FeetPerMile = 5280;
const double KiloFactor = 1000;
const double KiloPerMile = 1.60934;
const double FeetPerMeter = 3.28084;

#define virtzero 1e-8
#define virtinfin 1/virtzero
#define SAMEHOUR 1E-3
#define gpcf 7.481
#define CfsPerMgd 1.0/0.646358
#define CfsPerGpm 1.0/448.83;
#define PsiToFt 1/0.433
#define G_accel 9.81
EXPORT_common extern void *inspectptr;
extern void *NullPtr;


typedef bool (*NullParamProc)();
typedef void (*VoidParamProc)(void*);

#ifndef tdh_Windows
extern double EXPORTPROC sqrt(double);
#endif

extern char EXPORTPROC NoMessage (std::string);

extern bool EXPORTPROC notNumber (double);
extern bool EXPORTPROC IsNumber (std::string, int* = NULL);
extern bool EXPORTPROC IsNumber (char);
extern bool EXPORTPROC zero (double, double = virtzero);
extern bool EXPORTPROC infinity (double);
extern double EXPORTPROC max(double, double);
extern double EXPORTPROC circlearea (double radius);
extern double EXPORTPROC calcangle (double xdist, double ydist);
extern double EXPORTPROC slope_xy (double x1, double y1, double x2, double y2);
extern int EXPORTPROC rem (int num, int denom);
extern double EXPORTPROC calcdist (double xdist, double ydist);
extern double EXPORTPROC ftoi(double);
extern double EXPORTPROC sqr (double);
extern double EXPORTPROC StrToD (tdhString, int* = NULL);
extern long EXPORTPROC StrToI (tdhString, int = 10);
extern bool EXPORTPROC sameSign (double, double);
extern double EXPORTPROC sign (double);
extern int EXPORTPROC Trunc_tol (double, double = virtzero);

extern bool EXPORTPROC HasStr (std::string, std::string);
extern bool EXPORTPROC streql (const char*, const char*);
extern bool EXPORTPROC streql (std::string, std::string);
extern char EXPORTPROC *upstring(char *str);
extern std::string EXPORTPROC UpString(std::string str);
extern std::string EXPORTPROC To_Lower(std::string);
extern std::string EXPORTPROC To_Upper(std::string);
extern bool EXPORTPROC streql_nocase (std::string, std::string);
extern std::string EXPORTPROC ToIntStr(std::string);
extern tdhString EXPORTPROC FloatFmt (double val, int precParam=0, int lenParam=0);
extern tdhString EXPORTPROC IntToHexStr (unsigned, tdhString = "0x");
extern bool EXPORTPROC IsHexStr(tdhString, tdhString* = NULL);
extern int EXPORTPROC HexStrToInt(tdhString);

extern std::string EXPORTPROC GetStrField (std::string*, tdhString = ",", int=0, unsigned=0, bool=true);
extern std::string EXPORTPROC GetStrLine (std::string*);
extern char EXPORTPROC GetOneChar (std::string*);
extern std::string EXPORTPROC SubtractStr (std::string*, int, long = -1);
extern int EXPORTPROC GetIntField (std::string*, tdhString=",", int=0, int=0, int=10);
extern double EXPORTPROC GetDoubleField (std::string*, tdhString=",", int=0);
extern void EXPORTPROC AddStrField (std::string*, std::string, std::string = "");
extern std::string EXPORTPROC GetQuotedField (std::string* inStr, std::string = "\"");
extern int EXPORTPROC CountStrFields (std::string inStr, tdhString=",");
extern int EXPORTPROC GetStrFieldPos (std::string inStr, std::string fieldStr, tdhString sepch=",");
extern std::string EXPORTPROC getStrPrefix (std::string inStr);
extern int EXPORTPROC getStringIndex (TStringVector, tdhString);
extern tdhString EXPORTPROC getStringItem (TStringVector, unsigned);
extern tdhString EXPORTPROC RemoveApostrophes (tdhString);
extern tdhString EXPORTPROC RemoveStr (tdhString, tdhString);
extern tdhString EXPORTPROC MakeQuotedStr (tdhString);

extern bool EXPORTPROC zerostr (const char *strparam);
extern char EXPORTPROC numeral (char chval);


EXPORT_common extern std::string blankChars;
const char EXPORTPROC *noblank (const char*);
const char EXPORTPROC *noblank (std::string*);
std::string EXPORTPROC NoBlank (std::string);

extern std::string EXPORTPROC delete_endspaces (std::string);
extern std::string EXPORTPROC delete_leadspaces (std::string);
extern std::string EXPORTPROC delete_spaces (std::string);
extern std::wstring EXPORTPROC toWstring (std::string);
extern tdhString EXPORTPROC stringify_precision (double, unsigned);

extern bool EXPORTPROC negstr (const char*);
extern const char EXPORTPROC *sabs (const char*);
extern char EXPORTPROC alphanumcomp (const char*, const char*);


extern bool EXPORTPROC openwritefile (FILE **fileparam, tdhString filename, bool binary=false);


#endif

