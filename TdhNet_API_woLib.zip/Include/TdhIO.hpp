//Provides all the functionality used by TdhNet for file I/O

#ifndef TdhIOHeader
#define TdhIOHeader

#include "StringDef.hpp"
//#include "TdhContainer.hpp"

#define EXPORT_io
#ifdef tdh_Windows
  #define EXPORT_io __declspec(dllimport)
#endif
#ifdef TDHIO_EXPORTS
  #define EXPORT_io __declspec(dllexport)
#endif

class TUserRprt1;
class TInputSummary;
class TUserOpts;
class outprocobj;
class TRsltsCSV;
class Tfiledata;
class TdhContainer;
class TMessenger0;
class Ttdhvars;

class EXPORTPROC TTdhIO {
// file i/o for TdhNet
protected:
  TdhContainer *dataContainer;
  TUserRprt1* userRprt1;
  TInputSummary* inSumm;
  TUserOpts *userOpts;
  TRsltsCSV *resultsCSV;
  Tfiledata *fileData;
  virtual TdhContainer *DataContainer () {return dataContainer;}
  virtual Ttdhvars *TdhVars ();
  virtual outprocobj *get_OutProc (int);

  virtual Tfiledata *FileData () {return fileData;}
  virtual TUserRprt1 *UserRprt1 () {return userRprt1;}
  virtual TInputSummary *InSumm () {return inSumm;}
  virtual TRsltsCSV *ResultsCSV () {return resultsCSV;}

public:
  enum filetypes {ftUnknown, ftTdh, ftKypipes, ftEpanet, ftEpaScenario, ftDataSummary,
    ftEpaMap, ftTdhNetwork, ftTdhChanges, ftTdhControls, ftTdhDemandPts, ftTdhNotes, ftSolution, ftJunCoords,
    ftChangeSummary, ftControlSummary};

  TTdhIO (TdhContainer*, TMessenger0* = NULL);
  virtual ~TTdhIO ();

  virtual bool Ok () {return true;}
  virtual TUserOpts *UserOpts () {return userOpts;}

  //use this function for reading entire files. returns false if a problem was encountered
  virtual bool ReadFileType (tdhString, filetypes, unsigned int* = NULL);
    // 1st param is file path
    // 2nd param is the file type
    // 3rd param (optional) is a reference to an integer that will be set to the number of lines successfully read

  //use these functions for reading sections of tdh file
  virtual int OpenReadFile (tdhString, TMessenger0*); //open a specified file and set the class for messages
  virtual void CloseReadFile (); //close a file previously opened for reading
  virtual int ReadTdhData (unsigned int *numlines=NULL); // reads base data (i.e.everything except change and control data)
  virtual int ReadChanges (unsigned int *numlines=NULL);  // reads a ChangeSet
  virtual int ReadcControlSet (unsigned int *numlines=NULL); // read a ControlSet
//  virtual FLAG ReadDemandPtFile (unsigned int *numlines=NULL, bool *resetdemands=NULL); // reads a file containing demand pt data

  virtual int WriteTdhData ();
  virtual tdhString SectionName (); //returns the current section name
  virtual bool NextSection (); //advances to the next section
  virtual void ReadText (tdhString*); // return a line of text and advances to the next line

  // use this function to write a data of the specified type to the file specified by filename
  virtual void WriteFile (int filetype, tdhString filename);

  virtual void SetOutProc (int, TMessenger0*, int pglenparam = 0); //sets the callback function for handling some output from the library, use NULL for default file output

  // use this function to write a data file of the specified type, output set to callback function specified by TdhIO_SetOutProc
  virtual void WriteData (int filetype, bool);

  // use these functions for writing a results report, output sent to callback function specified by TdhIO_SetOutProc
  virtual void WriteLine (char*); // writes specified text in the report
  virtual void WriteTitle (); // writes a report title
  virtual void WriteSimulation (); // writes the results for the latest solution
  virtual void WriteSolutionSummary (); //write summary data for the solution sequence
  virtual void WriteInputSummary(tdhString chanset_name = "");
  virtual void RecordCountSummary ();

  // use these functions to write text to a file; can be used in conjunction with TdhIO_SetOutProc to send output to a file
  virtual int OpenWriteFile (tdhString filename); //open a file for writing
  virtual void CloseWriteFile (); //close a file previously opened for writing
  virtual void WriteText (tdhString text); // write to file the text contained in 1st parameter

  virtual void WriteResultsCSV (tdhString fileroot); //write results for FGNs, Junctions and Pipes in csv format
  virtual void WriteJunCordsCSV (tdhString);

  virtual tdhString *GetSourceTypeStrs(int *maxparam); //returns array of strings for quality source types, first param returns # of strings

  virtual void WriteTdhNetwork (); //write the base network data in a TdhNet file format
  virtual void WriteTdhChanges (int=1, tdhString="");  //write the change data in a TdhNet file format
  virtual void WriteControls (int=1, tdhString=""); //write the control data in s TdhNet file format
  virtual void WriteNotes (); //write notes in a TdhNet file format

  virtual void WriteEpaFile(); //write all data in a Epanet file format
  virtual void WriteEpaMapFile(); //write map data in a Epanet file format
  virtual void WriteEpaScenario(); //write scenario data in a Epanet file format
  };

TTdhIO EXPORTPROC *TdhIO_StartUp (TdhContainer*, TMessenger0*);
  //returns a TTdhIO instance that uses the TdhContainer specified by the 1st param.

#endif
