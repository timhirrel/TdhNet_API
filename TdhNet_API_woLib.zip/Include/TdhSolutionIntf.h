// A set of interfaces for the TdhNet solution engine:
// - allowing the solution engine to access input data
// - controlling the solution process
// - allowing the access of solution results

#ifndef TDHSOLUTIONINTF_H_INCLUDED
#define TDHSOLUTIONINTF_H_INCLUDED

#include "tdhdefs.hpp"
#include "RecordsNav0.h"

#define EXPORT_solveIntf
#ifdef tdh_Windows
#define EXPORT_solveIntf __declspec(dllimport)
#endif
#ifdef SOLVEINTF_EXPORTS
#define EXPORT_solveIntf __declspec(dllexport)
#endif


class Tsysdataref0;
class TTdhDataCheck;
class TSystemResults0;

// Solution Control Classes

class EXPORTPROC TdhSolveControl0 {
// implements hydraulic solutions
protected:
    Ttdhvars *tdhvars;
    debugstate debugState;
    int runNumber, simNumber;
    TTdhDataCheck *dataChecker;
    solution_stats solveStatusX;
//    TSystemResults0 *sysRslts;
    virtual Ttdhvars *TdhVars () {
        return tdhvars;}
    virtual TTdhDataCheck *DataChecker () {
        return dataChecker;}
    virtual TSystemResults0 *SysRslts();
public:
    TdhSolveControl0 (Ttdhvars*);
    virtual ~TdhSolveControl0 () {}
// these functions return 0 if successful, greater then 0 if there is a problem
    virtual int StartUp() {return 0;} //= 0; //initializes the solution engine
    virtual int SequenceInit(bool = true); //prepares engine for a solution sequence, calls DataInit if 1st param is true. this implementation should be called by the overriding implementation.
    virtual solution_stats SolveOne(int = 0); //performs one solution, 1st param can set initial iterations to some value other than 0. increments simNumber. this implementation should be called by the overriding implementation.
    virtual int ResetSolve (); //to prepare for a new solution sequence
    virtual int DataCheck (); //checks attached data, reports errors & warnings
    virtual char DataInit (bool) {return 0;}
    //sets pointers for related data entities (e.g. pipes to pumps & prvs); called by SequenceInit
    //call during solution sequence if new pipes are added (does not reset change data)
    // if 1st param = true, flows are set to 0

    virtual char SetTankFlows() {return 0; }   //call after solution and before EpsDriver
    virtual char EpsDriver () {return 0;}   //performs eps calcs (e.g. tank volume changes), called after moddriver
    virtual char EnergyCalcs() {return 0;}   //perform energy calculations for pumps and stations

// these functions set a new value = 1st parameter if it is not default. they return the current value after any update
    virtual debugstate DebugState (debugstate debugval=dsNoChange); //if param > -2, sets the debug state, default state = 0, 1 reports detailed solution info; returns current debug state. see enum debugstatus
    virtual bool DebugMessages(); //return true if DebugState() = dsSolveInfo
// return values or as explained
    virtual void ListPaths (int) {} //list elements in a path, use 0 for all paths;
    virtual void set_NoCheckFlag (bool flagval) {} //no data check, when flag = true
    virtual solution_stats SolveStatus (); // returns status of latest solution attempt
    virtual void set_SolveStatus (solution_stats); // set solveStatus
    virtual int Iterations () {return 0;} //= 0; //returns the number of iterations performed for the most recent soluation
    virtual bool NegPressureCheck(); //returns true if one or more junctions have negative pressure and demand greater than 0.
    virtual void PrepareForTraverse() {} //called with modinit, call separately only if topology changes during a solution sequence
    virtual char AnotherEps () {return 0;}   //returns whether eps requires another solution
    virtual void InitNextTime () {} // set initial value for next time
    virtual void TankTimeLimit () {} // modify next time based on tank limits
    virtual void BalanceNodes () {} // using current demands and pipe flows, balance the flow at every node
    virtual void RemovePrvs () {} //removes prvs, as needed by the Quality engine
    virtual void RestorePrvs () {} //restore prvs
    virtual void set_RunNumber (); //sets runNumber and initializes simNumber. called by SequenceInit
    virtual int RunNumber () {return runNumber;}
    virtual int SimulationNumber () {return simNumber;}
};


class EXPORTPROC TEpsSolve0 {
// implements eps functionality
protected:
public:
    virtual ~TEpsSolve0 () {}
    virtual bool SequenceInit_eps () = 0; //to be called before a solution sequence
    virtual void SetTankFlows () = 0; //sets tank flows to be used in EpsDriver (call immediately after solution to allow for fire flow analyses that won't affect tank levels)
    virtual void InitNextTime () {} // set initial value for next time. called after solution (SolveOne())
    virtual void TankTimeLimit () {} // modify next time based on tank limits. call after InitNextTime()
    virtual char EpsDriver () {return 0;}   //performs eps calcs (e.g. tank volume changes). called after TankTimeLimit()
    virtual char AnotherEps () {return 0;}   //returns whether eps requires another solution
    virtual double CurrentTime () = 0; //returns the current eps time
    virtual void set_CurrentTime (double) = 0; //sets the current eps time
    virtual double NextTime () = 0; //returns the next eps time (called after TankTimeLimit())
    virtual void AdjNextTime (double) = 0; //sets the next eps time
    virtual double TimeStep() = 0; // the difference between CurrentTime() and NextTime()
    virtual void Reset () = 0; // resets data used within TEpsSolve
    virtual char PumpEnergyUse () = 0; //returns true if pump energy calculations are performed
//    virtual double MaxTankChange () {return 0;} // returns the value returned Tsysdataref0::MaxTankChange()
};

class EXPORTPROC TPumpSpeedControl0 {
// implements pump speed controls
public:
    virtual ~TPumpSpeedControl0 () {}
    virtual double FindSpeed (tdh_keytype, tdh_keytype, double, double, double, double) = 0;
      // set the speed for a specified pump to maintain a specified hg at a specified junction node within a specified tolerance
      // param1 = pumpid, paraem2 = nodeid, pararm3 = specfified hg, param4 = tolerance, parem5 = max speed, parem6 = min speed
      // if min speed < 0 then a required speed < abs(min speed) will cause the pump to be shut down
      // returns calculated speed
};

class TPressDpndcyRef0;
class TtdhSolve_PressDpndt0 {
// implements pressure dependent demands
protected:
public:
  virtual ~TtdhSolve_PressDpndt0() {}
  virtual bool SequenceInit() = 0; // to be called at beginning of solution sequence. returns true if no error.
  virtual bool SolveInit() = 0; // to be called before each solution. return true if no error.
  virtual bool AfterSolve() = 0; // to be called after a solution. returns true if a demand is adjusted.
  virtual bool AccuracyOk () = 0; //return results of most recent call to AfterSolve()
  virtual bool AddDpndcy (TPressDpndcyRef0*) = 0; //adds a pressure dependency
  virtual bool DeleteDpndcy (basekey) = 0; //deletes a pressure dependency having an id = 1st parameter
  virtual void deletePressDpndys () = 0; //deletes all pressure dependencies
  };

//Input Data Access Classes

class EXPORTPROC TUnitsRef {
// unit conversion factors and other global data
protected:
    double qconver, dconver, powerconver, densconver, volconver, volconver2;
    double lossexpon, g2_, losscoef2, slope, losscoef, powerconver2, pressconver, minpumpflow;
    fricformulas fricform;
    double kinvis;
    Tsysdataref0 *sysData;
public:
    TUnitsRef (Tsysdataref0 *sysParam);
    virtual ~TUnitsRef () {}
    virtual double Q_conver() {return qconver; }  //factor to convert flow units to cfs or cms (the flow units used internally)
    virtual double Diam_conver() {return dconver;}   //factor to convert diameters to inches or mm (the diameter units used internally)
    virtual double Power_conver() {return powerconver;}   //factor to convert power to ft*lbs/s or kwh (the power units used internally)
    virtual double Power_conver2() {return powerconver2;}   //factor convert power to kwh (used in pump cost calcs)
    virtual double Dens_conver() {return densconver;}   //specific gravity * g
    virtual double Vol_conver() {return volconver;}   //factor to convert volume to million gallons or million cubic meters (the volume units used internally)
    virtual double Vol_conver2() {return volconver2;}   //factor to convert volume to million gallons or million liters (the volume units reported)
    virtual double LossExpon() {return lossexpon;}   // exponent applied to friction formula
    virtual double g2() {return g2_;}   // g*2
    virtual double LossCoef() {return losscoef;}   //coefficient applied to friction formula
    virtual double LossCoef2() {return losscoef2;}   // multiplied by flow to obtain the slope of friction
    virtual double Press_conver() {return pressconver;}   //factor to convert pressure to psi or meters (the pressure units reported)
    virtual double Kinvis () {return kinvis;}   //returns sysdata.kinvis * 1e-6 (the kinvis used internally)
    virtual double MinPumpFlow () {return minpumpflow;}
    virtual bool SI_flag(); // returns true if flow units are si
    virtual void SetUnits (); //default function for setting conversion factors
    virtual fricformulas FrictionFormula () {return fricform;}
    virtual Tsysdataref0 *SysData () {return sysData;}
}; //unistrec

// the ref classes allow the solution engine to reference input data.
// each class needs (at least) one non abstract definition that is instantiated for each data record
// see the TdhNet app user documentation for descriptions of the data fields
// the set functions are intended to allow changes to input data that is in effect only for the duration of a solution sequence

class EXPORTPROC Tsysdataref0 {
public:
    virtual ~Tsysdataref0 () {}
    virtual flowunits FlowUnits() = 0; //units of flow, see enum flowunits in tdhdefs.hpp
    virtual TUnitsRef *Units() = 0;
    virtual int maxtri() = 0; // maximum number of iterations for a solution
    virtual fricformulas fricform () = 0; // the friction formula used for pipes
    virtual char epsflag () = 0; // flag indicating whether a extended period simulation is performed
    virtual double relacc() = 0; // required accuracy (change in flow between iterations) for a solution to be considered accurate
    virtual double errorLimit () = 0; // maximum error (difference between calculated and target energy loss along a path) for a solution to be considered accurate
    virtual double spgrav() = 0; // the specific gravity of the fluid being modeled
    virtual double kinvis() = 0; // the kinematic viscosity of the fluid being modeled
    virtual double interval() = 0; // the default interval for between solutions in an eps
    virtual double starttime() = 0; // the start time for an eps
    virtual double endtime() = 0; // the end time for an eps
    virtual double UnitCost_sys () = 0; // the default unit energy cost, used in a pumping cost analysis
    virtual bool ResetPeakKw () = 0; // resets the peak kw for all components of a pumping cost analysis (pumps, stations, system)
    virtual double MaxTankChange() = 0; //if > 0, the maximum water level change (ft or m) allowed between solutions of an eps. applied to all tanks unless a tank specifies a different value.
//    virtual TResetFlowModes ResetFlows () = 0; // returns the value that determines when flows are set to 0
    virtual RelaxModes RelaxMode () = 0; //returns the value that determines when the energy gradient is relaxed (set to a value not based on flow)
    virtual double ChkVlvFactor () {return 10;}   //pipe flow change factor before a check valve status is changed
    virtual bool ResetVlvs () {return false;}   //opens all check valves between solutions, if true
};

class EXPORTPROC Tnoderef0 {
protected:
    bool hide;
public:
    Tnoderef0 () {
      hide = false;
      }
    virtual ~Tnoderef0 () {}
    virtual basekey nodeid () = 0; // returns node identifier
    virtual bool IsFgn () = 0; // returns true if node is a fixed grade node
    virtual double demand () = 0; // returns node demand
    virtual double elev () = 0; // returns node elevation for junctions; water elevation for fgns
    virtual basekey JunGroup () = 0; // returns the group identifier, if the node belongs to a group
    virtual void set_Demand (double) {} //set the demand for the duration of a solution sequence
    virtual void set_Elev (double) {} //set the elevation for the duration of a solution sequence
    virtual bool Hide () {return hide;}    // returns Hide attribute
    virtual void set_Hide (bool val) {hide = val;} // sets Hide attribute
};

class EXPORTPROC Tpumpptref0 {
public:
    virtual ~Tpumpptref0 () {}
    virtual double flow () = 0; // returns pump pt flow
    virtual double tdh () = 0; // returns pump pt tdh
    virtual double eff () = 0; // returns pump pt efficiency
    virtual double get_x() {return flow();}
    virtual double get_y() {return tdh();}
};

typedef TRecordsNav0_min <Tpumpptref0, double> TRecordsNav_pumpPt;

class EXPORTPROC Tpumpref0
{
public:
    virtual ~Tpumpref0 () {}
    virtual basekey pumpid () = 0; // returns pump identifier
    virtual basekey pipekey () = 0; // returns id of pipe to which the pump belongs
    virtual basekey station () = 0; // returns id of station to the pump belongs
    virtual pumptypes pumptype () = 0; // returns pump type
    virtual double power () = 0; // returns power for a constant power pump
    virtual double npshr () = 0; // returns net positive suction head required (ft or m)
    virtual double speed () = 0; // returns pump speed
    virtual void set_Power (double) = 0; //sets current power
    virtual void set_Speed (double) = 0; //sets current speed
    virtual bool Hide () {return false;} // returns hide attribute, see API documentation, Results
    virtual void set_Hide (bool) {} // sets hide attribute
    virtual TRecordsNav_pumpPt *Nav_PumpPts () = 0; // Navigation of a set of TValvePtRef's, ascending x.
//these functions have defaults, as used in the TdhNet app, provided in the class Tpiperef_hyd defined in TdhHydUtils2.h
//if userUnits = true, flow units are user specified.
//otherwise, units for flow parameters are cfs or cms, depending in whether user specified flow units are SI
    virtual void SequenceInit () {} //processing that needs to be done at the start of a solution sequence
    virtual void SolveInit() {} // processing that needs to be done before each solution
    virtual double CalcPumpHead (double, bool relax=false, bool userUnits =false) = 0; //calculate pump head given flow; 1st param = flow, 2nd param = relax (see RelaxMode)
    virtual double CalcPumpFlow (double, bool userUnits=false) = 0; //calculate flow given head; 1st param = tdh (ft or m)
    virtual double CalcPumpPrime (double, bool = false, bool userUnits=false) = 0; //calculate slope of pump head vs. flow; 1st param = flow
    virtual double CalcEfficiency (double, bool userUnits=false) = 0; //calculate efficiency vs. flow; 1st param = flow
    virtual double CalcPowerOutput (double, bool userUnits=false) {return 0;}   //calculates power vs. flow; 1st param = flow
    virtual double CalcSpeed (double, double, double, bool userUnits=false) {return 1;}   //calculates speed to produce a performance point; 1st param = flow, 2nd param  = tdh (ft or m),, 3rd param required tdh agreement
    virtual void HeadRange (double*, double*) {} //calculate max (1st param) and min (2nd param) heads,
    virtual double MaxFlow (bool userUnits = false) {return 0;}   //return highest flow in Pump Pts, adjusted for speed
    virtual bool OutOfRange (double, bool userUnits=false) {return false;}   //determine is flow is out of range, 1st param = flow
};


class EXPORTPROC TValvePtRef0
{
public:
    virtual ~TValvePtRef0 () {}
    virtual double flow () = 0; //returns valve pt flow or valve pt elevation (for float valves)
    virtual double headloss () = 0; //return valve pt headloss or valve pt amount open (for float valves)
    virtual double get_x() {
      return flow();
      }
    virtual double get_y() {
      return headloss();
      }
};

class TTankResults0;
class TPipeResults0;
typedef TRecordsNav0_min <TValvePtRef0, double> TRecordsNav_valvePt;

class EXPORTPROC Tprvref0 {
protected:
public:
    virtual TRecordsNav_valvePt *Nav_ValvePts () = 0; // Navigation of a set of TValvePtRef's, ascending x.
    virtual ~Tprvref0 () {}
    virtual basekey prvid () = 0; //returns valve identifier
    virtual basekey pipekey () = 0; // returns id of pipe to which the valve belongs
    virtual prvtypes prvtype () = 0; //returns valve type
    virtual double prvgrade () = 0; // returns valve setting; hydraulic grade for reducing and relief valves, flow for flow control valves
    virtual char Active () {return true;} // returns true if valve is active
    virtual double Cv () {return 10;} // returns Cv for throttling and float valves
    virtual double Exp () {return 0.5;} // returns exponent for throttling and float valves
    virtual double AmountOpen () {return 1;} // returns amount open for throttling an float valves (0=closed, 1= full open)
    virtual tdh_keytype TankID (TTankResults0*) {return "";}   //return the tank id for a float valve, if 1st is not NULL, will find a tank if connected to valve pipe
    virtual void set_AmountOpen (double) {} //sets the current open
    virtual void set_Grade (double) {} //sets the current valve setting
    virtual bool Hide () {return false;} //returns the Hide attribute
    virtual void set_Hide (bool) {} // sets the Hide attribute
//these functions have defaults, as used in the TdhNet app, provided in the class Tpiperef_hyd defined in TdhHydUtils2.h
//units for flow parameters are cfs or cms, depending in whether user specified flow units are SI
//  virtual double CurrentOpen() = 0; //amount open parameter that can change during a solution sequence without affecting the original amount open
    virtual double ValveLoss (double, bool) = 0; //calculate head loss vs. flow; 1st param = flow, 2nd param - relax (see RelaxMode)
    virtual double ValvePrime (double, bool) = 0; //calculate slope of head loss vs. flow; 1st param = flow, 2nd param - relax (see RelaxMode)
    virtual double ValveLoss_adjUnits (double) = 0; //calc valve loss from user defined flow units
    virtual void ThrottleToMinor (TPipeResults0*) {} //allows epanet to use tdhnet throttling valves
};


class EXPORTPROC Ttankptref0 {
protected:
public:
    double slope, vol;
    Ttankptref0 () {
      slope = 0;
      vol = 0;
      }
    virtual ~Ttankptref0 () {}
    virtual double level () = 0; // returns tank pt level (height above tank minimum elevation)
    virtual double diam () = 0; // returns tank pt diameter
    virtual double get_x() {return level();}
    virtual double get_y() {return diam();}
};

typedef TRecordsNav0_min <Ttankptref0, double> TRecordsNav_tankPt;

class EXPORTPROC Ttankref0 {
public:
    virtual ~Ttankref0 () {}
    virtual basekey tankid () = 0; // returns tank identifier
    virtual basekey nodekey () = 0; // returns id of fgn to which the tank belongs
    virtual double maxelev () = 0; // returns maximum water elevation for tank
    virtual double minelev () = 0; // returns minimum (usable) water elevation for tank
    virtual double MaxChange () = 0; // returns maximum amount water can change between solutions (triggering a new solution before the next scheduled solution)
    virtual bool AllowOverFlow () = 0; // if true, the tank will overflow if it has reached its max elevation
    virtual double CalcVolume (double) = 0; //return volume at grade = 1st param, in cubic feet or cubic meters
    virtual double CalcGrade (double) = 0; // return grade at volume = 1st param, in cubic feet or cubic meters
    virtual double FullVolume () = 0; // returns the tank volume when at max elevaion
    virtual TRecordsNav_tankPt *Nav_TankPts () = 0; // Navigation of a set of Ttankptref's, ascending x.
    virtual bool Hide () {return false;} // returns Hide attribute
    virtual void set_Hide (bool) {} // sets Hide attribute
};



class EXPORTPROC Tstationref0 {
public:
    virtual ~Tstationref0 () {}
    virtual basekey stationid () = 0; // returns station identifiier
    virtual basekey component1 () = 0; // returns id of station 1 in station relationship (parallel or series)
    virtual basekey component2 () = 0; // returns id of station 2 in station relationship
    virtual stationtypes stationtype () = 0; // returns station type
    virtual double unitcost () = 0; // return unit energy cost for station
    virtual void set_UnitCost (double) {} // sets current unit cost for station
    virtual bool Hide () {return false;} // returns Hide attribute
    virtual void set_Hide (bool) {} // sets Hide attribute
};

class EXPORTPROC Temitref0 {
public:
    virtual ~Temitref0() {}
    virtual basekey emitid () = 0; //returns emitter identifier
    virtual basekey nodekey () = 0; // returns id for node to which the emitter belongs
    virtual double coef () = 0; // returns emitter coefficient
    virtual double diam () = 0; // return emitter diameter (has no effect on hydraulics)
    virtual double exp () = 0; // returns emitter exponent
    virtual void set_Coef (double) {} // sets current coefficient for emitter
    virtual bool Hide (){return false;} // returns Hide attribute
    virtual void set_Hide (bool) {} // sets Hide attribute
};

class EXPORTPROC TPressDpndcyRef0 {
public:
    virtual ~TPressDpndcyRef0 () {}
    virtual basekey PressDpndcyID () = 0; // returns pressure dependency identifier
    virtual double PressFullQ () = 0; // returns the minimum pressure at which full demand is supplied
    virtual double PressNoQ () = 0; // returns the pressure below which no demand is supplied
    virtual double Pressure_Tolerance () = 0; // returns the required agreement between the calculated pressure and pressure corresponding to the supplied demand
    virtual double PressHigh () = 0; // returns the pressure above which demand increases above full demand
    virtual double SlopeHigh () = 0; // returns the rate at which demand increases above full demand
    virtual basekey JunGroup () = 0; // returns the junction group to which the pressure dependency applies. if blank, dependency applies to all junctions.
};

class EXPORTPROC Tpiperef0 {
protected:
    bool hide;

public:
    Tpiperef0 () {
        hide = false;
    }
    virtual ~Tpiperef0 () {}
    virtual basekey PipeId () = 0; // returns the pipe identifier
    virtual basekey NodeA () = 0; // returns the id for node A
    virtual basekey NodeB () = 0; // returns the id for node B
    virtual solvestatus Status () = 0; // returns the pipe status
    virtual chkvlvTypes ChkVlv () = 0; // returns the check valve type
    virtual char FgnFlag () = 0; // returns the fgn flag; 0 = no fgn, 1 = nodeA, 2 = nodeB
    virtual double Length () = 0; // returns the pipe length
    virtual double Diam () = 0; // returns the pipe diameter
    virtual double Roughness () = 0; // returns the pipe roughness
    virtual double Minor () = 0; // returns the minor loss coefficient

    virtual void set_PipeId (basekey) {} //sets the pipeid
    virtual void set_NodeA (basekey) {} // sets the id for nodeA
    virtual void set_NodeB (basekey) {} //sets the id for nodeB
    virtual void set_FgnFlag (char) {} // set the fgn flag
    virtual void set_ChkVlv (chkvlvTypes) {} // sets the check valve type
    virtual void set_Status (solvestatus) {} // sets the open/closed status
    virtual void set_Length (double) {} //sets the pipe length
    virtual void set_Diam (double) {} // sets the pipe diameter
    virtual void set_Roughness (double) {} //sets the pipe roughness
    virtual void set_Minor (double) {} //sets the pipe minor loss coefficient
    virtual void CopyData_from(Tpiperef0*); // copies the pipe data to a different Tpiperef


//these functions have defaults, as used in the TdhNet app, provided in the class Tpiperef_hyd defined in TdhHydUtils2.h
    virtual double PipeLoss (double, bool) {return 0;}   //calculates head loss vs. flow
    virtual double PipePrime (double, bool) {return 0;}   //calculates slope of head loss vs. flow
    virtual void SolveInit () {} //prepares pipe for head loss calculations
    virtual double FricLoss (double, bool, fricformulas) {return 0;}   //calculates friction loss vs. flow
    virtual void CalcKval (fricformulas) {} //prepares pipe for friction loss calculation
    virtual double MinorLoss (double) {return 0;}   //calculates minor loss vs. flow
    virtual double Velocity (double) {return 0;}   //calculate velocity vs flow
    virtual double CalcArea () {return 0;}   //calculates area
    virtual double PumpHead (Tpumpref0*, double, bool) {return 0;}   //calculates pump head vs. flow
    virtual double EmitLoss (Temitref0*, double, bool) {return 0;}   //calculates emitter loss vs. flow

    virtual Tpumpref0 *PumpRef () {return NULL;} //returns the Tpumpref associated with the pipe or NULL
    virtual Tprvref0 *PrvRef () {return NULL;} //returns the Tprvref associated with the pipe or NULL
    virtual Temitref0 *EmitRef () {return NULL;} // returns the Temitref associated with the pipe or NULL
    virtual void set_PrvRef (Tprvref0*) {} //sets the Tprvref associated with the pipe
    virtual void set_PumpRef (Tpumpref0*) {} //sets the Tpumpref associated with the pipe
    virtual void set_EmitRef (Temitref0*) {} //sets the Temitref associated with the pipe

    virtual bool Hide () {return hide;}  // returns Hide attribute
    virtual void set_Hide (bool val) {hide = val;} // sets Hide attribute
};

extern Tsysdataref0 *sysData_def;

class EXPORTPROC TAttachData0 {
protected:
    Tsysdataref0 *sysdata;
    Ttdhvars *tdhvars;
public:
    TAttachData0 (Ttdhvars*);
    virtual ~TAttachData0 () {}
    virtual Ttdhvars *TdhVars () {
        return tdhvars;
    }
    virtual bool Attach_Sys (Tsysdataref0*) = 0; //attaches a Tsysdataref
    virtual Tsysdataref0 *SysData (); //returns the attached Tsysdataref
    virtual bool Attach_Pipe (Tpiperef0*) = 0; //attaches a Tpiperef
    virtual bool Attach_Jun (Tnoderef0*) = 0; //attaches a Tnoderef as a junction
    virtual bool Attach_Fgn (Tnoderef0*) = 0; //attaches a Tnoderef as a fgn
    virtual bool Attach_Pump (Tpumpref0*) = 0;  //attaches a Tpumpref
    virtual bool Attach_PumpPt (Tpumpptref0*, basekey) = 0;  //attaches a Tpumppteref, 2nd param = pump ID
    virtual bool Attach_Prv (Tprvref0*) = 0;  //attaches a Tprveref
    virtual bool Attach_ValvePt (TValvePtRef0*, basekey) = 0;  //attaches a TValvePtRef, 2nd param = valve ID
    virtual bool Attach_Tank (Ttankref0*) = 0; //attaches a Ttankref
    virtual bool Attach_TankPt (Ttankptref0*, basekey) = 0;  //attaches a Ttankref, 2nd param = tank ID
    virtual bool Attach_Station (Tstationref0*) = 0; //attaches a Tstationref
    virtual bool Attach_Emit (Temitref0*) = 0; //attaches a Temitref
    virtual bool Attach_All () {return true;} //attaches all the data needed by the solution engine
    virtual bool Attach_Other () {return true;} //called by Attach_All to perform any additional processing

    virtual bool UnAttach_Pipe (basekey) = 0; //unattaches a pipe with id = 1st param
    virtual bool UnAttach_Jun (basekey) = 0; //unattaches a junction with id = 1st param
    virtual bool UnAttach_Fgn (basekey) = 0; //unattaches a fgn with id = 1st param
    virtual bool UnAttach_Pump (basekey) = 0; //unattaches a pump with id = 1st param
    virtual bool UnAttach_PumpPt (double, basekey) {return false;} //unattaches a pumpt with flow = 1st param, 2nd param = pump ID
    virtual bool UnAttach_Prv (basekey) = 0; //unattaches a prv with id = 1st param
    virtual bool UnAttach_ValveDataPt (double, basekey) {return false;} //unattaches a valvept with flow = 1st param, 2nd param = valve ID
    virtual bool UnAttach_Tank (basekey) = 0; //unattaches a tank with id = 1st param
    virtual bool UnAttach_TankPt (double, basekey) {return false;} //unattaches a tankpt with level = 1st param, 2nd param = tank ID
    virtual bool UnAttach_Station (basekey) = 0; //unattaches a station with id = 1st param
    virtual bool UnAttach_Emit (basekey) = 0; //unattaches an emitter with id = 1st param
    virtual bool UnAttach_All (); //unattaches all data
    virtual bool UnAttach_Other () {return true;} //called by UnAttach_All to perform additional processing
};


//Results Classes

class EXPORTPROC Ttdh_results2 {
protected:
    Ttdhvars *tdhvars;
    TEngineTypes engineType; // the engine type being used at the time the results instance was created
    virtual Ttdhvars *TdhVars () {
        return tdhvars;}
public:
    Ttdh_results2 (Ttdhvars*);
    virtual ~Ttdh_results2 () {}
    virtual entities get_entitytype() {
        return etNONE;}
    virtual Tsysdataref0 *SysData (); //returns the attached Tsysdataref
    virtual TUnitsRef *Units () { //returns the attached TUnitsRef
        return SysData()->Units();}
    virtual bool NeedsReset(); //indicates that this results instance is no longer valid, possibly because a different solution engine is being used
};

class EXPORTPROC TSystemResults0 : public Ttdh_results2 {
protected:
public:
    TSystemResults0 (Ttdhvars *tdhParam) : Ttdh_results2 (tdhParam) {}
    virtual entities get_entitytype() {
        return etSYSTEMRSlT;
    }
    virtual solution_stats solution_status (); // returns the status of the most recent solution attempt
    virtual double total_demand () = 0; //returns the total demand
    virtual double solution_accuracy () = 0; //returns the accuracy (flow convergence)
    virtual double solution_patherror () = 0; //return the path error
    virtual bool AccuracyOk (); // returns false if the solution accuracy is greater than the required accuracy
    virtual int iterations () = 0; //returns the number of iteration performed during the solution
    virtual bool epsflag () = 0; //return true if an extended period analysis is being performed
    virtual int run_number (); //valid default function
    virtual int simulation_number (); //valid default function
    virtual void set_Accuracy (double) = 0; //sets the required accuracy for the solution sequence
    virtual void set_PathError (double) = 0; //sets the maximum path error for the solution sequence
};

class EXPORTPROC TEpsResults0 : public Ttdh_results2 {
protected:
public:
    TEpsResults0 (Ttdhvars *tdhParam) : Ttdh_results2 (tdhParam) {}
    virtual entities get_entitytype() {
        return etEpsRslt;
    }
    virtual double current_time () = 0; //returns the current time within a cycle, hours
    virtual void set_CurrentTime (double) = 0; //sets the current time
    virtual double next_time () = 0; // returns the next solution time, hours, valid after epsdriver
    virtual void set_nexttime(double) = 0; //sets the next solution time, hours, valid before epsdriver
    virtual double time_step () = 0; // returns the current time step, in seconds, valid after epsdriver
    virtual double total_tank_volume () = 0; //returns the total volume currently within all tanks
};


template <class objtype, class keytype> class EXPORTPROC Ttdh_recrslts2 : public Ttdh_results2 {
protected:
    TRecordsNav0 <objtype, keytype> *resultsNav;
public:
    Ttdh_recrslts2 (Ttdhvars *tdhParam, TRecordsNav0 <objtype, keytype> *navParam) :
        Ttdh_results2 (tdhParam) {
        resultsNav = navParam;
    }
    virtual ~Ttdh_recrslts2() {
        delete resultsNav;
    }
    virtual TRecordsNav0 <objtype, keytype> *Nav () {return resultsNav;}
    virtual bool DataExists () {return Nav()->DataExists();} //returns true if the navigator has at least one record
    virtual objtype* GetData () {return Nav()->GetData();} //returns the current record
    virtual void SetData (objtype *dataParam) {Nav()->SetData(dataParam);} //sets the current record to the 1st param
    virtual keytype GetKey () {return Nav()->GetKey();} //returns the key value of the current record
    virtual bool GotoRec(keytype reckey) {return Nav()->GotoRec(reckey);} //sets the current record the record with key value = 1st param, if it exists
    virtual bool GotoNear(keytype reckey) {return Nav()->GotoNear(reckey);} //sets the current record the record with with greatest key value no greater than 1st param
    virtual bool GotoFirst() {return Nav()->GotoFirst();} //sets the current record the record with the lowest key value
    virtual bool GotoNext() {return Nav()->GotoNext();} //sets the current record to the record after the current record
    virtual bool GotoLast() {return Nav()->GotoLast();} //sets the current record to the record with the greatest key value
    virtual bool GotoPrev() {return Nav()->GotoPrev();} //sets the current record to the record before the current record
    virtual unsigned long get_RecNum(){return Nav()->get_RecNum();} //returns the record number for the current record
    virtual unsigned long get_Count() {return Nav()->get_Count();} //returns the number of records
    virtual bool AtFirst() {return Nav()->AtFirst();} //returns true if the current record is the first record
    virtual bool AtLast() {return Nav()->AtLast();} //returns true if the current is the last record
};

class TNodeResults_source;
typedef TRecordsNav0 <TNodeResults_source, basekey> TResultsNav0_node;
class EXPORTPROC TNodeResults0 : public Ttdh_recrslts2 <TNodeResults_source, basekey> {
protected:
public:
    TNodeResults0 (Ttdhvars *tdhParam, TResultsNav0_node *navParam) :
        Ttdh_recrslts2 <TNodeResults_source, basekey> (tdhParam, navParam) {}
    virtual ~TNodeResults0 () {}
//  virtual basekey getkey() {return nodeid();}
    virtual bool IsFgn() = 0; //returns true if the current node is a fgn
    virtual basekey nodeid () = 0; //returns the id for the current node
    virtual double grade () = 0; //returns the calculated hydraulic grade for the current node
    virtual double demand () = 0; //returns the current demand for the current node
    virtual solvestatus status () = 0; // returns ssIsolated if the node is not connected to a fgn; else returns ssOpen
    virtual double pressure () = 0; //returns the calculated pressure (psi or m)
    virtual double inflow() = 0; //the total flow into the node
    virtual double NetFlow() = 0; //the flow leaving (+) or entering (-) the network
    virtual basekey emitterid () = 0; //returns the emitter id if the node has an emitter, else returns blank
    virtual double adjacentgrade () = 0; //used for tanks, the grade at the other node of the (first) connecting pipe
    virtual double qprime (){return 0;} //returns the calculated gradient back to the starting fgn
    virtual void set_Status (solvestatus) {} //sets the current status (for restoring saved results)
    virtual void set_Demand (double) = 0; //set the current demand
//    virtual double DemandFactor() {return 1;}
//    virtual void set_DemandFactor(double) {}
    virtual void set_Grade (double) = 0; //set the calculated grade
    virtual bool GotoPipe (basekey) = 0; //set current pipe to 1st param
    virtual bool GotoFirstPipe() = 0; //set current pipe to first connected pipe
    virtual bool GotoNextPipe() = 0; //set current pipe to next connected pipe
    virtual basekey pipeid() = 0; // return pipeid of current pipe
    virtual basekey connect_nodeid () = 0; //return nodeid for other node of current pipe
    virtual nodetypes connect_nodetype () = 0; //return 1 if connected node of current pipe is fgn
    virtual Tnoderef0 *get_noderef () = 0; //returns the Tnoderef associated with the current results
    virtual void set_Elev(double) = 0; //set the input elev for the simulation
};


class TPipeResults_source;
typedef TRecordsNav0 <TPipeResults_source, basekey> TResultsNav0_pipe;
class EXPORTPROC TPipeResults0 : public Ttdh_recrslts2 <TPipeResults_source, basekey> {
protected:
public:
    TPipeResults0 (Ttdhvars *tdhParam, TResultsNav0_pipe *navParam) :
        Ttdh_recrslts2 <TPipeResults_source, basekey> (tdhParam, navParam) {}
    virtual ~TPipeResults0 () {}
    virtual entities get_entitytype() {return etPIPERSLT;}
//  virtual basekey getkey() {return pipeid();}
    virtual basekey pipeid () = 0; //returns the id for the current pipe
    virtual TNodeResults0 *NodeA () = 0; //returns the id for nodeA of the current pipe
    virtual TNodeResults0 *NodeB () = 0; //returns the id for nodeB of the current pipe
    virtual char fgnflag() = 0; //returns the fgn flag for the current pipe
    virtual solvestatus Status () = 0; //returns the solve statue for the current pipe (see solvestatus in tdhdefs.hpp)
    virtual double flow() = 0; //returns calculated flow for the current pipe
    virtual double fricloss () = 0;  //returns calculated friction loss for the current pipe
    virtual double gradient() = 0; //returns gradient (friction loss / legnth *1000) for the current pipe
    virtual double minorloss () = 0; //returns the calculated minor loss for the current pipe
    virtual double velocity () = 0; //returns the calculated velocity for the current pipe
    virtual double pumphead () = 0; //returns the calculated pump head for the current pipe, if the pipe has a pump; else return 0
    virtual basekey pumpid() = 0; // returns the id for the pump associated with the current pipe, or NULL
    virtual basekey prvid() = 0; //returns the id for the prv associated with the current pipe, or NULL
    virtual Tpiperef0 *get_piperef() = 0; // returns the Tpiperef associated with the current pipe
    virtual void set_Status (solvestatus) = 0; //set the input open/closed value for the solution sequence
    virtual void set_NodeA (basekey) {}  //set the id for nodeA for the solution sequence
    virtual void set_NodeB (basekey) {} //set the id for nodeB for the solution sequence
    virtual void set_Length (double) {} //set the pipe length for the solution sequence
    virtual void set_Diam (double) {} //set the pipe diameter for the solution sequence
    virtual void set_Roughness (double) {} //set the pipe roughness for the solution sequence
    virtual void set_Minor (double) {} //set the pipe minor loss coefficient for the solution sequence
    virtual void set_ChkVlv (chkvlvTypes) = 0; //change the input chkvlv value without affecting original value
    virtual void set_Flow (double) {} //set the flow for the current pipe (for restoring saved results)
    virtual void set_SolveStatus (solvestatus) = 0; //set the solve open/closed status  (for restoring saved results)
    virtual void set_ChkVlvStatus (chkvlvStatusFlags) = 0; //set the solved check valve status (for restoring saved results)
};

class TPumpResults_source;
typedef TRecordsNav0 <TPumpResults_source, basekey> TResultsNav0_pump;
class EXPORTPROC TPumpResults0 : public Ttdh_recrslts2 <TPumpResults_source, basekey> {
protected:
public:
    TPumpResults0 (Ttdhvars *tdhParam, TResultsNav0_pump *navParam) :
        Ttdh_recrslts2 <TPumpResults_source, basekey> (tdhParam, navParam) {}
    virtual ~TPumpResults0 () {}
    virtual entities get_entitytype() {return etPUMPRSLT; }
//  virtual basekey getkey() {return pumpid();}
    virtual basekey pumpid () = 0; //returns the id for the current pump
    virtual solvestatus Status() = 0; //returns the solution status for the current pump
    virtual basekey pipekey () = 0; //returns the id for the pump to which the pump belongs
    virtual bool GotoPump(basekey pipeid) = 0; //sets the current pump to the pump belonging to the pipe with id = 1st param
    virtual pumptypes pumptype () = 0; //returns pump type for current pump
    virtual double speed () = 0; //returns speed for current pump
    virtual double pumphead () = 0; //returns calculated head for current pump
    virtual double flow () = 0; //returns calculated flow for current pump
    virtual double power () = 0; //returns calculated hydraulic power for current pump
    virtual double efficiency() = 0; //returns calculated efficiency for current pump
    virtual char OutOfRange () = 0; //returns true if flow > than greatest pump pt flow
    virtual char cavatation () = 0; // returns true if suction grade is less than npshr
    virtual double downgrade() = 0; // returns calculated hydraulic grade at pump's downstream node
    virtual void set_Speed (double) = 0; //sets pump speed for solution sequence
    virtual void set_Power (double) = 0; // sets pump power for solution sequence, for constant power pumps
    virtual Tpumpref0 *get_pumpref() = 0; //return Tpumpref associated with current pump
//  virtual void set_CurrentSpeed (double) = 0;
};

class TPrvResults_source;
typedef TRecordsNav0 <TPrvResults_source, basekey> TResultsNav0_prv;
class EXPORTPROC TPrvResults0: public Ttdh_recrslts2 <TPrvResults_source, basekey> {
protected:
public:
    TPrvResults0  (Ttdhvars *tdhParam, TResultsNav0_prv *navParam) :
        Ttdh_recrslts2 <TPrvResults_source, basekey> (tdhParam, navParam) {}
    virtual ~TPrvResults0() {}
    virtual entities get_entitytype() {return etPRVRSLT;}
//  virtual basekey getkey() {return prvid();}
    virtual basekey prvid () = 0; //returns the id for the current valve
    virtual basekey pipekey () = 0; //returns the id for the pipe to which the current valve belongs
    virtual basekey nodekey () = 0; //returns the id for the node where the valve is located
    virtual solvestatus status () = 0; //returns the solve status for the current valve
    virtual char connected () = 0; //returns flagYes if valve is connected properly and functioning normally, else returns flagNo
    virtual prvtypes prvtype () = 0; //returns valve type
    virtual double flow () = 0; // returns calculated flow for current pipe
    virtual double HeadLoss() = 0; //returns calculated head loss for current pipe
    virtual double prvgrade () = 0; //returns current valve setting
    virtual double upgrade () = 0; //returns calculated hydraulic grade at upstream node of valve
    virtual double downgrade() = 0; //returns calculated hydraulic grade at downstream node of valve
    virtual double CurrentOpen(); // returns the current amount open for valve
    virtual Tprvref0 *get_prvref() = 0; //returns the Tprvref associated with current valve
    virtual void set_Status (solvestatus) = 0; //set solve status for current valve (for restoring saved results)
    virtual void set_Grade (double) {} //sets the valve setting for the solution sequence
    virtual void set_AmountOpen (double) {} //sets the amount open for the solution sequence
};

class TTankResults_source;
typedef TRecordsNav0 <TTankResults_source, basekey> TResultsNav0_tank;
class EXPORTPROC TTankResults0 : public Ttdh_recrslts2 <TTankResults_source, basekey> {
protected:
public:
    TTankResults0 (Ttdhvars *tdhParam, TResultsNav0_tank *navParam) :
        Ttdh_recrslts2 <TTankResults_source, basekey> (tdhParam, navParam) {}
    virtual ~TTankResults0() {}
    virtual entities get_entitytype() {return etTANKRSLT;}
//  virtual basekey getkey() {return tankid();}
    virtual basekey tankid () = 0; //return id for current tank
    virtual basekey nodekey () = 0; //returns id for fgn to which current tank belongs
    virtual tankstatus status () = 0; //returns calculated solve status for current tank (see tankstatus in tdhdefs.hpp)
    virtual double tankflow () = 0; // returns calculated flow for current tank, > 0 = filling, < 0 = depleting
    virtual double Elev() = 0; // returns current water elevation for tank
    virtual double adjacentgrade () = 0; //returns the calculated hydraulic grade at the adjacent node for the pipe connecting to a tank
    virtual double current_volume () = 0; //returns the current water volume in the tank
    virtual double involume () = 0; //returns the total volume into the tank over the solution sequence
    virtual double outvolume () = 0; //return the total volume out of the tank over the solution sequence
    virtual double CalcVolume (double) = 0; //returns the volume (MG or ML) for the tank a the water elevation = 1st param
    virtual double CalcElev (double) = 0; //returns the elevation for the tank corresponding to a volume (MG or ML) = 1st param
    virtual double FillTime() = 0; // returns the time needed to fill the tank based on current water elevation and flow
    virtual double DrainTime() = 0; // returns the time needed to empty the tank based on current water elevation and flow
    virtual Ttankref0 *get_tankref() = 0; //returns the Ttankref associated with the current tank
    virtual bool GotoNode (basekey) = 0; // sets the current tank to the tank associated with the node where id = 1st param
    virtual void set_Elev (double) = 0; //sets the current water elevation for the tank
    virtual void set_Flow (double) = 0; //sets the current flow for the tank
    virtual void AdjUpperLimit (double) = 0; //sets the upper limit the tank may reach before the next solution, if < current limit
    virtual void AdjLowerLimit (double) = 0; //sets the limit limit the tank may reach before the next solution, if > current limit
};

class TEmitterResults_source;
typedef TRecordsNav0 <TEmitterResults_source, basekey> TResultsNav0_emit;
class EXPORTPROC TEmitterResults0 : public Ttdh_recrslts2 <TEmitterResults_source, basekey> {
protected:
public:
    TEmitterResults0 (Ttdhvars *tdhParam, TResultsNav0_emit *navParam) :
        Ttdh_recrslts2 <TEmitterResults_source, basekey> (tdhParam, navParam) {}
    virtual ~TEmitterResults0() {}
    virtual entities get_entitytype() {return etEMITRSLT;}
    virtual basekey emitterid () = 0; //returns the id for the current emitter
    virtual basekey nodekey () = 0; //returns the id for the node to which the current emitter belongs
    virtual basekey pipekey () = 0; //returns the id for the pipe to which the current emitter belongs
    virtual double flow() = 0; //returns the calculated flow for the emitter
    virtual double loss() = 0; //returns the calculated loss for the emitter
    virtual double velocity() = 0; //returns the calculated velocity for the emitter
    virtual Temitref0 *EmitRef() = 0; //returns the Temitref associated with the emitter
    virtual void set_Coef (double) {} //set the emitter coefficient for the solution sequence
};

class TStationResults_source;
typedef TRecordsNav0 <TStationResults_source, basekey> TResultsNav0_station;
class EXPORTPROC TStationResults0: public Ttdh_recrslts2 <TStationResults_source, basekey> {
protected:
public:
    TStationResults0 (Ttdhvars *tdhParam, TResultsNav0_station *navParam) :
        Ttdh_recrslts2 <TStationResults_source, basekey> (tdhParam, navParam) {}
    virtual ~TStationResults0() {}
    virtual entities get_entitytype() {return etSTATIONRSLT;}
    virtual basekey stationid () = 0; //returns the id for the current station
    virtual basekey component1 () = 0;  //returns the stations id for component 1 of the current station
    virtual basekey component2 () = 0; //returns the stations id for component 2 of the current station
    virtual stationtypes station_type() = 0; //returns the type for the current station
    virtual double flow () = 0; //returns the calculated flow for the station
    virtual double UnitCost() = 0; //return the current unit energy cost for the station
    virtual void set_UnitCost (double val) {get_stationref()->set_UnitCost(val);} //sets the unit energy cost for the solution sequence
    virtual Tstationref0 *get_stationref () = 0; //returns the Tstationref associated with the current station
};

class EXPORTPROC TPumpCostResults_source;
typedef TRecordsNav0 <TPumpCostResults_source, basekey> TResultsNav0_cost;
class EXPORTPROC TPumpCostResults0 : public Ttdh_recrslts2 <TPumpCostResults_source, basekey> {
protected:
public:
    TPumpCostResults0 (Ttdhvars *tdhParam, TResultsNav0_cost *navParam) :
        Ttdh_recrslts2 <TPumpCostResults_source, basekey> (tdhParam, navParam) {}
    virtual ~TPumpCostResults0 () {}
    virtual entities get_entitytype() {return etCOSTRSLT;}
    virtual basekey pumpid() = 0; //returns id for the current pump
    virtual bool valid () = 0; //returns false if the energy calculation for the current component are not valid (e.g. efficiency data is not available)
    virtual double flow () = 0; //returns the calculated flow the current component
    virtual double hydpower () = 0; //returns the calculated hydraulic power for the current component
    virtual double hydenergy () = 0; //returns cumulative hydraulic energy for the current component
    virtual double elecpower () = 0; //returns the calculated current electrical power for the current component
    virtual double elecenergy () = 0; //returns the cumulative electrical energy for the current component
    virtual double peak_elecpower () = 0; //returns the peak electrical power thus far in the solution sequence for the current component
    virtual double pumpcost () = 0; //return the cumulative cost for the current component
    virtual double pumpvolume () = 0;  //returns the cumulative volume pumped for the current component
    virtual double pumphours () = 0; //returns the cumulative time the current component has been operating
    virtual double cost_per_volume () = 0; //return the current cost per volume for the current component
    virtual void setenergy_system () = 0; //sets the current component to the system energy
    virtual bool setenergy_station () = 0; //sets the current component to the current station
    virtual bool setenergy_pump () = 0; //sets the current component to the current pump
    virtual void set_Valid (bool) = 0; //sets the valid value (for restoring saved results)
    virtual void set_Flow (double) = 0; // set the current flow
    virtual void set_HydPower (double) = 0; //sets the current hydraulic power
    virtual void set_HydEnergy (double) = 0; //sets the current hydraulic energy
    virtual void set_ElecPower (double) = 0; //sets the current electrical power
    virtual void set_ElecEnergy (double) = 0; //sets the current electrical energy
    virtual void set_PeakElecPower (double) = 0; //sets the peak electrical power
    virtual void set_Cost (double) = 0; //sets the cumulative cost
    virtual void set_Volume (double) = 0; //sets the cumulative volume pumped
    virtual void set_CostPerVol (double) = 0;  //sets the current cost per volume
    virtual void set_Hours (double) = 0; //sets the cumulative time of operation
};


class EXPORTPROC TResultsClasses0 {
protected:
    Ttdhvars *tdhvars;
    TSystemResults0 *sysRslts;
    TEpsResults0 *epsRslts;
    TPipeResults0 *pipeRslts;
    TNodeResults0 *junRslts;
    TNodeResults0 *fgnRslts;
    TPumpResults0 *pumpRslts;
    TPrvResults0 *prvRslts;
    TEmitterResults0 *emitRslts;
    TTankResults0 *tankRslts;
    TStationResults0 *stationRslts;
    TPumpCostResults0 *pumpcostRslts;

    virtual TSystemResults0 *get_SystemResults() = 0;
    virtual TEpsResults0 *get_EpsResults() = 0;
    virtual TPipeResults0 *get_PipeResults () = 0;
    virtual TNodeResults0 *get_JunctionResults () = 0;
    virtual TNodeResults0 *get_FgnResults () = 0;
    virtual TPumpResults0 *get_PumpResults () = 0;
    virtual TPrvResults0 *get_PrvResults () = 0;
    virtual TEmitterResults0 *get_EmitterResults () = 0;
    virtual TTankResults0 *get_TankResults () = 0;
    virtual TStationResults0 *get_StationResults () = 0;
    virtual TPumpCostResults0 *get_PumpCostResults (TStationResults0*) = 0;

public:
    TResultsClasses0 (Ttdhvars*);
    virtual ~TResultsClasses0();
    virtual Ttdhvars *TdhVars () {return tdhvars;}
    virtual bool RsltOk (Ttdh_results2*);

    // if the 1st parameter is false (or NULL) a default value is returned; it should not be deleted
    // if the 1st parameter is true (or not NULL) a unique value is returned; it should be deleted when no longer needed
    virtual TSystemResults0 *SystemRslts(bool=false); //returns a system results instance
    virtual TEpsResults0 *EpsRslts(bool=false); //returns an eps results instance
    virtual TPipeResults0 *PipeRslts (bool=false); // returns a pipe results instance
    virtual TNodeResults0 *JunRslts(bool=false); //returns a junction results instance
    virtual TNodeResults0 *FgnRslts(bool=false); //returns a fgn results instance
    virtual TPumpResults0 *PumpRslts(bool=false); //returns a pump results instance
    virtual TPrvResults0 *PrvRslts(bool=false); //returns a valve results instance
    virtual TEmitterResults0 *EmitRslts(bool=false); //returns an emitter results instance
    virtual TTankResults0 *TankRslts(bool=false); //returns a tank results instance
    virtual TStationResults0 *StationRslts(bool=false); //returns a station results instance
    virtual TPumpCostResults0 *PumpCostRslts(TStationResults0* =NULL); //returns a pump cost results instance

};

extern double EXPORTPROC PumpPtPower_KW (double tdh, double flow, TUnitsRef *units); //returns the hydraulic power for the pump pt specified in the parameters

class EXPORTPROC TdhFireFlow0 {
protected:
    Ttdhvars *tdhvars;
    virtual Ttdhvars *TdhVars () {
      return tdhvars;
      }
public:
    TdhFireFlow0 (Ttdhvars *tdhParam){
      tdhvars = tdhParam;
      }
    virtual ~TdhFireFlow0  () {}
    virtual bool CalcFlow (tdh_keytype, double, double*) = 0;
      // calculates the pressure at a node with a specified fire flow
      // 1st param = node id, 2nd param = fire flow, 3rd param - set to calculated pressure
      // returns false if there is problem (e.g. node doesn't exist)
    virtual bool CalcPressure (tdh_keytype, double, double*) = 0;
      // calculates the fire flow at a node with a specified residual pressure
      // 1st param = node id, 2nd param = residual pressure, 3rd param - set to calculated flow
      // returns false if there is a problem (e.g. TdhFireFlow::SequenceInit not called)
    virtual void SequenceInit() = 0; //prepares for fire flow analyses at the beginning of a solution sequence
};


#endif // TDHSOLUTIONINTF_H_INCLUDED
