#include "ExportDef.hpp"

class TdhContainer;
class TEpaIntf0;
EXTERNC TEpaIntf0 EXPORTPROC *Create_EpaToTdh (TdhContainer*);
