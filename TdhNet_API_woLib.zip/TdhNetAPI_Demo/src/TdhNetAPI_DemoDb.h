// Provides for database I/O for the TdhNet Demo

#ifndef TdhNetAPIDemoDb_Header
#define TdhNetAPIDemoDb_Header

#include "TdhNetAPI_DemoFuncs.h"
//#include "TdhSql_IO.h"
//#include "uiUtils_generic.h"

class TdhSql_netIO;

class TTdhDemo_DB : public TTdhDemo {
// this class implements sqlite database i/o for input data and solution results
// TdhnetData.sqlite and TdhnetResults.sqlite must exist in a directory 'TdhNet_StructPath' and be compatible with the current program version
protected:
  TdhSql_netIO *TdhnetSql_IO;
  virtual bool InitDB();
  virtual void SaveNetToDB ();
  virtual void GetNetFromDB ();
  virtual void SaveResultsToDB ();
  virtual void GetResultsFromDB ();
public:
  virtual void Main();
  };


#endif // TdhNetAPIDemoDb_Header

