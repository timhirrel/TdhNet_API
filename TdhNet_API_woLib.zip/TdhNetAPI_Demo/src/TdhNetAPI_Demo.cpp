/*
This is a very simple program to demonstrate the Tdhnet API
Sucessful compilation and linking of this program requires:
  - the source code files in the cpp directory TdhDemo.zip file
  - the header files in the Include directory of the TdhNet_API.zip file
  - the executable libraries for a specific compiler in the TdhNet_API.zip file

  The program is intended to be run as a console app
  It reads a file, net1.inp, in Epanet format (this file must be in the program directory)
  writes some input data to the console
  executes a single hydraulic solution and writes some results to the console
*/

#include "TdhNetAPI_DemoFuncs.h"
#include "TdhNetAPI_DemoDb.h"  //comment this line if this functionality is not needed
#include "EpaDemo_funcs.h"  //comment this line if this functionality is not needed
#include "EpaToTdhDemo_funcs.h"  //comment this line if this functionality is not needed

#include <iostream>

int main() {
//  TTdhDemo tdhDemo; //comment this line to implement other versions
//  TTdhDemo_DB tdhDemo; //uncomment this line to implement this version
  TEpaDemo tdhDemo; //uncomment this line to implement this version
//  TEpaToTdhDemo tdhDemo; //uncomment this line to implement this version
//  TEpaToEpaDemo tdhDemo; //uncomment this line to implement this version
  tdhDemo.Main();
  std::cout << "hit any key to exit...";
  std::cin.get();
  return 0;
  }
