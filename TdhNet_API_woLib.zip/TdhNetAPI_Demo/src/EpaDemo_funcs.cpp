#include "EpaEngine.h"
#include "EpaDemo_funcs.h"


void TEpaDemo::SetEngine () {
  Use_EpaNet_Engine(tdhvars, get_EpaIntf(Messenger_Epa()));
  }

