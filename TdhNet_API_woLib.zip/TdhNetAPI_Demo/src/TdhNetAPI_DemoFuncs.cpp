
#include "TdhNetAPI_DemoFuncs.h"
#include "TdhIO.hpp"
#include "TdhSolutionIntf.h"
#include "Tdhdata02.h"
#include "TdhEngine.h"


TMessenger0 *messenger_DemoApi = &messenger_console;


void TTdhDemo::GetFile () {
//read an input file, in Epanet format
  unsigned int numLines = 0;
  tdhIO->ReadFileType("net1.inp", TTdhIO::ftEpanet, &numLines);
  }

void TTdhDemo::WriteDiameters () {
//write the pipe id and diameter for every pipe
  std::cout << "Pipe ID, Diameter" << std::endl;
  TPipeIntf2 *pipeintf = dataContainer->DataIntfs()->get_PipeIntf2();
  bool goflag = pipeintf->GotoFirst();
  while (goflag) {
	std::cout << pipeintf->get_pipeid() << ", " << pipeintf->get_diameter() << std::endl;
	goflag = pipeintf->GotoNext();
	}
  }

void TTdhDemo::AttachData () {
  dataContainer->AttachData("");
  }

void TTdhDemo::Solve () {
// execute a single hydraulic solution
// for an EPS solution sequence, solveControl->SolveOne() would be repeated while solveControl->AnotherEPS() == true
  solveControl->SequenceInit(true);
  solveControl->SolveOne();
  TSystemResults0 *sysRslts = tdhvars->ResultsClasses()->SystemRslts();
  std::cout <<  "Total Demand: " << sysRslts->total_demand() << std::endl;
  }

void TTdhDemo::WriteFlows () {
// write the pipe id and flow (in the user specified units) for every pipe
  TPipeResults0 *piperslt = tdhvars->ResultsClasses()->PipeRslts();
  piperslt->Nav()->set_Hide(true);
  std::cout << "Pipe ID, Flow" << std::endl;
  bool goflag = piperslt->GotoFirst();
  while (goflag) {
	std::cout << piperslt->pipeid() << ", " << piperslt->flow() << std::endl;
	goflag = piperslt->GotoNext();
	}
  }

void TTdhDemo::Init () {
// initialize TdhnetAPI
  tdhvars = GetTdhVars (messenger_DemoApi);
  SetEngine();
  dataContainer = get_TdhContainer(tdhvars);
  tdhIO = TdhIO_StartUp(dataContainer, messenger_DemoApi);
  solveControl = tdhvars->SolveControl();
  solveControl->StartUp();
  }

void TTdhDemo::SetEngine () {
  Use_TdhNet_Engine(tdhvars);
  }

void TTdhDemo::Main () {
  Init();
  GetFile();
  AttachData();
  WriteDiameters();
  Solve();
  WriteFlows();
  }

