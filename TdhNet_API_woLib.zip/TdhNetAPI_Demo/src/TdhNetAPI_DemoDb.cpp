/*
To use the database functions:
  The TdhNet_Structure directory (containing sqlite database files)
  must be in the execution directory
  (or change the value of the structPath variable in InitDB to a different directory)
*/

#include "TdhNetAPI_DemoDb.h"
#include "TdhSql_IO.h"


bool TTdhDemo_DB::InitDB() {
// initialize database parameters
  tdhString execPath = "./";
#ifdef tdh_Windows
  execPath = ".\\";
#endif
  std::string structPath = execPath + "Tdhnet_Structure";
  std::string dataPath = execPath + "Tdhnet_Data";
  //TdhnetData.sqlite and TdhnetResults.sqlite must exist in a directory structPath and be compatible with the current program version
  TdhnetSql_IO = new TdhSql_netIO(dataContainer, structPath);
  return TdhnetSql_IO->SetDB(dataPath);
  }

void TTdhDemo_DB::SaveNetToDB () {
//set network name and save to database
  dataContainer->DataIntfs()->get_SystemIntf2()->set_netname("Net1");
  TdhnetSql_IO->SaveNetwork();
  }

void TTdhDemo_DB::GetNetFromDB () {
//retrieve network from database
  TdhnetSql_IO->getNetwork(TdhnetSql_IO->getNetworkCode("Net1"));
  }

void TTdhDemo_DB::SaveResultsToDB () {
//save results to database using scratch run and situation numbers (will overwrite any previously saved scratch results)
  TdhnetSql_IO->SaveResults(lfScratchRun);
  }

void TTdhDemo_DB::GetResultsFromDB () {
//retrieve saved scratch results
  TdhnetSql_IO->getResults(TdhnetSql_IO->getNetworkCode("Net1"), 1, -1);
  }

void TTdhDemo_DB::Main () {
  TTdhDemo::Main();
  if (InitDB()) {
    SaveNetToDB();
    GetNetFromDB();
    SaveResultsToDB();
    GetResultsFromDB();
    }
}

