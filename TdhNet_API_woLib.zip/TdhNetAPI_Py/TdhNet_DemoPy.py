
# these classes demonstrate the TdhNet API using python
# the TdhNet API can be used to implement either the TdhNet or EpaNet hydraulic solution engine
# the library libTdhNet_DemoPy.so must be avialable for either solution engine
# the library libEpaAttach.so must be available for the EpaNet solution engine
# the library libSqlLite.so must be available for database i/o

from ctypes import *
import os
import sys

TdhNet = CDLL("./libTdhNetIntf_Py.so") # uncomment this line for linux
#TdhNet = cdll.LoadLibrary("./TdhNetIntf_Py.dll") # uncomment this line for msWin


def C_Str(py_string):
    return c_char_p(py_string.encode('utf-8'))

def Set_TdhNetCFuncs ():
# set the restype and argtypes for the C++ functions providing the python interface
  TdhNet.GetTdhVars_py.restype = c_void_p
  TdhNet.get_TdhContainer_py.restype = c_void_p
  TdhNet.get_TdhContainer_py.argtypes = [c_void_p]
  TdhNet.Use_TdhNet_Engine_py.argtypes = [c_void_p]
  TdhNet.TdhIO_StartUp_py.restype = c_void_p
  TdhNet.TdhIO_StartUp_py.argtypes = [c_void_p]
  TdhNet.tdhfile_readfiletype_py.restype = c_bool
  TdhNet.tdhfile_readfiletype_py.argtypes = [c_void_p, c_char_p, c_int]
  TdhNet.BaseIntf_GotoFirst_py.restype = c_bool
  TdhNet.BaseIntf_GotoFirst_py.argtypes = [c_void_p]
  TdhNet.BaseIntf_GotoNext_py.restype = c_bool
  TdhNet.BaseIntf_GotoNext_py.argtypes = [c_void_p]
  TdhNet.GetPipeIntf_py.argtypes = [c_void_p]
  TdhNet.PipeIntf_PipeID_py.restype = c_char_p
  TdhNet.PipeIntf_PipeID_py.argtypes = [c_void_p]
  TdhNet.PipeIntf_Diameter_py.restype = c_double;
  TdhNet.PipeIntf_Diameter_py.argtypes = [c_void_p]
  TdhNet.TdhSystemResult_Create_py.restype = c_void_p
  TdhNet.TdhSystemResult_Create_py.argtypes = [c_void_p]
  TdhNet.SysRslts_total_demand_py.restype = c_double
  TdhNet.SysRslts_total_demand_py.argtypes = [c_void_p]
  TdhNet.BaseRslt_GotoFirst_py.restype = c_bool
  TdhNet.BaseRslt_GotoFirst_py.argtypes = [c_void_p]
  TdhNet.BaseRslt_GotoNext_py.restype = c_bool
  TdhNet.BaseRslt_GotoNext_py.argtypes = [c_void_p]
  TdhNet.TdhPipeResult_Create_py.restype = c_void_p
  TdhNet.TdhPipeResult_Create_py.argtypes = [c_void_p]
  TdhNet.PipeRslt_PipeID_py.restype = c_char_p
  TdhNet.PipeRslt_PipeID_py.argtypes = [c_void_p]
  TdhNet.PipeRslt_Flow_py.restype = c_double
  TdhNet.PipeRslt_Flow_py.argtypes = [c_void_p]
  TdhNet.GetPipeIntf_py.restype = c_void_p
  TdhNet.Get_TdhSolveControl_py.restype = c_void_p
  TdhNet.Get_TdhSolveControl_py.argtypes = [c_void_p]
  TdhNet.TdhSolve_StartUp_py.argtypes = [c_void_p]
  TdhNet.TdhSolve_SequenceInit_py.argtypes  = [c_void_p, c_bool] 
  TdhNet.TdhSolve_SolveOne_py.argtypes = [c_void_p, c_int]
  TdhNet.TdhSolve_AttachData_py.restype = c_void_p
  TdhNet.TdhSolve_AttachData_py.argtypes = [c_void_p, c_char_p]
  TdhNet.GetSql_netIO_py.argtypes = [c_void_p, c_char_p]
  TdhNet.GetSql_netIO_py.restype = c_void_p
  TdhNet.Sql_IO_SetDB_py.argtypes = [c_void_p, c_char_p]
  TdhNet.Sql_IO_SetDB_py.restype = c_char
  TdhNet.SaveNetToDB_py.argtypes = [c_void_p, c_char_p]
  TdhNet.GetNetFromDB_py.argtypes = [c_void_p, c_char_p]
  TdhNet.SaveResultsToDB_py.argtypes = [c_void_p, c_int]
  TdhNet.GetResultsFromDB_py.argtypes = [c_void_p, c_char_p]
  TdhNet.get_EpaIntf_py.restype = c_void_p
  TdhNet.Use_EpaNet_Engine_py.argtypes = [c_void_p, c_void_p]
  TdhNet.Create_EpaToTdh_py.restype = c_void_p
  TdhNet.Create_EpaToTdh_py.argtypes = [c_void_p]
  TdhNet.EN_init_py.argtypes = [c_void_p, c_char_p, c_char_p, c_int, c_int]
  TdhNet.EN_getcount_py.argtypes = [c_void_p, c_int, POINTER(c_int)]
  TdhNet.EN_getlinkid_py.argtypes = [c_void_p, c_int, POINTER(c_char_p)]
  TdhNet.EN_getlinkvalue_py.argtypes = [c_void_p, c_int, c_int, POINTER(c_double)]
  TdhNet.EN_initH_py.argtypes = [c_void_p, c_int]
  TdhNet.EN_runH_py.argtypes = [c_void_p, POINTER(c_long)]

class TTdhNet_Demo_py:
# this class implements the TdhNet solution engine using the TdhNet API

  def Main (self):
  # program structure  
    self.Init(self)
    self.GetFile(self) 
    self.AttachData(self)
    self.WriteDiameters(self)
    self.Solve(self)
    self.WriteFlows(self)

  def Init (self):
  #initialize the API  
    self.tdhvars = TdhNet.GetTdhVars_py()
    self.SetEngine(self)
    self.tdhContainer = TdhNet.get_TdhContainer_py(self.tdhvars)
    self.tdhIO = TdhNet.TdhIO_StartUp_py (self.tdhContainer)
    self.tdhSolve = TdhNet.Get_TdhSolveControl_py(self.tdhvars)
    TdhNet.TdhSolve_StartUp_py(self.tdhSolve)
  
  def SetEngine (self):
  # select the TdhNet solution Engine  
    TdhNet.Use_TdhNet_Engine_py(self.tdhvars)

  def GetFile (self):   
  # read an input file   
    numLines = int()
    fileName = "./net1.inp"
    readOk = TdhNet.tdhfile_readfiletype_py(self.tdhIO, C_Str(fileName), 3)
    if not readOk:
      print ("input file not read:", fileName)

  def WriteDiameters (self):
  # output the id and diameter for each pipe 
    pipeIntf = TdhNet.GetPipeIntf_py(self.tdhContainer)
    goFlag = TdhNet.BaseIntf_GotoFirst_py(pipeIntf)
    while goFlag :
      print(TdhNet.PipeIntf_PipeID_py(pipeIntf), TdhNet.PipeIntf_Diameter_py(pipeIntf))
      goFlag = TdhNet.BaseIntf_GotoNext_py(pipeIntf) 

  def AttachData (self):
  # attach the data to the solution engine  
    changeSet = "";
    TdhNet.TdhSolve_AttachData_py(self.tdhContainer, C_Str(changeSet))

  def Solve (self):      
  # execute a single hydraulic solution
  # for an EPS solution sequence, solveControl->SolveOne() would be repeated while solveControl->AnotherEPS() == true
    TdhNet.TdhSolve_SequenceInit_py(self.tdhSolve, 1) 
    TdhNet.TdhSolve_SolveOne_py(self.tdhSolve, 0)


  def WriteFlows (self):
  # output the id, flow and loss for each pipe  
    pipeResult = TdhNet.TdhPipeResult_Create_py(self.tdhvars)
    goFlag = TdhNet.BaseRslt_GotoFirst_py(pipeResult)
    while goFlag :
      pipeID = TdhNet.PipeRslt_PipeID_py(pipeResult)
      flow = TdhNet.PipeRslt_Flow_py(pipeResult)
      print (pipeID, flow)
      goFlag = TdhNet.BaseRslt_GotoNext_py(pipeResult)

class TTdhNet_DbDemo_py (TTdhNet_Demo_py):
# this class implements sqlite database i/o for input data and solution results  
# TdhnetData.sqlite and TdhnetResults.sqlite must exist in a directory 'TdhNet_StructPath' and be compatible with the current program version

  def Main (self):
  # program structure    
    TTdhNet_Demo_py.Main(self)
    if self.InitDB(self):
      netName = "Net1"
      TdhNet.SaveNetToDB_py (self.sql_IO, C_Str(netName)) # save the input data to the db
      TdhNet.GetNetFromDB_py (self.sql_IO, C_Str(netName)) # retrieve the input data from the db
      TdhNet.SaveResultsToDB_py (self.sql_IO, 1) # save solution results to the db
      TdhNet.GetResultsFromDB_py (self.sql_IO, C_Str(netName), 1, -1) # retrieve solution results from the db

  def InitDB (self):
  # initialize the database api  
    execPath = os.getcwd();
    structPath = os.path.join (execPath, "Tdhnet_Structure")
    dataPath = os.path.join (execPath, "Tdhnet_Data")
    self.sql_IO = TdhNet.GetSql_netIO_py(self.tdhContainer, C_Str(structPath))
    result = TdhNet.Sql_IO_SetDB_py(self.sql_IO, C_Str(dataPath))
    return result

class TTdhNet_EpaDemo_py (TTdhNet_DbDemo_py):
# this class implements the EpaNet solution engine using the TdhNet API
  
  def SetEngine (self):
  # select the EpaNet solution  
    TdhNet.Use_EpaNet_Engine_py(self.tdhvars, TdhNet.get_EpaIntf_py())
    
class TEpaToTdh_Demo_py (TTdhNet_DbDemo_py):
# this class implements the TdhNet solution engine using a modified EpaNet API
  
  def Init (self):
  # initialize the TdhNet solution engine and a modified EpaNet API  
    self.tdhvars = TdhNet.GetTdhVars_py()
    self.tdhvars2 = TdhNet.GetTdhVars_py()
    self.tdhContainer = TdhNet.get_TdhContainer_py(self.tdhvars)
    self.tdhContainer2 = TdhNet.get_TdhContainer_py(self.tdhvars2)
    TdhNet.Use_TdhNet_Engine_py(self.tdhvars2)
    self.epaIntf = TdhNet.Create_EpaToTdh_py(self.tdhContainer2)
    TdhNet.Use_EpaNet_Engine_py(self.tdhvars, self.epaIntf)
    self.tdhIO = TdhNet.TdhIO_StartUp_py (self.tdhContainer)
    self.tdhSolve = TdhNet.Get_TdhSolveControl_py(self.tdhvars)
    TdhNet.TdhSolve_StartUp_py(self.tdhSolve)
    if (TdhNet.EN_init_py(self.epaIntf, C_Str(""), C_Str(""), 0, 0)):
      print("Epanet not initialized")

  def WriteDiameters (self):
  # output the id, diameter and status for every pipe
    id = c_char_p()
    diam = c_double()
    status = c_double()
    numPipes = c_int()
    TdhNet.EN_getcount_py(self.epaIntf, 2, byref(numPipes))
    for i in range (1, numPipes.value+1) : 
      TdhNet.EN_getlinkid_py(self.epaIntf, i, byref(id))
      TdhNet.EN_getlinkvalue_py(self.epaIntf, i, 0, byref(diam))
      TdhNet.EN_getlinkvalue_py(self.epaIntf, i, 4, byref(status))
      print (id.value, diam.value, status.value)
    
  def Solve (self) :
  # execute a single hydraulic solution
    epaTime = c_long()
    TdhNet.EN_initH_py(self.epaIntf, 0)
    TdhNet.EN_runH_py(self.epaIntf, byref(epaTime))
    self.WriteTotalDemand(self)

  def WriteTotalDemand (self):    
  # output the total demand for the solution  
    totalDemand = c_double()
    sysRslts = TdhNet.TdhSystemResult_Create_py(self.tdhvars)
    totalDemand.value = TdhNet.SysRslts_total_demand_py(sysRslts)
    print ("Total Demand: ", totalDemand.value)

  def WriteFlows (self) :
  # output the id and flow (in the user specified units) and loss for every pipe
    id = c_char_p ()
    flow = c_double ()
    loss = c_double ()
    numPipes = c_int ()
    TdhNet.EN_getcount_py(self.epaIntf, 2, byref(numPipes))
    for i in range (1, numPipes.value+1) : 
      TdhNet.EN_getlinkid_py(self.epaIntf, i, byref(id))
      TdhNet.EN_getlinkvalue_py(self.epaIntf, i, 8, byref(flow))
      TdhNet.EN_getlinkvalue_py(self.epaIntf, i, 10, byref(loss))
      print (id.value, flow.value, loss.value)

class TEpaToEpa_Demo_py (TEpaToTdh_Demo_py):
# this class implements the EpaNet solution engine using a modified EpaNet API
  
  def Init (self):
  # initialize the API  
    TTdhNet_EpaDemo_py.Init(self);

  def SetEngine (self):
  # select the EpaNet solution engine  
    self.epaIntf = TdhNet.get_EpaIntf_py()
    TdhNet.Use_EpaNet_Engine_py(self.tdhvars, self.epaIntf)
    
  def Solve (self) :
  # execute a single hydraulic solution  
    TTdhNet_EpaDemo_py.Solve(self)
    self.WriteTotalDemand(self)

Set_TdhNetCFuncs()
tdhDemo = TTdhNet_Demo_py # comment out this line before implementing other versions
#tdhDemo = TTdhNet_DbDemo_py # uncomment this line to implement this version
#tdhDemo = TTdhNet_EpaDemo_py # uncomment this line to implement this version
#tdhDemo = TEpaToTdh_Demo_py # uncomment this line to implement this version
#tdhDemo = TEpaToEpa_Demo_py # uncomment this line to implement this version
tdhDemo.Main(tdhDemo)




