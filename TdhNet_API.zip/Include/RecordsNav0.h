// Defines the functionality for a Tdh Records Navigator

#ifndef RecordsNav0_Header
#define RecordsNav0_Header

#include "StringDef.hpp"

template <class objType, class keyType> class EXPORTPROC TRecordsNav0_min {
// an abstract class for the most basic functionality provided by the Tdh Records Navigator
protected:
public:
  virtual ~TRecordsNav0_min () {}
  virtual bool AddRec (objType*, keyType, bool=false) = 0;
  virtual bool DeleteAll () = 0;
  virtual bool DeleteOne (keyType, bool=false) = 0; //find object with key = 1st param and remove from list, delete object if 2nd param = false
  virtual objType *GetFirst () = 0;
  virtual objType *GetNext (objType*) = 0;
  virtual objType *GetLast () = 0;
  virtual objType *GetPrev (objType*) = 0;
  virtual bool GetRec (keyType, objType**) = 0;
  virtual objType *GetItem (unsigned) = 0; //return object pointer in position = 1st param
  virtual unsigned get_Count() = 0;
  virtual objType *DefaultRec () = 0;
  virtual void set_DefaultRec (objType*) {} //sets the object to be returned if the container is empty
  };

class TListManNotify0; //provides notifications upon change of the object pointer of a container

template <class objType, class keyType> class EXPORTPROC TRecordsNav0 : public TRecordsNav0_min <objType, keyType> {
// an abstract class for expanded functionality provided by the Tdh Records Navigator
private:
protected:
public:
  virtual ~TRecordsNav0 () {}
  virtual void Destroy () {}
  virtual bool DataExists () = 0; //returns true if the container contains at least one object; otherwise returns false;
  virtual bool GotoFirst() = 0; //sets the object pointer to the first object in the container
  virtual bool GotoLast() = 0; //sets the object pointer to the last object in the container
  virtual bool GotoNext() = 0; //sets the object pointer to the object after the current object, if the current object is not the last object
  virtual bool GotoPrev() = 0; //sets the object pointer to the object before the current object, if the current object is not the first object
  virtual bool GotoRec (keyType) = 0; //sets the object pointer to the object whose key value matches the 1st parameter, if such an current object exists
  virtual bool GotoNear (keyType) = 0; //sets the object pointer to the object whose key value is closest to but not more than the 1st parameter. return false only if no objects exist
  virtual bool AtFirst() = 0; // return true if the object pointer is set to the first object
  virtual bool AtLast() = 0; // return true if the object pointer is set to the last object
  virtual unsigned get_Count() {return 0;} // returns the number of objects in the container
  virtual unsigned get_RecNum() {return 0;} // returns the position of the current object


  virtual keyType GetKey () = 0; // returns the key value of the current object
  virtual keycomp_result KeyComp (keyType) = 0;//returns the key comparison result for the current object vs. the 1st parameter
  virtual bool SetKey (keyType, bool=false) {return false;} // sets the key value of the current object and inserts or moves the object within the container.
                                                 // if there is an existing object with the same key and the 2nd parameter is true, the exiting object is deleted; otherwise the change is rejected
                                                 // returns true if is the key is set
  virtual objType *SetOrGetKey (keyType) = 0; // sets the key value of the current object and inserts or moves the object within the container.
                                                 // if there is an existing object with the same key that object becomes the current object
                                                 //return the current object

  virtual objType *GetData () = 0; //returns the object pointer
  virtual void SetData (objType*) = 0; //set the object pointer (if the object belongs to the container)

  virtual unsigned GetPosition (objType*) = 0;
  virtual bool DeleteOne (keyType, bool=false) {return false;} //deletes the object with a key value = 1st parameter, if it exists
  virtual bool DeleteAll () {return false;} //deletes all objects in the container
  virtual bool NewData (objType*, keyType, bool=false) {return false;}
        // sets current current object to 1st parameter, to be assigned the key value of the 2nd parameter and added to list
        // if 2nd param already exists: if the 3rd param is true the existing records is replaced, otherwise the new record is not added
  virtual objType *get_UnUsedObj () {return NULL;} // returns the previous new object if it was not added to the container; otherwise, returns NULL
  virtual bool NewData_nokey (objType*) {return false;} // sets current current object to 1st parameter. must be followed by a call to SetKey to add to container
  virtual tdhString KeyToStr () {return "";} //returns a string representation of the key
  virtual tdhString GetNextAvailableKey (const char* prefix) {return "";}
  virtual bool KeyError () = 0; //indicates whether n key conflict resulted from the previous SetKey operation
  virtual bool KeyUsed (keyType) = 0; // return true if the key is used in the container
  virtual void AddNotify (TListManNotify0*) {}; //adds a notification to the container
  virtual void RemoveNotify (TListManNotify0*) {}; //deletes a notification from the container
  virtual void set_Hide (bool) {} //controls whether records marked for hiding are hidden in navigators that allow hiding
  virtual bool Hide () {return false;}
  };


template <class objType, class keyType> class EXPORTPROC TRecordsNav_def :
public TRecordsNav0 <objType, keyType>    {
// a non abstract TRecordsNav that does nothing
protected:
  objType *defaultRec;
public:
  TRecordsNav_def (objType *defParam = NULL) {
    defaultRec = defParam;
    }
  virtual bool DataExists () {return false;}
  virtual bool GotoFirst() {return false;}
  virtual bool GotoLast() {return false;}
  virtual bool GotoNext() {return false;}
  virtual bool GotoPrev() {return false;}
  virtual bool GotoRec (keyType) {return false;}
  virtual bool GotoNear (keyType) {return false;}
  virtual bool AtFirst() {return false;}
  virtual bool AtLast() {return false;}

  virtual bool AddRec (objType*, keyType, bool=false) {return false;}
  virtual keyType GetKey () {return (keyType)0;}
  virtual keycomp_result KeyComp (keyType) {return crKeysEqual;}
  virtual objType *SetOrGetKey (keyType) {return NULL;}

  virtual objType *GetData () {return DefaultRec();}
  virtual void SetData (objType*) {}
  virtual objType *DefaultRec () {return defaultRec;}

  virtual objType *GetFirst () {return NULL;}
  virtual objType *GetNext (objType*) {return NULL;}
  virtual objType *GetLast () {return NULL;}
  virtual objType *GetPrev (objType*) {return NULL;}
  virtual bool GetRec (keyType, objType**) {return false;}
  virtual objType *GetItem (unsigned) {return DefaultRec();}
  virtual unsigned GetPosition(objType*) {return 0;}

  virtual bool KeyError () {return false;}
  virtual bool KeyUsed (keyType) {return false;}
  };

template <class objType, class keyType> class EXPORTPROC TRecordsNav_array : public TRecordsNav0 <objType, keyType> {
// navigate and manage the objects in a array
protected:
  unsigned long currI, baseI, currI2;
  virtual unsigned long BaseI () {return baseI;}
  virtual objType *SetOrGetKey (keyType) {return NULL;} // sets the key value of the current object and inserts or moves the object within the container.
                                                 // if there is an existing object with the same key that object becomes the current object
                                                 //return the current object
  virtual bool SetKey (keyType, bool=false) {return false;} // sets the key value of the current object and inserts or moves the object within the container.
  virtual bool KeyError () {return false;}  //indicates whether n key conflict resulted from the previous SetKey operation
  virtual bool KeyUsed (keyType) {return false;} // return true if the key is used in the container

public:
  TRecordsNav_array (int baseParam) : TRecordsNav0 <objType, keyType> () {
    baseI = baseParam;
    currI = baseI;
    currI2 = baseI;
    }
  virtual bool WithinBounds (unsigned long index) {
    if (index < BaseI())
      return false;
    if (index > LastI())
      return false;
    return true;
    }
  virtual unsigned long LastI () {return get_Count()+BaseI()-1;}
  virtual unsigned long GetPosition2 (objType *objParam) {
    if (objParam == GetArray()+currI2)
      return currI2;
    return GetPosition(objParam);
    }
  virtual objType *GetData2 (unsigned long index) {
    if (!WithinBounds(index))
      return NULL;
    currI2 = index;
    return GetArray()+currI2;
    }
  virtual objType *GetFirst () {return GetData2(BaseI());} //returns first object pointer in list
  virtual objType *GetNext (objType *objParam) {return GetData2(GetPosition2(objParam)+1);} //returns object pointer after 1st param.
  virtual objType *GetLast () {return GetData2(LastI());} //returns last object pointer in list
  virtual objType *GetPrev (objType *objParam) {return GetData2(GetPosition2(objParam)-1);} //returns object pointer before 1st param.
  virtual objType *GetItem (unsigned long index) {return GetData2(index);}

  virtual bool DataExists () {return get_Count() > 0;} //returns true if the container contains at least one object; otherwise returns false;
  virtual bool GotoFirst() {currI = BaseI(); return DataExists();} //sets the object pointer to the first object in the container
  virtual bool GotoLast() {currI = LastI(); return DataExists();} //sets the object pointer to the last object in the container
  virtual bool GotoNext() {if (currI < LastI()) currI++; else return false; return true;} //sets the object pointer to the object after the current object, if the current object is not the last object
  virtual bool GotoPrev() {if (currI > BaseI()) currI--; else return false; return true;} //sets the object pointer to the object before the current object, if the current object is not the first object
  virtual bool GotoRec (keyType) = 0; //sets the object pointer to the object whose key value matches the 1st parameter, if such an current object exists
  virtual bool GotoNear (keyType) = 0; //sets the object pointer to the object whose key value is closest to but not more than the 1st parameter. return false only if no objects exist
  virtual bool AtFirst() {return currI == BaseI();} // return true if the object pointer is set to the first object
  virtual bool AtLast() {return currI == LastI();} // return true if the object pointer is set to the last object
  virtual unsigned long get_Count() = 0; // returns the number of objects in the container
  virtual unsigned long get_RecNum() {return currI;} // returns the position of the current object

  virtual objType *GetArray () = 0;
  virtual objType *GetData () {
    if (!DataExists())
      return this->DefaultRec();
    return GetArray()+currI;
    } //returns the object pointer
  virtual void SetData (objType *objParam) {
    *(GetArray()+currI) = *objParam;
    } //set the object pointer (if the object belongs to the container)

  virtual bool AddRec (objType*, keyType, bool=false) {return false;}
  virtual keyType GetKey () = 0; // returns the key value of the current object
  virtual keycomp_result KeyComp (keyType) {return crInvalid;} //returns the key comparison result for the current object vs. the 1st parameter
  virtual bool DeleteOne (keyType, bool=false) {return false;} //deletes the object with a key value = 1st parameter, if it exists
  virtual void DeleteAll () {} //deletes all objects in the container
  virtual bool NewData (objType*, keyType, bool=false) {return false;}
        // sets current current object to 1st parameter, to be assigned the key value of the 2nd parameter and added to list
        // if 2nd param already exists: if the 3rd param is true the existing records is replaced, otherwise the new record is not added
  virtual objType *get_UnUsedObj () {return NULL;} // returns the previous new object if it was not added to the container; otherwise, returns NULL
  virtual bool NewData_nokey (objType*) {return false;} // sets current current object to 1st parameter. must be followed by a call to SetKey to add to container
  virtual tdhString KeyToStr () {return "";} //returns a string representation of the key
  virtual tdhString GetNextAvailableKey (const char* prefix) {return "";}
  virtual void set_DefaultRec (objType*) {} //sets the object to be returned if the container is empty
  virtual void AddNotify (TListManNotify0*) {}; //adds a notification to the container
  virtual void RemoveNotify (TListManNotify0*) {}; //deletes a notification from the container
  };


#endif // RecordsNav0_Header
