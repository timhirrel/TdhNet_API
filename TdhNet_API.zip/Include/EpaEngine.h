// Provides some functions needed to use the Epanet solution engine from the TdhNet API
// and to use the TdhNet solution engine from the modified Epanet API

#ifndef EpaEgnine_Header
#define EpaEgnine_Header

#include "TdhSolutionIntf.h"

class TEpaIntf0;
class TdhContainer;

EXTERNC void EXPORTPROC Use_EpaNet_Engine (Ttdhvars*, TEpaIntf0*); 
  // allows the Epanet solution engine to be used from the Tdhnet API 
  // and the TdhNet solution to be used from a modified Epanet API. 
  // TEpaIntf0 defines the modified version of the Epanet API and is defined in EpaIntf0.h
  // this function calls the following the function:
  //  1. Ttdhvars::set_SolveControl()
  //  2. Ttdhvars::set_EpsSolve()
  //  3. Ttdhvars::set_AttachData()
  //  4. Ttdhvars::set_ResultsClasses ()
  //  5. Ttdhvars::set_FireFlow ()
  //  6. Ttdhvars::set_PressDpndcy()
  //  7. Ttdhvars::set_PumpSpeedControl()

EXTERNC TEpaIntf0 EXPORTPROC *get_EpaIntf (TMessenger0*); 
  // returns an implementation of TEpaIntf0 that calls Epanet API functions. 
  // this implementation is used when using the Epanet solution from the TdhNet API.

EXTERNC TEpaIntf0 EXPORTPROC *Create_EpaToTdh (TdhContainer*); 
  // returns an implementation of TEpaIntf0 that calls Tdhnet API functions. 
  // This implementation is used when using the TdhNet solution engine from the modified Epanet API.

EXTERNC TMessenger0 EXPORTPROC *Messenger_Epa(); 
  // returns a TMessenger0 class that provides a callback function needed by Epanet

#endif // EpaEgnine_Header
