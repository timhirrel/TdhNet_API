#ifndef QUALITYINTF_H_INCLUDED
#define QUALITYINTF_H_INCLUDED

#include "tdhdefs.hpp"

class TdhContainer;

class EXPORTPROC TQualityIntf0 {
protected:
//  Ttdhvars *tdhvars;
public:
  TQualityIntf0 () {
//    tdhvars = varsParam;
//    varsParam->set_QualityIntf(this);
    }
  virtual ~TQualityIntf0 () {}
//Quality results functions
  virtual double JunQuality (basekey) {return 0;}
  virtual double FgnQuality (basekey) {return 0;}
  virtual double TankQuality (basekey) {return 0;}
  virtual double PipeQuality (basekey) {return 0;}
  virtual double PipeReactRate (basekey) {return 0;}
  virtual char QualType () {return 0;}
// set quality values
  virtual void set_JunQuality (basekey, double) {}
  virtual void set_FgnQuality (basekey, double) {}
//quality control functions
  virtual void PrepareQual () {} // prepases for water quality analysis before a solution sequence begins; called after tdhengine_modint
  virtual void SolveQual (double) {} // executes a water quality analysis for the latest hydraulic solution
                                  // 1st param is the time elapsed since the previous hydraulic solution, in seconds
  virtual void ResetQual () {} // called after the current solution sequence is no longer needed, allows for a new sequence
//travel time control functions
  virtual void PrepareTrav () {}  // prepares for a travel analysis
  virtual void ResetTrav (int) {} // called after the current solution sequence is no longer needed, allows for a new sequence
  virtual char StartTrav_fgn (basekey, int) {return 0;} // 1st param specifies the fgn to be used as a starting point for a travel time analysis
                                               // 2nd param specified direction: direction = 1 for analysis of outflow from start point
                                               // direction = 2 for analysis of inflow to start point
  virtual char StartTrav_jun (basekey, int) {return 0;} // 1st param specifies the fgn to be used as a starting point for a travel time analysis
  virtual void AllSourcesTrav () {} // performs a weighted travel time analysis for all flow entering the networking
// travel time results functions
  virtual bool GotoNodeTrav (basekey, char) {return false;} //specifies a node id and type, 1 = junction, 2 = fgn
  virtual double ContributionTrav () {return 0;} // returns the proportion of flow received from or reaching the start node
  virtual double TravTime () {return 0;} // returns the weighted travel time for the flow included in contribution
  };

EXTERNC TQualityIntf0* EXPORTPROC TdhQuality_Init (TdhContainer*); //must be called before any functions in TQualityIntf0


#endif // QUALITYINTF_H_INCLUDED
