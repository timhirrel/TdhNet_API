#ifndef tdhdefheader
#define tdhdefheader

#include <stdlib.h>

#include "StringDef.hpp"


typedef unsigned char byte;
typedef unsigned int word;
typedef short FLAG;
typedef std::string tdh_keytype;
typedef char (*messageproc) (std::string);

#define basekey std::string

// codes for the entity types used within the API
enum entities {etNONE = -1, etFGN = 0, etJUN, etPIPE, etPUMP,
               etPRV, etTANK, etSTATION,
               etSWITCH, etJUNGROUP, etEMIT, etSYSTEM, etRULE, etCHANSIT, etCHANVAL, etCHANSET,
               etQUAL, etPUMPPT, etTANKPT, etValvePt, etDEMANDPT, etRUNRSLT, etSIMRSLT, etPIPERSLT,
               etFGNRSLT, etJUNRSLT, etPUMPRSLT, etPRVRSLT, etTANKRSLT, etSWITCHRSLT, etSTATIONRSLT,
               etEMITRSLT, etCOSTRSLT,etNOTE, etNODE, etSYSLABEL, etCHANLABEL, etEPS,
               etCONTROLSET, etOPT, etNETNAME, etFILEVER, etMAPDATA, etCELLDATA, //etRULE2,
               etSYSTEMRSlT, etQuery, etPIPEPT, etRULERSLT, etXYZ, etValveData, etEntID, etPressDpndcy,
               etPumpControl, etEpsRslt, etMAX
              };
//int const MaxEntNum =100;

// codes for the status of entities within the API
enum solvestatus {ssUnknown=-1, ssOPEN, ssCLOSED, ssChkVlvClosed, ssISOLATED, ssREMOVED};

//codes for flow units
enum flowunits {CFS, GPM, MGD, SI_lps, SI_lpm, SI_cmh, SI_cmd, SI_cms, SI_mld};

//codes for solution status
enum solution_stats {Unknown_status = -1, NO_ATTEMPT, ACCURACY_OK, NOT_ACCURATE, ACCURACY_DIVERGED, INSUFFICIENT_MEM,
                     DATA_ERROR
                    };

//codes for return status for user messages
enum usermessages {NOMESSAGE, STOPTDH};

//codes for hydraulic friction formulas
enum fricformulas {HAZEN=1, DARCY=2, MANNING};

//codes for node types
enum nodetypes {UnKnown = -1, JUN, FGN, PRVNODE, PRVFLOWJUN};

//codes for valve types
enum prvtypes {vtRELIEF=0, vtREDUC=1, vtFLOWCONTROL =2, vtGENERAL, vtTHROTTLE, vtFLOATVALVE};

//codes for pump performance specifications
enum pumptypes {POWER=1, PTS3=2, PTS3POW=3, PTSMULTI};

int const MAXPUMPPTS = 3; //number of pts for a calculated pump performance curve

//codes for station types
enum stationtypes {PUMPSTATION, PARALLELSTATION, SERIALSTATION};

//codes for check valve types
enum chkvlvTypes {chkvlvNONE=0, chkvlvNORMAL, chkvlvREVERSE};

// codes for the status of check valves
enum chkvlvStatusFlags {cvNONE=-1, cvOPEN, cvCLOSED};

//codes for yes/no opations
enum YesNoFlags {flagNO=0, flagYES};

//codes for tank solution status
enum tankstatus {tsFULL, tsRISING, tsFALLING, tsEMPTY, tsSTATIC, tsCLOSED};

//codes for error conditions
enum errortype {errorUNKNOWN=1, errorLOWMEM, errorINPUTDATA};

//codes for debug state, determines what messages are sent
enum debugstate {dsNoChange= -2, dsNoMessages, dsNormal, dsSolveInfo, dsStep};

//codes for applying relaxation to the hydraulic calculations
enum RelaxModes {rmDefault= -1, rmSequenceInit, rmSolveInit, rmNewpaths};

//codes for resetting pipe flows to 0
//enum TResetFlowModes {rfmDefault= -1, rfmSequnceInit, rfmSolveInit, rfmPathInit};

enum TEngineTypes {engtypeUnknown=-1, engtypeTdhNet, engtypeEpanet};

class TdhChanges0;
class TDrawNet_tdhnet;
class TtdhRulesAdmin;
class TTdhIO;
class TAttachData0;
class TResultsClasses0;
class TQualityIntf0;
class TdhSolveControl0;
class TEpsSolve0;
class TUnitsRef;
class Tsysdataref0;
class TCreateRefs0;
class TdhFireFlow0;
class TPumpSpeedControl0;
class TtdhSolve_PressDpndt0;

//class for associating entities with descriptive strings
class TEntStrs0 {
public:
    virtual ~TEntStrs0 () {}
    virtual entities EntStrIndex(tdhString)=0; //returns the index for an entity name
    virtual tdhString EntStr (entities)=0; //returns the entity name for an index
};

// universal class for TdhNet API
// provides access to the classes for the major components of the API
// must be created before using any feature of the API
class EXPORTPROC Ttdhvars {
protected:
    TMessenger0 *messenger; //for handling messages from the libraries
    TTdhIO *tdhIO;  //for file I/O
    TdhSolveControl0 *solveControl; //for controlling the solution process
    TdhChanges0 *changeInst; //for implementing change data
    TtdhRulesAdmin *RuleInst; //for processing rules
    TDrawNet_tdhnet *MapInst; //for displaying a network map
    TAttachData0 *attachData; //for providing access to data for the solution engeine
    TResultsClasses0 *resultsClasses; //for providing access to solution results
    TEntStrs0 *entStrs; //for associating entities with descriptive strings
    TQualityIntf0 *qualityIntf; //for performing a water quality analysis using EpaNet functions
    TEpsSolve0 *epsSolve; // for implementing extended period simulations
    TdhFireFlow0 *fireFlow; // for implementing fire flow analysis
    TPumpSpeedControl0 *pumpSpeedControl; // for implementing pump speed controls
    TtdhSolve_PressDpndt0 *pressDpndcy; // for implementing pressure adjusted demands

public:
    TEngineTypes engineType;
    Ttdhvars (TMessenger0*);
    virtual ~Ttdhvars ();
    virtual bool Ok () {return true;}

    virtual TMessenger0 *Messenger () {return messenger;}
    virtual void set_Messenger (TMessenger0 *val) {messenger = val;}

    virtual int Debug ();
    virtual void Debug_Step(tdhString);

    virtual void set_EntStrs (TEntStrs0 *strParam) {entStrs = strParam;}

    virtual entities EntStrIndex(tdhString val) {return entStrs->EntStrIndex(val);}   //returns the index for an entity name
    virtual tdhString EntStr (entities val) {return entStrs->EntStr(val);}   //returns the entity name for an index

    virtual TEngineTypes EngineType () {return engineType;}
    virtual void set_EngineType (TEngineTypes val) {engineType = val;}

    virtual TdhSolveControl0 *SolveControl () {return solveControl;}
    virtual void set_SolveControl (TdhSolveControl0 *param) {solveControl = param;}

    virtual TdhChanges0 *ChangeInst () {return changeInst;}
    virtual void set_ChangeInst (TdhChanges0*instParam) {changeInst = instParam;}

    virtual TQualityIntf0 *QualityIntf ();
    virtual void set_QualityIntf (TQualityIntf0 *instParam) {qualityIntf = instParam; }

    virtual TtdhRulesAdmin *get_RuleInst () {return RuleInst;}
    virtual void set_RuleInst (TtdhRulesAdmin *instParam) {RuleInst = instParam;}

    virtual TDrawNet_tdhnet *get_MapInst () {return MapInst;}
    virtual void set_MapInst (TDrawNet_tdhnet *instParam) {MapInst = instParam;}

    virtual TTdhIO *TdhIO () {return tdhIO;}
    virtual void set_TdhIO (TTdhIO *ioParam) {tdhIO = ioParam;}

    virtual TAttachData0 *AttachData () {return attachData;}
    virtual void set_AttachData (TAttachData0 *attachParam) {attachData = attachParam; }

    virtual TResultsClasses0 *ResultsClasses () {return resultsClasses;}
    virtual void set_ResultsClasses (TResultsClasses0 *val) {resultsClasses = val;}

    virtual TEpsSolve0 *EpsSolve () {return epsSolve;}
    virtual void set_EpsSolve (TEpsSolve0 *epsParam) {epsSolve = epsParam;}

    virtual TUnitsRef *Units();
    virtual Tsysdataref0 *SysData();

    virtual TdhFireFlow0 *FireFlow () {return fireFlow;}
    virtual void set_FireFlow (TdhFireFlow0 *val) {fireFlow = val;}

    virtual TPumpSpeedControl0 *PumpSpeedControl() {return pumpSpeedControl;}
    virtual void set_PumpSpeedControl (TPumpSpeedControl0 *val) {pumpSpeedControl = val;}

    virtual TtdhSolve_PressDpndt0 *PressDpndcy () {return pressDpndcy;}
    virtual void set_PressDpndcy (TtdhSolve_PressDpndt0 *val) {pressDpndcy = val;}
};

//recommended function for creating Ttdhvars
EXTERNC Ttdhvars EXPORTPROC *GetTdhVars (TMessenger0* = &NoMessenger);

class TUnitsRef;
//calculate the hydraulic power produced by a pump at a specified operating point
EXTERNC double EXPORTPROC PumpPtPower(double tdh, double flow, TUnitsRef*, double spgrav);


#endif
