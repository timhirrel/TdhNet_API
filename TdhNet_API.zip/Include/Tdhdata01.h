// Provides a set of interfaces for data that is needed for the solution engine

#ifndef tdhcomheader
#define tdhcomheader
#endif

//---------------------------------------------------------------------------
#ifndef tdhdata01H
#define tdhdata01H
//---------------------------------------------------------------------------

#include "TdhSolutionIntf.h"
#include "RecordsNav0.h"

#define EXPORT_TdhContainer
#ifdef tdh_Windows
  #define EXPORT_TdhContainer __declspec(dllimport)
#endif
#ifdef TDHContainer_EXPORTS
  #define EXPORT_TdhContainer __declspec(dllexport)
#endif

class Ttdhvars;

basekey EXPORTPROC convertKey (tdh_keytype);
const char EXPORTPROC *KeyToChar (tdh_keytype);

class Ttdhdata;
class TListNotify_M;
class TtdhDataInterfaces;
class TdhContainer;

class EXPORTPROC TBase0Intf {
protected:
  Ttdhdata *tdhdata;
//  TdhContainer *dataContainer;
public:
  TBase0Intf (Ttdhdata *dataParam) {
    tdhdata = dataParam;
    }
  virtual ~TBase0Intf () {}
  virtual entities GetEntType()=0;
  virtual Ttdhdata *get_tdhdata();
  virtual Ttdhvars *get_tdhvars ();
  virtual Ttdhdata *TdhData () {return tdhdata;}
  virtual TtdhDataInterfaces *DataIntfs();
//  virtual TdhContainer *DataContainer();
  virtual tdhString KeyToStr () {return "";}
  virtual bool GotoFirst (bool = false) {return false;}
  virtual bool GotoNext () {return false;}
  virtual bool DataExists (bool = false) {return true;}
  virtual bool copy_data (TBase0Intf*) {return false;}
  virtual bool copy_alldata (TBase0Intf*); //copy the data to the specified Ttdhvars
  virtual TUnitsRef *Units ();
  };

class Tsystemdata;
class EXPORTPROC TSystemIntf : public TBase0Intf {
protected:
  virtual Tsystemdata *GetDataObj();
public:
  TSystemIntf (Ttdhdata*);
  virtual ~TSystemIntf ();
    virtual TEngineTypes EngineType ();
    virtual void set_EngineType (TEngineTypes);
    virtual flowunits get_FlowUnits ();
    virtual void set_FlowUnits (flowunits);
    virtual bool SI_flag ();
    virtual TUnitsRef *Units ();
    virtual int get_maxtrials();
    virtual void set_maxtrials (int);
    virtual fricformulas get_FrictionFormula();
    virtual void set_FrictionFormula (fricformulas);
    virtual double get_RelativeAccuracy();
    virtual void set_RelativeAccuracy(double);
    virtual double get_ErrorLimit();
    virtual void set_ErrorLimit(double);
    virtual double get_SpecificGravity();
    virtual void set_SpecificGravity(double);
    virtual double get_kinvis();
    virtual void set_kinvis(double);
    virtual double get_demandfactor();
    virtual void set_demandfactor(double);
    virtual void modify_demandfactor (double);
    virtual double ChkVlvFactor();
    virtual void set_ChkVlvFactor(double);
    virtual char ResetValves();
    virtual void set_ResetValves(char);
//    virtual TResetFlowModes ResetFlows();
//    virtual void set_ResetFlows(TResetFlowModes);
    virtual RelaxModes RelaxMode ();
    virtual void set_RelaxMode (RelaxModes);

//    virtual Ttdhdata *get_tdhdata () {return tdhdata;}
    virtual bool SetKeyError() {return false;}
    virtual entities GetEntType() {return etSYSTEM;}
    virtual bool DataExists (bool = false);
    virtual bool DataAttached ();
  };

class Tepsdata;
class EXPORTPROC TEpsIntf : public TBase0Intf {
protected:
  virtual Tepsdata *GetDataObj();
public:
  TEpsIntf (Ttdhdata*);
  virtual ~TEpsIntf ();
    virtual FLAG get_epsflag ();
    virtual void set_epsflag (FLAG);
    virtual double get_EpsStartTime();
    virtual void set_EpsStartTime(double);
    virtual double get_EpsEndTime();
    virtual void set_EpsEndTime(double);
    virtual double get_Duration () {return get_EpsEndTime()-get_EpsStartTime();}
    virtual double get_EpsInterval();
    virtual void set_EpsInterval(double);
//    virtual double get_nexttime();
//    virtual void set_nexttime(double);
    virtual double get_MaxTankChange ();
    virtual void set_MaxTankChange (double);  // >0 - max tank level change between solutions, may be overridden for individual tanks
    virtual double get_UnitCost_sys ();
    virtual void set_UnitCost_sys (double);
    virtual double get_CurrentCost ();
    virtual void set_CurrentCost (double);
    virtual bool get_resetPeakKw ();
    virtual void set_resetPeakKw (bool);
    virtual entities GetEntType() {return etEPS;}
    virtual bool DataExists (bool = false);
  };

template <class keytype> class EXPORTPROC TBaseIntf : public TBase0Intf {
public:
  TBaseIntf (Ttdhdata *dataParam) : TBase0Intf (dataParam) {
    }
  virtual bool GotoRec (keytype keyptr) {return false;}
  virtual keytype GetKey () = 0;
  virtual long RecordCount () {return 0; }
  };

//base class for multi instance interface
template <class listclass, class keytype> class EXPORTPROC TBaseIntf01 :
public TBaseIntf <keytype> {
protected:
  TRecordsNav0 <listclass, keytype> *nav;
  virtual bool SetKey (keytype keyParam) {return Nav()->SetKey(keyParam);}
  virtual listclass *SetOrGetKey (keytype newkey) {return Nav()->SetOrGetKey(newkey); }
  virtual void BeforeDelete() {}
//  virtual TtdhListManager0 <listclass, keytype> *get_ListMan() {return datalist;}
  template <class, class> friend class TtdhEdit0;
public:
  TBaseIntf01 (Ttdhdata *dataParam, TRecordsNav0 <listclass, keytype> *navParam) :
  TBaseIntf <keytype> (dataParam) {
    nav = navParam;
    }
  virtual ~TBaseIntf01 () {
    if (nav)
      delete nav;
    }
  virtual TRecordsNav0 <listclass, keytype> *Nav() {return nav;}
  virtual listclass* createObj () = 0;
  virtual bool DataExists () {return Nav()->DataExists ();} //returns true if the list contains at least one object, otherwise, returns false
  virtual long RecordCount () {return Nav()->get_Count();}  // returns the number of objects in the list
  virtual long RecNum () {return Nav()->get_RecNum();} // returns the position of the current object
  virtual bool GotoFirst () {return Nav()->GotoFirst();} //sets the pointer to the first object in the list, if it exists
  virtual bool GotoLast () {return Nav()->GotoLast();} //sets the pointer to the last object in the list, if it exists
  virtual bool GotoNext () {return Nav()->GotoNext();} //sets the pointer to the next object in the list, if it exists
  virtual bool GotoPrev () {return Nav()->GotoPrev();} //sets the pointer to the previous object in the list, if it exists
  virtual bool GotoRec (keytype keyparam) {return Nav()->GotoRec(keyparam);} //sets the pointer to the object with a key value = 1st parameter, if it exists
  virtual bool GotoNear (keytype keyparam) {return Nav()->GotoNear(keyparam);} //sets the pointer to the object with a key value closest to but not more than the 1st parameter. returns false if no data exists
  virtual bool DeleteOne (keytype keyparam) {return false;} //deletes the object with a key value = 1st parameter, if it exists
  virtual void reset () {Nav()->DeleteAll();} //deletes all objects in list
  virtual keytype GetKey () {return Nav()->GetKey();} //return the key value for the current object
  virtual listclass *GetDataObj() {return  Nav()->GetData();} //returns the data object pointer
  virtual void SetDataObj (listclass *objPtr) {Nav()->SetData(objPtr);} //set the object pointer, validity of the pointer is the responsibility of the calling function (use with much caution, GotoRec is much safer)
  virtual keycomp_result KeyComp (keytype keyval) {return Nav()->KeyComp(keyval);} //returns the comparison result of the key value for the current data vs. the 1st parameter
  virtual listclass *get_NewObj () {
    listclass *newObj = Nav()->get_UnUsedObj();
    if (!newObj)
      newObj = createObj();
    return newObj;
    }
  virtual bool new_data_wkey (keytype keyParam) { //creates a new object, sets the key value = 1st parameter and adds to list, returns true if object is added to list
    return Nav()->NewData(get_NewObj(), keyParam);    }
  virtual void new_data () { // creates a new object that is not added to list until the key value is set
    Nav()->NewData_nokey(get_NewObj()); }
//  virtual TtdhListManager0 <listclass, keytype> *get_ListMan() {return datalist;}
//  virtual listclass *GetLast (TtdhOwner *ownerParam) {return get_ListMan()->get_List()->get_listfuncs()->GetLast(ownerParam);}
  virtual tdhString KeyToStr () {return Nav()->KeyToStr();}
  virtual tdhString GetNextAvailableKey (const char* prefix) {return Nav()->GetNextAvailableKey(prefix);}
  };

class TtdhDataObj;
typedef TBaseIntf <tdh_keytype> TtdhKeyIntf;
typedef TBaseIntf01 <TtdhDataObj, tdh_keytype> TtdhDataIntf;

class EXPORTPROC Tpipe_data;
class EXPORTPROC TPipeIntf : public TBaseIntf01 <Tpipe_data, tdh_keytype> {
protected:
    virtual Tpipe_data *createObj();
public:
    TPipeIntf (Ttdhdata*);
    virtual ~TPipeIntf();
    virtual tdh_keytype get_pipeid ();
    virtual bool set_pipeid (tdh_keytype);
    virtual tdh_keytype get_nodea ();
    virtual void set_nodea (tdh_keytype);
    virtual tdh_keytype get_nodeb ();
    virtual void set_nodeb (tdh_keytype);
    virtual char get_ClosedFlag ();
    virtual void set_ClosedFlag (solvestatus); //during a solution sequence, use TPipeIntf2::OCstatus to modify pipe status
    virtual chkvlvTypes get_ChkVlvFlag ();
    virtual void set_ChkVlvFlag (chkvlvTypes);
    virtual char get_FGNflag ();
    virtual void set_FGNflag (FLAG);
    virtual double get_length ();
    virtual void set_length (double);
    virtual double get_diameter ();
    virtual void set_diameter (double);
    virtual double get_Roughness_dep (); //return roughness appropriate for friction formula
    virtual double get_Roughness_hw (); //return roughness for Hazen
    virtual double get_Roughness_dw (); //return roughness for Darcy
    virtual void set_Roughness_dep (double); //set roughness appropriate for friction formula
    virtual void set_Roughness_hw (double); //set roughness for Hazen
    virtual void set_Roughness_dw (double); //set roughness for Darcy
    virtual double get_minor();
    virtual void set_minor (double);
    virtual tdh_keytype get_pumpid (); //returns pump id if the pipe contains a pump, else return ""
    virtual tdh_keytype get_prvid (); //returns prv id if the pipe contains a prv, else return ""
    virtual entities GetEntType() {return etPIPE;}
    virtual void set_CurrStatus (solvestatus); //the pipe open/close status during a simulation sequence; set to ClosedFlag at start of sequence
    virtual solvestatus get_CurrStatus ();
  };

class Tnode_data;
class EXPORTPROC TJunctionIntf : public TBaseIntf01 <Tnode_data, tdh_keytype> {
protected:
  tdh_keytype pipeid, oppnodeid;
  nodetypes oppnodetype;
  virtual Tnode_data *createObj();
public:
    TJunctionIntf (Ttdhdata*);
    virtual ~TJunctionIntf ();
    virtual tdh_keytype get_nodeid ();
    virtual bool set_nodeid (tdh_keytype, bool orFind); //since nodes are created with pipe data, the 2nd parameter is normally true when reading data, false when editing data
    virtual double get_demand();
    virtual void set_demand (double);
    virtual double get_elevation();
    virtual void set_elevation (double);
    virtual double CalcSolveDemand(); //basedemand * sysdata->demand_factor. note: different for TJunctionIntf2
    virtual void SetAllDemands(); // for all junctions, set solvedemand = CalcSolveDemand
    virtual double get_solvedemand ();
    virtual void set_solvedemand (double dataparam);
    virtual tdh_keytype FindPipe (tdh_keytype prevpipe); //start search w/ prevpipe = "", used returned value to resume search
    virtual unsigned int PipeCount (); //returns the number of pipes connected the current node;
    virtual tdh_keytype OppNodeID ();
    virtual nodetypes OppNodeType ();
    virtual tdh_keytype get_emitid();
    virtual entities GetEntType() {return etJUN;}
    virtual void set_AutoDelete (bool); //set whether node is automatically deleted when orphaned
  };

class EXPORTPROC TFgnIntf : public TBaseIntf01 <Tnode_data, tdh_keytype> {
protected:
  tdh_keytype pipeid, oppnodeid;
  nodetypes oppnodetype;
    virtual Tnode_data *createObj();
public:
    TFgnIntf (Ttdhdata*);
    virtual ~TFgnIntf();
    virtual tdh_keytype get_nodeid ();
    virtual bool set_nodeid (tdh_keytype, bool orFind); //since noddes are created with pipe data, the 2nd parameter is normally true when reading data, false when editing data
    virtual double get_grade();
    virtual void set_grade (double);
    virtual tdh_keytype FindPipe (tdh_keytype);
    virtual unsigned int PipeCount (); //returns the number of pipes connected the current node;
    virtual tdh_keytype OppNodeID ();
    virtual nodetypes OppNodeType ();
    virtual tdh_keytype get_tankid();
    virtual entities GetEntType() {return etFGN;}
    virtual void set_AutoDelete (bool);  //set whether node is automatically deleted when orphaned
  };

class Tprv_data;
class EXPORTPROC TPrvIntf : public TBaseIntf01 <Tprv_data, tdh_keytype> {
protected:
//  TTankResults0 *tankRslt;
  virtual TTankResults0 *TankRslt();
  virtual Tprv_data *createObj();
public:
  TPrvIntf (Ttdhdata*);
  virtual ~TPrvIntf ();
  virtual tdh_keytype get_prvid ();
  virtual bool set_prvid (tdh_keytype);
  virtual tdh_keytype get_pipekey ();
  virtual void set_pipekey (tdh_keytype);
  virtual bool GotoPipeID (tdh_keytype);
  virtual bool get_Active ();
  virtual void set_Active (bool);
  virtual prvtypes get_prvtype ();
  virtual void set_prvtype (prvtypes);
  virtual double get_prvgrade();
  virtual void set_prvgrade (double);
  virtual double get_Cv();
  virtual void set_Cv (double);
  virtual double get_AmountOpen();
  virtual void set_AmountOpen (double);
  virtual Tprvref0 *PrvRef ();
//  virtual double get_CurrentOpen();
//  virtual void set_CurrentOpen (double);
  virtual double get_Exponent();
  virtual void set_Exponent (double);
  virtual tdh_keytype get_ValveDataID ();
  virtual void set_ValveDataID (tdh_keytype);
  virtual tdh_keytype get_TankID(); //for float valve
  virtual void set_TankID (tdh_keytype); //for float valve
  virtual entities GetEntType() {return etPRV;}
  virtual void SetFloatValves();
//  virtual double CalcLoss (double);
  };

class TValveData_data;
class EXPORTPROC TValveDataIntf : public TBaseIntf01 <TValveData_data, tdh_keytype> {
protected:
  virtual TValveData_data *createObj();
public:
  TValveDataIntf (Ttdhdata*);
  virtual ~TValveDataIntf ();
  virtual tdh_keytype get_ValveDataID ();
  virtual bool set_ValveDataID (tdh_keytype);
  virtual int get_ValveType ();
  virtual void set_ValveType (int);
  virtual entities GetEntType();
  virtual long get_notecode();
  virtual void set_notecode (long);
  };

class TValvePt_data;
class EXPORTPROC TValvePtIntf : public TBaseIntf01 <TValvePt_data, double> {
protected:
    TValveDataIntf *valveDataIntf;
    virtual TValvePt_data *createObj();
public:
    TValvePtIntf (Ttdhdata*, TValveDataIntf*);
    virtual ~TValvePtIntf ();
    virtual double get_flow();
    virtual bool set_flow (double);
    virtual double get_loss();
    virtual void set_loss (double);
    virtual entities GetEntType() {return etValvePt;}
    virtual TValveDataIntf *ValveDataIntf () {return valveDataIntf;}
};

class Temit_data;
class EXPORTPROC TEmitIntf : public TBaseIntf01 <Temit_data, tdh_keytype> {
protected:
    virtual Temit_data *createObj();
public:
    TEmitIntf (Ttdhdata*);
    virtual ~TEmitIntf ();
    virtual tdh_keytype get_emitid ();
    virtual bool set_emitid (tdh_keytype);
    virtual tdh_keytype get_nodekey ();
    virtual void set_nodekey (tdh_keytype);
    virtual double get_coef();
    virtual void set_coef (double);
    virtual double get_diam();
    virtual void set_diam (double);
    virtual double get_exp();
    virtual void set_exp (double);
    virtual entities GetEntType() {return etEMIT;}
};

class EXPORTPROC Tpumppt_data;
class EXPORTPROC Tpump_data;
class EXPORTPROC TPumpIntf : public TBaseIntf01 <Tpump_data, tdh_keytype> {
protected:
    virtual Tpump_data *createObj();
//    virtual bool PrepareForCalc();
public:
    TPumpIntf (Ttdhdata*);
    virtual ~TPumpIntf();
    virtual entities GetEntType() {return etPUMP;}
    virtual tdh_keytype get_pumpid ();
    virtual bool set_pumpid (tdh_keytype);
    virtual tdh_keytype get_pipekey ();
    virtual void set_pipekey (tdh_keytype);
    virtual bool GotoPipeID (tdh_keytype);
    virtual tdh_keytype get_stationid ();
    virtual void set_stationid (tdh_keytype);
    virtual pumptypes get_pumptype ();
    virtual void set_pumptype (pumptypes);
    virtual double get_power();
    virtual void set_power (double);
    virtual double get_speed();
    virtual void set_speed (double);
    virtual double get_npshr();
    virtual void set_npshr (double);
    virtual void set_stationcurve (bool);
    virtual bool get_stationcurve ();
    virtual Tpumpref0 *PumpRef ();
//    virtual double get_CurrentSpeed();
//    virtual void set_CurrentSpeed(double = -1); //defaults to get_speed(). sets pump coefficients
//    virtual double CalcHead (double); //call set_CurrentSpeed() before calling this
//    virtual double CalcEfficiency (double); //call set_CurrentSpeed() before calling this
//    virtual double CalcFlow (double); //call set_CurrentSpeed() before calling this
//    virtual double CalcSpeed (double flow, double head, double tolerance);
//    virtual void SaveCurrentSpeed (); //save CurrentSpeed
//    virtual void RestoreCurrentSpeed(); //restore saved CurrentSpeed
//    virtual double MaxFlow (); //return highest flow in Pump Pts, adjusted for speed
//    virtual void HeadRange (double*, double*);
};

class EXPORTPROC TPumpPtIntf : public TBaseIntf01 <Tpumppt_data, double> {
protected:
    TPumpIntf *pumpIntf;
    virtual Tpumppt_data *createObj();
public:
    TPumpPtIntf (Ttdhdata*, TPumpIntf*);
    virtual ~TPumpPtIntf ();
    virtual double get_flow();
    virtual bool set_flow (double);
    virtual double get_tdh();
    virtual void set_tdh (double);
    virtual double get_efficiency();
    virtual void set_efficiency (double);
    virtual entities GetEntType() {return etPUMPPT;}
    virtual TPumpIntf *PumpIntf () {return pumpIntf;}
};

class EXPORTPROC Tstation_data;
class EXPORTPROC TStationIntf : public TBaseIntf01 <Tstation_data, tdh_keytype> {
protected:
    virtual Tstation_data *createObj();
public:
    TStationIntf (Ttdhdata*);
    virtual ~TStationIntf ();
    virtual void BeforeDelete();
    virtual tdh_keytype get_stationid ();
    virtual bool set_stationid (tdh_keytype);
    virtual tdh_keytype get_component1();
    virtual void set_component1 (tdh_keytype);
    virtual tdh_keytype get_component2();
    virtual void set_component2 (tdh_keytype);
    virtual FLAG get_stationtype ();
    virtual void set_stationtype (stationtypes);
    virtual FLAG get_outputflag ();
    virtual void set_outputflag (FLAG);
//    virtual FLAG get_newcost();
//    virtual void set_newcost (FLAG);
    virtual double get_unitcost();
    virtual void set_unitcost (double);
    virtual double get_SavedCost();
    virtual void set_SavedCost (double);
    virtual tdh_keytype getPump (tdh_keytype);
    virtual entities GetEntType() {return etSTATION;}
};

class Ttank_data;
class TtdhTank;
class EXPORTPROC TTankIntf : public TBaseIntf01 <Ttank_data, tdh_keytype> {
protected:
    virtual Ttank_data *createObj();
//    virtual bool AttachTank();
//    virtual TtdhTank *Create_TtdhTank();
    friend class TTankPtIntf;
public:
    TTankIntf (Ttdhdata*);
    virtual ~TTankIntf ();
    virtual Ttankref0 *TankRef();
    virtual tdh_keytype get_tankid ();
    virtual bool set_tankid (tdh_keytype);
    virtual tdh_keytype get_nodekey ();
    virtual void set_nodekey (tdh_keytype);
    virtual double get_maxelev();
    virtual void set_maxelev (double);
    virtual double get_minelev ();
    virtual void set_minelev (double);
    virtual double get_MaxChange ();
    virtual void set_MaxChange (double); // max level change between solutionss; 0-use system default, < 0 - no max
    virtual bool get_AllowOverFlow();
    virtual void set_AllowOverFlow (bool);
    virtual bool FindFgn (tdh_keytype fgnid); //move currdata to Tank w/ fgnid
    virtual entities GetEntType() {return etTANK;}
//    virtual double CalcVolume (double); //return the volume (MG or ML) for a specified elevation
//    virtual double CalcElev (double);  //return the elevation for a specified volume (MG or ML)
  };

class Ttankpt_data;
class EXPORTPROC TTankPtIntf : public TBaseIntf01 <Ttankpt_data, double> {
protected:
    TTankIntf *tankIntf;
    virtual Ttankpt_data *createObj();
public:
    TTankPtIntf (Ttdhdata*, TTankIntf*);
    virtual ~TTankPtIntf ();
    virtual double get_level();
    virtual bool set_level (double);
    virtual double get_diam();
    virtual void set_diam (double);
    virtual entities GetEntType() {return etTANKPT;}
  };

class EXPORTPROC TPressDpndcy_data;
class EXPORTPROC TPressDpndcyIntf : public TBaseIntf01 <TPressDpndcy_data, tdh_keytype> {
protected:
  virtual TPressDpndcy_data *createObj();
public:
  TPressDpndcyIntf (Ttdhdata*);
  virtual ~TPressDpndcyIntf();
  virtual entities GetEntType() {return etPressDpndcy;}
  virtual tdh_keytype get_PressDpndcyID();
  virtual bool set_PressDpndcyID(tdh_keytype);
  virtual double get_PressFullQ();
  virtual void set_PressFullQ (double);
  virtual double get_PressNoQ();
  virtual void set_PressNoQ (double);
  virtual double get_Pressure_Tolerance();
  virtual void set_Pressure_Tolerance (double);
  virtual double get_PressHigh();
  virtual void set_PressHigh (double);
  virtual double get_SlopeHigh();
  virtual void set_SlopeHigh (double);
  virtual tdh_keytype get_JunGroup ();
  virtual void set_JunGroup (tdh_keytype);
  virtual bool Active ();
  virtual void set_Active (bool);
  virtual int NoteCode();
  virtual void set_NoteCode (int);
  };


class TPumpControl_data;
class EXPORTPROC TPumpControlIntf : public TBaseIntf01 <TPumpControl_data, tdh_keytype> {
protected:
//  virtual TPumpControl_data *GetDataObj();
  virtual TPumpControl_data *createObj();
public:
  TPumpControlIntf (Ttdhdata*);
  virtual ~TPumpControlIntf ();
  virtual entities GetEntType() {return etPumpControl;}
  virtual tdh_keytype get_PumpID();
  virtual bool set_PumpID (tdh_keytype);
  virtual tdh_keytype get_JunID();
  virtual void set_JunID (tdh_keytype);
  virtual double get_TargetGrade ();
  virtual void set_TargetGrade (double);
  virtual int get_Priority ();
  virtual void set_Priority (int);
  virtual double get_Tolerance();
  virtual void set_Tolerance (double);
  virtual void SequenceInit ();
  virtual void ImplementPumpControls ();
  virtual bool get_Active();
  virtual void set_Active(bool);
  virtual double get_MaxSpeed();
  virtual void set_MaxSpeed (double);
  virtual double get_MinSpeed();
  virtual void set_MinSpeed (double);
  virtual int get_NoteCode();
  virtual void set_NoteCode (int);
  virtual void setCurrent_Grade (double);
  virtual double getCurrent_Grade ();
  virtual void setCurrent_Active (bool);
  virtual bool getCurrent_Active ();
  };


#endif
