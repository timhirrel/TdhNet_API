//provided the definitions needed for exporting from MS Windows dll's

#ifndef EXPORTDEF_HPP_INCLUDED
#define EXPORTDEF_HPP_INCLUDED

#include <stdlib.h>
#define EXTERNC extern "C"

#ifdef _WIN32
  #define tdh_Windows
#endif // _WIN32

#ifdef tdh_Windows
#define EXPORTPROC __declspec(dllexport)
#else
#define EXPORTPROC
#endif

#define EXPORT_common
#ifdef tdh_Windows
  #define EXPORT_common __declspec(dllimport)
#endif
#ifdef TDHCOMMON_EXPORTS
  #define EXPORT_common __declspec(dllexport)
#endif

enum keycomp_result {crKeysEqual, crExKeyLess, crNewKeyLess, crInvalid};
enum NavOpts {navFirst, navLast, navNext, navPrev, navFind, navRandom, navNew, navNear, navNoNotify, navDelete, navChangeKey};



#endif // EXPORTDEF_HPP_INCLUDED
