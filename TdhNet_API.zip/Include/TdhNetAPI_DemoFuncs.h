//Defines the most basic functionality for the TdhNet Demo

#ifndef TdhNetAPIDemo_Header
#define TdhNetAPIDemo_Header

class Ttdhvars;
class TdhContainer;
class TdhSolveControl0;
class TSystemIntf;
class TMessenger0;
class TTdhIO;

extern TMessenger0 *messenger_DemoApi;

class TTdhDemo {
// this class implements the TdhNet solution engine using the TdhNet API
protected:
  Ttdhvars *tdhvars;
  TdhContainer *dataContainer;
  TdhSolveControl0 *solveControl;
  TSystemIntf *sysIntf;
  TTdhIO *tdhIO;
  virtual void SetEngine();
  virtual void Init ();
  virtual void GetFile();
  virtual void WriteDiameters();
  virtual void AttachData();
  virtual void Solve();
  virtual void WriteFlows();
public:
  virtual void Main();
  };


#endif // TdhNetAPIDemo_Header
