//Provides the most basic functionality for vector graphics

#ifndef CadPrimitives0_Header
#define CadPrimitives0_Header

#include "ExportDef.hpp"

class TPointXY0;
typedef TPointXY0& TPtParam;

typedef TPointXY0* TPointPtr;

class EXPORTPROC TPointXY0 {
// an abstract class for providing access to x,y coordinates
// provides shell functions for x,y coordinates to be shared by different entities.
protected:
  virtual void Decr_refcount () {}
  virtual void Incr_refcount () {}
  virtual short RefCount () {return 0;}
  virtual void set_ShareCode (unsigned long) {}
  friend class TSharedPt;
public:
  TPointXY0 (); 
  virtual ~TPointXY0 ();
  void operator = (TPointXY0&);
  virtual void setX (double) = 0;
  virtual void setY (double) = 0;
  virtual double getX () = 0;
  virtual double getY () = 0;
  virtual void SetXY (double xParam, double yParam) {setX(xParam); setY(yParam);}
  virtual void CopyXY (TPointPtr ptParam) {SetXY(ptParam->getX(), ptParam->getY());}
  virtual void CopyXY (TPtParam ptParam) {SetXY(ptParam.getX(), ptParam.getY());}
  virtual bool IsShareable () {return false;}
  virtual bool IsShared () {return false;}
  virtual bool okToDelete () {return true;}
  virtual unsigned long ShareCode () {return 0;}
  };


class EXPORTPROC TPointXY : public TPointXY0 {
// an implementation class for x,y coordinates
// this class is used if no other implementation class is specified
// this class does not implement coordinate sharing
protected:
  double x, y;
public:
  TPointXY ();
  TPointXY(double, double);
  TPointXY (TPtParam);
  void operator = (TPointXY);
  void operator = (TPtParam);
  virtual void setX (double val) {x = val;}
  virtual void setY (double val) {y = val;}
  virtual double getX () {return x;}
  virtual double getY () {return y;}
  virtual double Distance (TPtParam);
  virtual double Angle (TPtParam);
  };

typedef TPointXY TPtResult;

class EXPORTPROC TPointXY_share : public TPointXY {
// an extension of class TPointXY that implements coordinate sharing
// this class is used for coordinate sharing if no other class is specified
protected:
  unsigned long shareCode;
  unsigned short refcount;
  virtual void Decr_refcount ();
  virtual void Incr_refcount ();
  virtual short RefCount () {return refcount;}
  virtual void set_ShareCode (unsigned long val) {shareCode = val;}
  virtual bool okToDelete ();
public:
  TPointXY_share ();
  TPointXY_share (TPtParam);
  virtual ~TPointXY_share ();
  virtual bool IsShareable () {return true;}
  virtual bool IsShared();
  virtual unsigned long ShareCode () {return shareCode;}
  };

class TVertex;
class TSharedPt;

class EXPORTPROC TMultiLine0 {
// an abstract class for an entity containing a list of coordinates defining line segments
public:
  virtual TVertex *AddVertex (TPtParam) =0;
  virtual void DeleteAllPts () = 0;
  virtual bool DeletePt (TPtParam) =0;
  virtual TPointPtr get_FirstPt() = 0;
  virtual TPointPtr get_NextPt() = 0;
  virtual unsigned int getPtCount () =0;
  };

class TMultiLine;

#endif // CadPrimitives0_Header
