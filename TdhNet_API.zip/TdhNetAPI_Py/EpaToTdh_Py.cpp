// Functions to be used by Python to access a modified Epanet API

#include "ExportDef.hpp"
#include "EpaIntf.h"
#include "TdhContainer.hpp"
#include "EpaToTdh.h"
#include "TdhNetIntf_Py.h"
#include "EpaEngine.h"

EXTERNC{


EXPORTPROC  TEpaIntf0 * EpaIntf(void* tdhEpaPtr) {
  return (TEpaIntf0*)tdhEpaPtr;
  }

EXPORTPROC  void* EpaProjPtr_py(void* tdhEpaPtr) {
  return EpaIntf(tdhEpaPtr)->EpaProj();
  }

EXPORTPROC  void* EpaNetwork_py(void* tdhEpaPtr) {
  return EpaIntf(tdhEpaPtr)->EpaNet();
  }

EXPORTPROC  void* EpaParser_py(void* tdhEpaPtr) {
  return EpaIntf(tdhEpaPtr)->EpaParser();
  }

EXPORTPROC  void* EpaHydraulic_py(void* tdhEpaPtr) {
  return EpaIntf(tdhEpaPtr)->EpaParser();
  }


//input
EXPORTPROC  int EN_setflowunits_py(void* tdhEpaPtr, int units) {
  return EpaIntf(tdhEpaPtr)->EN_setflowunits(units);
  }

EXPORTPROC  int EN_setoption_py(void* tdhEpaPtr, int option, double value) {
  return EpaIntf(tdhEpaPtr)->EN_setoption(option, value);
  }

EXPORTPROC  int EN_addlink_py(void* tdhEpaPtr, char* id, int linkType, char* fromNode, char* toNode, int* index) {
  return EpaIntf(tdhEpaPtr)->EN_addlink(id, linkType, fromNode, toNode, index);
  }

EXPORTPROC  int EN_deletelink_py(void* tdhEpaPtr, int index, int actionCode) {
  return EpaIntf(tdhEpaPtr)->EN_deletelink(index, actionCode);
  }

EXPORTPROC  int EN_setlinknodes_py(void* tdhEpaPtr, int index, int node1, int node2) {
  return EpaIntf(tdhEpaPtr)->EN_setlinknodes(index, node1, node2);
  }

EXPORTPROC  int EN_getlinknodes_py(void* tdhEpaPtr, int index, int* out_node1, int* out_node2) {
  return EpaIntf(tdhEpaPtr)->EN_getlinknodes(index, out_node1, out_node2);
  }

EXPORTPROC  int EN_setlinkvalue_py(void* tdhEpaPtr, int index, int property, EN_API_FLOAT_TYPE value) {
  return EpaIntf(tdhEpaPtr)->EN_setlinkvalue(index, property, value);
  }

EXPORTPROC  int EN_setlinktype_py(void* tdhEpaPtr, int* inout_index, int linkType, int actionCode) {
  return EpaIntf(tdhEpaPtr)->EN_setlinktype(inout_index, linkType, actionCode);
  }

EXPORTPROC  int EN_addnode_py(void* tdhEpaPtr, char* id, int nodeType, int* index) {
  return EpaIntf(tdhEpaPtr)->EN_addnode(id, nodeType, index);
  }

EXPORTPROC  int EN_setnodevalue_py(void* tdhEpaPtr, int index, int property, double value) {
  return EpaIntf(tdhEpaPtr)->EN_setnodevalue(index, property, value);
  }

EXPORTPROC  int EN_addcurve_py(void* tdhEpaPtr, char* id) {
  return EpaIntf(tdhEpaPtr)->EN_addcurve(id);
  }

EXPORTPROC  int EN_getcurveindex_py(void* tdhEpaPtr, char* id, int* index) {
  return EpaIntf(tdhEpaPtr)->EN_getcurveindex(id, index);
  }

EXPORTPROC  int EN_setcurvevalue_py(void* tdhEpaPtr, int curveIndex, int pointIndex, double x, double y) {
  return EpaIntf(tdhEpaPtr)->EN_setcurvevalue(curveIndex, pointIndex, x, y);
  }

//results
EXPORTPROC  int EN_getcount_py(void* tdhEpaPtr, int object, int* countParam) {
  return EpaIntf(tdhEpaPtr)->EN_getcount(object, countParam);
  }

char idBuffer[255] = "testID";
EXPORTPROC  int EN_getlinkid_py(void* tdhEpaPtr, int index, char** id) {
	//  *id = testID;
	//  return 0;
	  int result = EpaIntf(tdhEpaPtr)->EN_getlinkid(index, idBuffer);
	  *id = idBuffer;
	  return result;
	  }

EXPORTPROC  int EN_getlinkindex_py(void* tdhEpaPtr, char* id, int* index) {
  return EpaIntf(tdhEpaPtr)->EN_getlinkindex(id, index);
  }

EXPORTPROC  int EN_getlinktype_py(void* tdhEpaPtr, int index, int* linkType) {
	return EpaIntf(tdhEpaPtr)->EN_getlinktype(index, linkType);
	}

EXPORTPROC  int EN_getlinkvalue_py(void* tdhEpaPtr, int index, int property, double* value) {
	return EpaIntf(tdhEpaPtr)->EN_getlinkvalue(index, property, value);
	}

EXPORTPROC  int EN_getnodeid_py(void* tdhEpaPtr, int index, char* id) {
  return EpaIntf(tdhEpaPtr)->EN_getnodeid(index, id);
  }

EXPORTPROC  int EN_getnodeindex_py(void* tdhEpaPtr, char* id, int* index) {
  return EpaIntf(tdhEpaPtr)->EN_getnodeindex(id, index);
  }

EXPORTPROC  int EN_getnodetype_py(void* tdhEpaPtr, int index, int* nodeType) {
  return EpaIntf(tdhEpaPtr)->EN_getnodetype(index, nodeType);
  }

EXPORTPROC  int EN_getnodevalue_py(void* tdhEpaPtr, int index, int property, double* value) {
  return EpaIntf(tdhEpaPtr)->EN_getnodevalue(index, property, value);
  }

EXPORTPROC  int EN_getcurvelen_py(void* tdhEpaPtr, int index, int* len) {
  return EpaIntf(tdhEpaPtr)->EN_getcurvelen(index, len);
  }

//control
EXPORTPROC  int EN_createproject_py(void* tdhEpaPtr) {
  return EpaIntf(tdhEpaPtr)->EN_createproject();
  }

EXPORTPROC  int EN_close_py(void* tdhEpaPtr) {
  return EpaIntf(tdhEpaPtr)->EN_close();
  }

EXPORTPROC  int EN_deleteproject_py(void* tdhEpaPtr) {
  return EpaIntf(tdhEpaPtr)->EN_deleteproject();
  }

EXPORTPROC  int EN_init_py(void* tdhEpaPtr, const char* rptFile, const char* outFile, int unitsType, int headLossType) {
  return EpaIntf(tdhEpaPtr)->EN_init(rptFile, outFile, unitsType, headLossType);
  }

EXPORTPROC  int EN_openH_py(void* tdhEpaPtr) {
  return EpaIntf(tdhEpaPtr)->EN_openH();
  }

EXPORTPROC  int EN_initH_py(void* tdhEpaPtr, int initFlag) {
  return EpaIntf(tdhEpaPtr)->EN_initH(initFlag);
  }

//  virtual int EN_solveH(Epanet_types::EN_Project ph) = 0;

EXPORTPROC  int EN_runH_py(void* tdhEpaPtr, long* currentTime) {
  return EpaIntf(tdhEpaPtr)->EN_runH(currentTime);
  }

EXPORTPROC  int EN_closeH_py(void* tdhEpaPtr) {
  return EpaIntf(tdhEpaPtr)->EN_closeH();
  }

EXPORTPROC  int EN_setreportcallback_py(void* tdhEpaPtr, TEpanetReportCallback callBack) {
  return EpaIntf(tdhEpaPtr)->EN_setreportcallback(callBack);
  }

EXPORTPROC  int EN_setstatusreport_py(void* tdhEpaPtr, int level) {
  return EpaIntf(tdhEpaPtr)->EN_setstatusreport(level);
  }

// non Epanet functions
EXPORTPROC  bool set_FrictionFormula_py(void* tdhEpaPtr, int value) {
  return EpaIntf(tdhEpaPtr)->set_FrictionFormula(value);
  }

EXPORTPROC  void* Create_EpaToTdh_py(void* dataParam) {
//  return Create_EpaToTdh((TdhContainer*)dataContainer);
  TdhContainer* dataContainer = TdhContainer_py(dataParam);
  return Create_EpaToTdh(dataContainer);
  }

} //EXTERNC
