// defines functions within TdhNet_DemoPy.cpp used within EpaToTdh_DemoPy.cpp

#ifndef TdhNetDemoPy_Header
#define TdhNetDemoPy_Header

#include "ExportDef.hpp"

EXTERNC TdhContainer *TdhContainer_py (void*);

EXTERNC Ttdhvars EXPORTPROC *GetTdhVars_py ();

EXTERNC TdhContainer EXPORTPROC *get_TdhContainer_py11 (Ttdhvars*);

#endif // TdhNetDemoPy_Header
