// Functions to be used by Python code to access the TdhNet API
// building this library requires access to the header file in the TdhNet API Include directory
// and access to the executable libraries in the TdhNet API for specific compilers

#include "TdhIO.hpp"
#include "TdhSql_IO.h"
#include "TdhEngine.h"
#include "EpaEngine.h"

#include "TdhNetIntf_Py.h"

#include <cstring>

namespace TdhNetNS_py {



EXTERNC TdhContainer EXPORTPROC *get_TdhContainer (Ttdhvars*);


const int idSize = 65;
const char *IDstr (std::string strParam) {
  static char idStr [idSize];
  strncpy (idStr, strParam.c_str(), idSize);
  return idStr;
  }


EXTERNC {

TMessenger0 * MessProc_py() {
  return Messenger_Console();
  }


EXPORTPROC Ttdhvars * GetTdhVars_py() {
    Ttdhvars* tdhvars = GetTdhVars(MessProc_py());
    if (!tdhvars->Ok())
        MessProc_py()->Message("create tdhvars failed");
    return tdhvars;
    }


Ttdhvars *TdhVars_py (void *varsParam) {
  return (Ttdhvars*)varsParam;  }

EXPORTPROC TdhContainer *get_TdhContainer_py (void *varsParam) {
  Ttdhvars *tdhvars = TdhVars_py(varsParam);
  TdhContainer *result = get_TdhContainer(tdhvars);
  return result;
  }

TdhContainer *get_TdhContainer_py11 (Ttdhvars *varsParam) {
  return get_TdhContainer(varsParam);
  }

TdhContainer *TdhContainer_py (void *dataParam) {
  return (TdhContainer*)dataParam;
  }

EXPORTPROC  void TdhSolve_AttachData_py (void *dataParam, const char *chanset) {
  TdhContainer *dataContainer = TdhContainer_py(dataParam);
  dataContainer->AttachData(chanset);
  }

EXPORTPROC  TTdhIO *TdhIO_StartUp_py (void *dataParam) {
  TdhContainer *dataContainer = TdhContainer_py(dataParam);
  return TdhIO_StartUp (dataContainer, dataContainer->TdhVars()->Messenger());
  }

EXPORTPROC  bool tdhfile_readfiletype_py (void *ioParam, const char *filename, int typeparam) {
  return ((TTdhIO*)ioParam)->ReadFileType (filename, (TTdhIO::filetypes)typeparam);
  }

TtdhDataIntf *BaseIntf_py (void *intfParam) {
  return (TtdhDataIntf*)intfParam;
  }

EXPORTPROC  bool BaseIntf_GotoFirst_py (void *intfParam) {
  return BaseIntf_py(intfParam)->GotoFirst();
  }

EXPORTPROC  bool BaseIntf_GotoNext_py (void *intfParam) {
  return BaseIntf_py(intfParam)->GotoNext();
  }

EXPORTPROC  void *GetPipeIntf_py (void *tdhContainer) {
  TPipeIntf *pipeIntf = ((TdhContainer*)tdhContainer)->DataIntfs()->get_PipeIntf2();
  return pipeIntf;
  }

TPipeIntf2 *PipeIntf_py (void *intfParam) {
  return (TPipeIntf2*)intfParam;
  }

EXPORTPROC  const char* PipeIntf_PipeID_py (void *intfParam) {
  TPipeIntf2 *pipeIntf = PipeIntf_py(intfParam);
  return IDstr (pipeIntf->get_pipeid().c_str());
  }

EXPORTPROC  double PipeIntf_Diameter_py (void *intfParam) {
  TPipeIntf2 *pipeIntf = PipeIntf_py(intfParam);
  return pipeIntf->get_diameter();
  }


EXPORTPROC  void Use_TdhNet_Engine_py (void *varsParam) {
  Ttdhvars *tdhvars = TdhVars_py(varsParam);
  Use_TdhNet_Engine(tdhvars);
  }

EXPORTPROC  void Use_EpaNet_Engine_py (void *varsParam, void *epaIntf) {
  Ttdhvars *tdhvars = TdhVars_py(varsParam);
  Use_EpaNet_Engine(tdhvars, (TEpaIntf0*)epaIntf);
  }

EXPORTPROC  void *get_EpaIntf_py () {
  return get_EpaIntf(Messenger_Epa());
  }



EXPORTPROC  TdhSolveControl0 *Get_TdhSolveControl_py(void *varsParam) {
  Ttdhvars *tdhvars = TdhVars_py(varsParam);
  TdhSolveControl0 *solveControl = tdhvars->SolveControl();
  return solveControl;
  }

TdhSolveControl0 *TdhSolveControl_py (void *solveParam) {
  return (TdhSolveControl0*)solveParam;
  }

EXPORTPROC int TdhSolve_StartUp_py (void *solveParam) {
  TdhSolveControl0 *solveControl = TdhSolveControl_py(solveParam);
  return solveControl->StartUp();
  }

EXPORTPROC int TdhSolve_DataCheck_py (void *solveParam) {
  TdhSolveControl0 *solveControl = TdhSolveControl_py(solveParam);
  return solveControl->DataCheck();
  }

EXPORTPROC int TdhSolve_SequenceInit_py (void *solveParam, bool dataInit) {
  TdhSolveControl0 *solveControl = TdhSolveControl_py(solveParam);
  return solveControl->SequenceInit(dataInit);
  }

EXPORTPROC  int TdhSolve_SolveOne_py (void *solveParam, int iteratParam) {
  TdhSolveControl0 *solveControl = TdhSolveControl_py(solveParam);
  return solveControl->SolveOne(iteratParam);
  }

EXPORTPROC  int TdhSolve_ResetSolve_py (void *solveParam) {
  TdhSolveControl0 *solveControl = TdhSolveControl_py(solveParam);
  return solveControl->ResetSolve();
  }

EXPORTPROC  void *TdhSystemResult_Create_py (void *varsParam) {
  Ttdhvars *tdhvars = TdhVars_py(varsParam);
  TSystemResults0 *sysResults = tdhvars->ResultsClasses()->SystemRslts();
  return sysResults;
  }

TSystemResults0 *SystemResults_py (void *resultsParam) {
  return (TSystemResults0*)resultsParam;
  }

EXPORTPROC  int SysRslts_solution_status_py (void *resultsParam) {
  // returns the status of the most recent solution attempt
  return SystemResults_py(resultsParam)->solution_status();
  }

EXPORTPROC  double SysRslts_total_demand_py (void *resultsParam) {
//returns the total demand
  return SystemResults_py(resultsParam)->total_demand();
  }

EXPORTPROC  double SysRslts_solution_accuracy_py (void *resultsParam) {
 //returns the accuracy (flow convergence)
  return SystemResults_py(resultsParam)->solution_accuracy();
  }

EXPORTPROC  double SysRslts_solution_patherror_py (void *resultsParam) {
//return the path error
  return SystemResults_py(resultsParam)->solution_patherror();
  }

class TResults_base;
Ttdh_recrslts2 <TResults_base, basekey> *ResultsBase (void *resultsParam) {
  return (Ttdh_recrslts2 <TResults_base, basekey>*)resultsParam; }

EXPORTPROC  bool BaseRslt_GotoFirst_py (void *rsltsParam) {
  return ResultsBase(rsltsParam)->GotoFirst();
  }

EXPORTPROC  bool BaseRslt_GotoNext_py (void *rsltsParam) {
  return ResultsBase(rsltsParam)->GotoNext();
  }

EXPORTPROC  void *TdhPipeResult_Create_py (void *varsParam) {
  Ttdhvars *tdhvars = TdhVars_py(varsParam);
  TPipeResults0 *pipeResults = tdhvars->ResultsClasses()->PipeRslts();
  return pipeResults;
//  return PyCapsule_New(pipeResults, ModStr("PipeResults"), NULL);
  }

TPipeResults0 *PipeResults_py (void *resultsParam) {
  return (TPipeResults0*)resultsParam;
  }

EXPORTPROC  const char* PipeRslt_PipeID_py (void *rsltsParam) {
  TPipeResults0 *pipeRslt = PipeResults_py(rsltsParam);
  return IDstr (pipeRslt->pipeid().c_str());
  }

EXPORTPROC  double PipeRslt_Flow_py (void *rsltsParam) {
  TPipeResults0 *pipeRslt = PipeResults_py(rsltsParam);
  return pipeRslt->flow();
  }

EXPORTPROC  TdhSql_netIO *GetSql_netIO_py (void *dataContainer, const char *structPath) {
  return new TdhSql_netIO(TdhContainer_py(dataContainer), structPath);
  }

TdhSql_netIO *TdhSql_netIO_py (void *sqlIO) {
  return (TdhSql_netIO*)sqlIO;
  }

EXPORTPROC  bool Sql_IO_SetDB_py (void *sqlIO, const char *execPath) {
  return TdhSql_netIO_py(sqlIO)->SetDB(execPath);
  }

EXPORTPROC  void SaveNetToDB_py (void *sqlIO, const char *netID) {
//set network name and save to database
  TdhSql_netIO_py(sqlIO)->DataContainer()->DataIntfs()->get_SystemIntf2()->set_netname(netID);
  TdhSql_netIO_py(sqlIO)->SaveNetwork();
  }

EXPORTPROC  void GetNetFromDB_py (void *sqlIO, const char *netID) {
//retrieve network from database
  TdhSql_netIO_py(sqlIO)->getNetwork(TdhSql_netIO_py(sqlIO)->getNetworkCode(netID));
  }

EXPORTPROC  void SaveResultsToDB_py (void *sqlIO, int runNum) {
//save results to database using scratch run and situation numbers (will overwrite any previously saved scratch results)
  TdhSql_netIO_py(sqlIO)->SaveResults((loadResultsFlag)runNum);
  }

EXPORTPROC  void GetResultsFromDB_py (void *sqlIO, const char *netID, long runParam, int sitParam) {
//retrieve saved scratch results
  TdhSql_netIO_py(sqlIO)->getResults(TdhSql_netIO_py(sqlIO)->getNetworkCode(netID), runParam, sitParam);
  }

} //EXTERNC

} //namespace


