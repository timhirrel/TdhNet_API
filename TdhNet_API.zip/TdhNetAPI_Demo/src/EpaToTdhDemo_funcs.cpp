#include "EpaEngine.h"
#include "TdhEngine.h"
#include "EpaIntf.h"
#include "TdhIO.hpp"
#include "EpaToTdhDemo_funcs.h"
#include "TdhContainer.hpp"


void TEpaToTdhDemo::WriteDiameters () {
//write the pipe id and diameter for every pipe
  char id [255];
  double diam, status;
  int numPipes;
  EpaIntf()->EN_getcount(Epanet_types::EN_LINKCOUNT, &numPipes);
  for (int i=1; i<numPipes+1; i++) {
    EpaIntf()->EN_getlinkid(i, id);
    EpaIntf()->EN_getlinkvalue(i, Epanet_types::EN_DIAMETER, &diam);
    EpaIntf()->EN_getlinkvalue(i, Epanet_types::EN_INITSTATUS, &status);
	std::cout <<  id << ", " << diam << ", " << status << std::endl;
    }
  }

void TEpaToTdhDemo::Solve () {
// execute a single hydraulic solution
  long epaTime;
  EpaIntf()->EN_initH(0);
  EpaIntf()->EN_runH(&epaTime);
  sysRslts = tdhvars->ResultsClasses()->SystemRslts();
  std::cout <<  "Total Demand: " << sysRslts->total_demand() << std::endl;
  }

void TEpaToTdhDemo::WriteFlows () {
// write the pipe id and flow (in the user specified units) for every pipe
  char id [255];
  double flow, loss;
  int numPipes;
  EpaIntf()->EN_getcount(Epanet_types::EN_LINKCOUNT, &numPipes);
  for (int i=1; i<numPipes+1; i++) {
    EpaIntf()->EN_getlinkid(i, id);
    EpaIntf()->EN_getlinkvalue(i, Epanet_types::EN_FLOW, &flow);
    EpaIntf()->EN_getlinkvalue(i, Epanet_types::EN_HEADLOSS, &loss);
	std::cout <<  id << ", " << flow << ", " << loss << std::endl;
    }
//actually, either API can be used with this class. the TdhNet API could be used here by calling TTdhDemo::WriteFlows()
  }

void TEpaToTdhDemo::Init () {
  tdhvars = GetTdhVars (messenger_DemoApi);
  tdhvars2 = GetTdhVars (messenger_DemoApi);
  dataContainer = get_TdhContainer(tdhvars);
  dataContainer2 = get_TdhContainer(tdhvars2);
  Use_TdhNet_Engine(tdhvars2);
  epaIntf = Create_EpaToTdh(dataContainer2);
  Use_EpaNet_Engine(tdhvars, epaIntf);
  tdhIO = TdhIO_StartUp(dataContainer, messenger_DemoApi);
  solveControl = tdhvars->SolveControl();
  solveControl->StartUp();
  }


void TEpaToEpaDemo::Init () {
  TEpaDemo::Init();
  }

void TEpaToEpaDemo::SetEngine () {
  epaIntf = get_EpaIntf(messenger_DemoApi);
  Use_EpaNet_Engine(tdhvars, epaIntf);
  }

void TEpaToEpaDemo::Solve () {
  TEpaDemo::Solve();
}
